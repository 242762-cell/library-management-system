#!/usr/bin/env python3
import sys
p = 'frontend_java/data/sold_books.json'
try:
    with open(p, 'r', encoding='utf-8') as f:
        s = f.read()
except FileNotFoundError:
    print('No sold_books.json found, nothing to repair')
    sys.exit(0)
objs = []
idx = 0
while True:
    st = s.find('{', idx)
    if st == -1:
        break
    en = s.find('}', st)
    if en == -1:
        break
    obj = s[st:en+1].strip()
    objs.append(obj)
    idx = en + 1
if objs:
    out = '[\n' + ',\n'.join('  ' + o for o in objs) + '\n]\n'
else:
    out = '[]\n'
with open(p, 'w', encoding='utf-8') as f:
    f.write(out)
print('Repaired', p)
