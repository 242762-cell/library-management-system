#include "SalesList.h"
#include "../util/FileUtils.h"
#include <sstream>
#include <iterator>
#include <vector>
#include <cctype>
#include <fstream>

using namespace std;

// Comparator used for heap operations: higher amount == higher priority.
// Tie-break on id to make ordering deterministic across runs.
static auto saleCompare = [](const Sale &a, const Sale &b){
    if (a.amount != b.amount) return a.amount < b.amount; // returns true if a is less than b (so max-heap by amount)
    return a.id < b.id; // tie-break by id
};

// Helper: parse int/double/string fields from JSON-like text
static int parseIntField(const string& obj, const string& key, int defaultVal = 0) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length();
    while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart;
    while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-')) ++numEnd;
    try { return stoi(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}
static double parseDoubleField(const string& obj, const string& key, double defaultVal = 0.0) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length();
    while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart;
    while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-' || obj[numEnd]=='.')) ++numEnd;
    try { return stod(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}
static string parseStringField(const string& obj, const string& key) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return "";
    size_t start = obj.find('"', pos + key.length());
    if (start == string::npos) return "";
    size_t end = obj.find('"', start + 1);
    if (end == string::npos) return "";
    return obj.substr(start + 1, end - start - 1);
}

// small helpers to simplify file/object handling
static string readFileStr(const string &path) {
    ifstream f(path);
    if (!f.is_open()) return "";
    return string((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
}
static vector<string> extractObjects(const string &content) {
    vector<string> objs; size_t idx=0;
    while (true) {
        size_t s = content.find('{', idx); if (s==string::npos) break;
        size_t e = content.find('}', s); if (e==string::npos) break;
        string o = content.substr(s, e-s+1);
        size_t a=0; while (a<o.size() && isspace((unsigned char)o[a])) a++; size_t b=o.size(); while (b>a && isspace((unsigned char)o[b-1])) b--; objs.push_back(o.substr(a,b-a)); idx = e+1;
    }
    return objs;
}
static bool writeJsonArrayFile(const string &path, const vector<string> &objs) {
    string out = "[\n";
    for (size_t i=0;i<objs.size();++i) { out += "  " + objs[i]; if (i+1!=objs.size()) out += ",\n"; else out += "\n"; }
    out += "]\n";
    return writeWithBackup(path, out);
}
static string replaceSuffix(string path, const string &from, const string &to) { size_t p = path.rfind(from); if (p!=string::npos) path.replace(p, from.length(), to); return path; }

SalesList::SalesList() {}
SalesList::~SalesList() {}

void SalesList::loadFromFile(const char* dataFile) {
    string content = readFileStr(dataFile);
    sales.clear();
    if (content.empty()) return;
    auto objs = extractObjects(content);
    for (auto &o : objs) {
        Sale s{};
        s.id = parseIntField(o, "\"id\":", 0);
        s.bookId = parseIntField(o, "\"bookId\":", 0);
        s.amount = parseDoubleField(o, "\"amount\":", 0.0);
        s.date = parseStringField(o, "\"date\":");
        s.title = parseStringField(o, "\"title\":");
        s.author = parseStringField(o, "\"author\":");
        sales.push_back(s);
    }
    rebuildHeap();
}

void SalesList::saveToFile(const char* dataFile) {
    ofstream file(dataFile);
    if (!file.is_open()) return;
    file << "[\n";
    int n = sales.size();
    int i = 0;
    for (auto &s : sales) {
        file << "  { \"id\": " << s.id
             << ", \"bookId\": " << s.bookId
             << ", \"amount\": " << s.amount
             << ", \"date\": \"" << s.date << "\"";
        if (!s.title.empty()) file << ", \"title\": \"" << s.title << "\"";
        if (!s.author.empty()) file << ", \"author\": \"" << s.author << "\"";
        file << " }";
        if (++i < n) file << ",\n"; else file << "\n";
    }
    file << "]\n";
    file.close();
} 

int SalesList::addSale(Sale s) {
    // assign id
    int maxId = 0; for (auto &x : sales) if (x.id > maxId) maxId = x.id;
    s.id = maxId + 1; sales.push_back(s);
    // maintain heap incrementally
    heap.push_back(s);
    push_heap(heap.begin(), heap.end(), saleCompare);
    return s.id;
}


list<Sale>::iterator SalesList::searchSale(int id) {
    return find_if(sales.begin(), sales.end(), [id](const Sale &s) { return s.id == id; });
}

bool SalesList::deleteSale(int id) {
    auto it = searchSale(id);
    if (it != sales.end()) {
        sales.erase(it);
        // rebuild heap to reflect deletion (simple and safe)
        rebuildHeap();
        return true;
    }
    return false;
}

void SalesList::rebuildHeap() {
    heap.clear();
    for (auto &s : sales) heap.push_back(s);
    if (!heap.empty()) make_heap(heap.begin(), heap.end(), saleCompare);
}

bool SalesList::getTop(Sale &out) {
    if (heap.empty()) return false;
    out = heap.front();
    return true;
}

vector<Sale> SalesList::topN(int n) {
    vector<Sale> res;
    if (n <= 0 || heap.empty()) return res;
    vector<Sale> tmp = heap;
    sort(tmp.begin(), tmp.end(), [](const Sale &a, const Sale &b){ return a.amount > b.amount; });
    size_t take = min((size_t)n, tmp.size());
    res.insert(res.end(), tmp.begin(), tmp.begin() + take);
    return res;
}

void SalesList::displaySales(ostream& os) {
    os << "{\n";
    os << "  \"status\": \"success\",\n";
    os << "  \"data\": [\n";
    for (auto it = sales.begin(); it != sales.end(); ++it) {
        os << "    { \"id\": " << it->id << ", \"bookId\": " << it->bookId << ", \"amount\": " << it->amount << ", \"date\": \"" << it->date << "\"";
        if (!it->title.empty()) os << ", \"title\": \"" << it->title << "\"";
        if (!it->author.empty()) os << ", \"author\": \"" << it->author << "\"";
        os << " }";
        if (next(it) != sales.end()) os << ",\n"; else os << "\n";
    }
    os << "  ]\n";
    os << "}\n";
}

void SalesList::execute(const char* inputFile, const char* resultFile, const char* dataFile) {
    loadFromFile(dataFile);

    ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        ofstream outFile(resultFile);
        outFile << "{ \"status\": \"error\", \"message\": \"Could not open input file.\" }";
        return;
    }

    string jsonContent((istreambuf_iterator<char>(inFile)), istreambuf_iterator<char>());
    inFile.close();

    string operation;
    size_t op_pos = jsonContent.find("\"operation\": \"");
    if (op_pos != string::npos) {
        size_t start = op_pos + 14;
        size_t end = jsonContent.find("\"", start);
        operation = jsonContent.substr(start, end - start);
    }

    ofstream outFile(resultFile);
    if (operation.empty()) { outFile << "{ \"status\": \"error\", \"message\": \"Operation not specified.\" }"; return; }

    if (operation == "add") {
        Sale s; s.id = 0; s.bookId = 0; s.amount = 0.0; s.date = ""; s.title = ""; s.author = "";
        size_t book_pos = jsonContent.find("\"bookId\":");
        size_t amt_pos = jsonContent.find("\"amount\":");
        if (book_pos != string::npos && amt_pos != string::npos) {
            s.bookId = parseIntField(jsonContent, "\"bookId\":", 0);
            s.amount = parseDoubleField(jsonContent, "\"amount\":", 0.0);
            s.date = parseStringField(jsonContent, "\"date\":");
            s.title = parseStringField(jsonContent, "\"title\":");
            s.author = parseStringField(jsonContent, "\"author\":");
            int assignedId = addSale(s);
            s.id = assignedId;
            saveToFile(dataFile);

            // mark book as sold and update supporting files (books_data.json, sold_books.json, sales_summary.json)


            string booksFile(dataFile);
            booksFile = replaceSuffix(booksFile, "sales_data.json", "books_data.json");
            string removedObj = "";
            ifstream bf(booksFile);
            if (bf.is_open()) {
                string content((istreambuf_iterator<char>(bf)), istreambuf_iterator<char>());
                bf.close();
                auto objs = extractObjects(content);
                vector<string> kept;
                for (auto &o : objs) {
                    int bid = parseIntField(o, "\"id\":", 0);
                    if (bid == s.bookId) { removedObj = o; continue; }
                    kept.push_back(o);
                }
                if (!writeJsonArrayFile(booksFile, kept)) { outFile << "{ \"status\": \"error\", \"message\": \"Failed to write books_data.json safely.\" }"; return; }
                if (!removedObj.empty()) {
                    string soldFile = replaceSuffix(booksFile, "books_data.json", "sold_books.json");
                    ifstream sf(soldFile);
                    string soldContent;
                    if (sf.is_open()) { soldContent.assign((istreambuf_iterator<char>(sf)), istreambuf_iterator<char>()); sf.close(); }
                    auto existing = extractObjects(soldContent);
                    existing.push_back(removedObj);
                    if (!writeJsonArrayFile(soldFile, existing)) { outFile << "{ \"status\": \"error\", \"message\": \"Failed to update sold_books.json safely.\" }"; return; }
                }
            }

            // update sales summary
            double totalCollected = 0.0; int saleCount = 0;
            for (auto &x : sales) { totalCollected += x.amount; saleCount++; }
            string summaryFile(dataFile);
            summaryFile = replaceSuffix(summaryFile, "sales_data.json", "sales_summary.json");
            ostringstream summaryStream;
            time_t t = time(nullptr);
            string timestr;
            if (struct tm* lt = localtime(&t)) { char buf[64]; if (strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", lt)) timestr = buf; }
            if (timestr.empty()) timestr = to_string((long long)t);
            summaryStream << "{\n  \"totalCollected\": " << totalCollected << ",\n  \"saleCount\": " << saleCount << ",\n  \"lastUpdated\": \"" << timestr << "\"\n}\n";
            if (!writeWithBackup(summaryFile, summaryStream.str())) { outFile << "{ \"status\": \"error\", \"message\": \"Failed to update sales_summary.json safely.\" }"; return; }

            outFile << "{ \"status\": \"success\", \"message\": \"Sale added successfully.\" }";
        } else {
            outFile << "{ \"status\": \"error\", \"message\": \"Invalid sale data for add operation.\" }";
        }
    } else if (operation == "search") {
        size_t id_pos = jsonContent.find("\"id\":");
        if (id_pos != string::npos) {
            int id = stoi(jsonContent.substr(id_pos + 5));
            auto it = searchSale(id);
            if (it != sales.end()) {
                outFile << "{\n  \"status\": \"success\",\n  \"data\": {\n" << "    \"id\": " << it->id << ",\n" << "    \"bookId\": " << it->bookId << ",\n" << "    \"amount\": " << it->amount << ",\n" << "    \"date\": \"" << it->date << "\"\n  }\n}";
            } else {
                outFile << "{ \"status\": \"error\", \"message\": \"Sale not found.\" }";
            }
        } else {
            outFile << "{ \"status\": \"error\", \"message\": \"ID not provided for search.\" }";
        }
    } else if (operation == "delete") {
        size_t id_pos = jsonContent.find("\"id\":");
        if (id_pos != string::npos) {
            int id = stoi(jsonContent.substr(id_pos + 5));
            if (deleteSale(id)) { saveToFile(dataFile); outFile << "{ \"status\": \"success\", \"message\": \"Sale deleted successfully.\" }"; }
            else { outFile << "{ \"status\": \"error\", \"message\": \"Sale not found for deletion.\" }"; }
        } else { outFile << "{ \"status\": \"error\", \"message\": \"ID not provided for delete.\" }"; }
    } else if (operation == "display") {
        displaySales(outFile);
    } else if (operation == "top") {
        Sale t;
        if (getTop(t)) {
            outFile << "{ \"status\": \"success\", \"data\": { \"id\": " << t.id << ", \"bookId\": " << t.bookId << ", \"amount\": " << t.amount << ", \"date\": \"" << t.date << "\" } }";
        } else {
            outFile << "{ \"status\": \"error\", \"message\": \"No sales available.\" }";
        }
    } else if (operation == "topN") {
        int n = parseIntField(jsonContent, "\"n\":", 5);
        auto arr = topN(n);
        outFile << "{ \"status\": \"success\", \"data\": [";
        for (size_t i=0;i<arr.size();++i) {
            auto &it = arr[i];
            if (i) outFile << ", ";
            outFile << "{ \"id\": " << it.id << ", \"bookId\": " << it.bookId << ", \"amount\": " << it.amount << ", \"date\": \"" << it.date << "\" }";
        }
        outFile << "] }";
    } else {
        outFile << "{ \"status\": \"error\", \"message\": \"Unknown operation.\" }";
    }
    outFile.close();
}
