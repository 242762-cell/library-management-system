#ifndef SALESLIST_H
#define SALESLIST_H

#include <ostream>
#include <string>
#include <list>
#include <vector>
#include <algorithm>

struct Sale {
    int id;
    int bookId;
    double amount;
    std::string date;
    std::string title;
    std::string author;
};

class SalesList {
private:
    std::list<Sale> sales;
    // max-heap for fast retrieval of highest-amount sales
    std::vector<Sale> heap;
    void rebuildHeap();
public:
    SalesList();
    ~SalesList();

    int addSale(Sale s);
    std::list<Sale>::iterator searchSale(int id);
    bool deleteSale(int id);
    void displaySales(std::ostream& os);

    // Heap helpers
    bool getTop(Sale &out);
    std::vector<Sale> topN(int n);

    void execute(const char* inputFile, const char* resultFile, const char* dataFile);
    void loadFromFile(const char* dataFile);
    void saveToFile(const char* dataFile);
};

#endif // SALESLIST_H
