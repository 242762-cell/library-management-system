#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "book/BookService.h"
#include "member/MemberList.h"
#include "issue_return/IssueQueue.h"
#include "sales/SalesList.h"

using namespace std;

bool fileExists(const std::string& name) {
    std::ifstream f(name.c_str());
    return f.good();
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Error: Module not specified." << std::endl;
        std::cerr << "Usage: " << argv[0] << " [book|member|sales]" << std::endl;
        return 1;
    }

    std::string module = argv[1];

    // Dynamic path detection
    std::string prefix = "frontend_java/data/";
    if (!fileExists(prefix + "book.json")) {
        if (fileExists("data/book.json")) {
            prefix = "data/";
        } else if (fileExists("../frontend_java/data/book.json")) {
            prefix = "../frontend_java/data/";
        }
    }

    if (module == "book") {
        BookService bookService;
        bookService.execute((prefix + "book.json").c_str(), (prefix + "result.json").c_str(), (prefix + "books_data.json").c_str());
    } 
    else if (module == "member") {
        MemberList memberList;
        memberList.execute((prefix + "member.json").c_str(), (prefix + "result.json").c_str(), (prefix + "members_data.json").c_str());
    }
    else if (module == "sales") {
        SalesList sales;
        sales.execute((prefix + "sales.json").c_str(), (prefix + "result.json").c_str(), (prefix + "sales_data.json").c_str());
    }
    else if (module == "issue") {
        IssueQueue issues;
        issues.execute((prefix + "issue.json").c_str(), (prefix + "result.json").c_str(), (prefix + "issues_data.json").c_str());
    }
    else {
        std::cerr << "Error: Invalid module specified." << std::endl;
                std::cerr << "Valid modules are: book, member, sales, issue" << std::endl;
        return 1;
    }

    return 0;
}