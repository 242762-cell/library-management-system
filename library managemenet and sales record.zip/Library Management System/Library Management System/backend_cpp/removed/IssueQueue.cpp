#include "IssueQueue.h"
#include "../util/FileUtils.h"
#include <fstream>
#include <string>
#include <list>
#include <algorithm> // For std::sort
#include <cctype>
#include <sstream>
#include <vector>

using namespace std;

// Helper: parse integer value for a given key in a JSON-like string.
// Returns defaultVal if key not found or parse fails.
static int parseIntField(const string& obj, const string& key, int defaultVal = 0) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length();
    while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart;
    while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-')) ++numEnd;
    try { return stoi(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}

// Helper: parse a quoted string value for a given key
static string parseStringField(const string& obj, const string& key) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return "";
    size_t start = obj.find('"', pos + key.length());
    if (start == string::npos) return "";
    size_t end = obj.find('"', start + 1);
    if (end == string::npos) return "";
    return obj.substr(start + 1, end - start - 1);
}

// small helpers to shorten file parsing
static string readFileStr(const string &path) {
    ifstream f(path);
    if (!f.is_open()) return "";
    return string((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
}
static vector<string> extractObjects(const string &content) {
    vector<string> objs; size_t idx=0;
    while (true) {
        size_t s = content.find('{', idx); if (s==string::npos) break;
        size_t e = content.find('}', s); if (e==string::npos) break;
        string o = content.substr(s, e-s+1);
        size_t a=0; while (a<o.size() && isspace((unsigned char)o[a])) a++; size_t b=o.size(); while (b>a && isspace((unsigned char)o[b-1])) b--; objs.push_back(o.substr(a,b-a)); idx = e+1;
    }
    return objs;
}

// Constructor and Destructor
IssueQueue::IssueQueue() {}
IssueQueue::~IssueQueue() {}

// Load issued books from a JSON-like file
void IssueQueue::loadFromFile(const char* dataFile) {
    string content = readFileStr(dataFile);
    issuedBooks.clear();
    if (content.empty()) return;
    auto objs = extractObjects(content);
    for (auto &o : objs) {
        IssueRecord r{};
        r.bookId = parseIntField(o, "\"bookId\":", 0);
        r.memberId = parseIntField(o, "\"memberId\":", 0);
        r.issueDate = parseStringField(o, "\"issueDate\":");
        issuedBooks.push_back(r);
    }
}

// Save issued books to a JSON-like file
void IssueQueue::saveToFile(const char* dataFile) {
    ostringstream out;
    out << "[\n";
    for (auto it = issuedBooks.begin(); it != issuedBooks.end(); ++it) {
        out << "  { \"bookId\": " << it->bookId
            << ", \"memberId\": " << it->memberId
            << ", \"issueDate\": \"" << it->issueDate << "\" }";
        if (next(it) != issuedBooks.end()) {
            out << ",\n";
        } else {
            out << "\n";
        }
    }
    out << "]\n";
    writeWithBackup(string(dataFile), out.str());
}

// Enqueue an issue record
void IssueQueue::issueBook(IssueRecord record) {
    issuedBooks.push_back(record);
}

// Find and remove a record by bookId
bool IssueQueue::returnBook(int bookId) {
    size_t initial_size = issuedBooks.size();
    issuedBooks.remove_if([bookId](const IssueRecord& record) {
        return record.bookId == bookId;
    });
    return issuedBooks.size() < initial_size;
}

// Display all issued books, with an option to sort
void IssueQueue::displayIssuedBooks(ostream& os, bool sorted) {
    if (sorted) {
        issuedBooks.sort([](const IssueRecord& a, const IssueRecord& b) {
            return a.bookId < b.bookId;
        });
    }

    os << "{\n  \"status\": \"success\",\n  \"data\": [\n";
    for (auto it = issuedBooks.begin(); it != issuedBooks.end(); ++it) {
        os << "    { \"bookId\": " << it->bookId
           << ", \"memberId\": " << it->memberId
           << ", \"issueDate\": \"" << it->issueDate << "\" }";
        if (next(it) != issuedBooks.end()) {
            os << ",\n";
        } else {
            os << "\n";
        }
    }
    os << "  ]\n}";
}

// Main execution logic
void IssueQueue::execute(const char* inputFile, const char* resultFile, const char* dataFile) {
    loadFromFile(dataFile);

    ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        ofstream outFile(resultFile);
        outFile << "{ \"status\": \"error\", \"message\": \"Could not open input file.\" }";
        return;
    }

    string jsonContent((istreambuf_iterator<char>(inFile)), istreambuf_iterator<char>());
    inFile.close();
    
    string operation;
    size_t op_pos = jsonContent.find("\"operation\": \"");
    if (op_pos != string::npos) {
        size_t start = op_pos + 14;
        size_t end = jsonContent.find("\"", start);
        operation = jsonContent.substr(start, end - start);
    }
    
    ofstream outFile(resultFile);
    if (operation.empty()) {
        outFile << "{ \"status\": \"error\", \"message\": \"Operation not specified.\" }";
        return;
    }

    if (operation == "issue") {
        IssueRecord newRecord;
        int bid = parseIntField(jsonContent, "\"bookId\":", -1);
        int mid = parseIntField(jsonContent, "\"memberId\":", -1);
        std::string date = parseStringField(jsonContent, "\"issueDate\":");

        if (bid != -1 && mid != -1 && !date.empty()) {
            newRecord.bookId = bid;
            newRecord.memberId = mid;
            newRecord.issueDate = date;
            
            issueBook(newRecord);
            saveToFile(dataFile);
            outFile << "{ \"status\": \"success\", \"message\": \"Book issued successfully.\" }";
        } else {
            outFile << "{ \"status\": \"error\", \"message\": \"Invalid data for issue operation.\" }";
        }

    } else if (operation == "return") {
        int bookId = parseIntField(jsonContent, "\"bookId\":", -1);
        if (bookId != -1) {
            if (returnBook(bookId)) {
                saveToFile(dataFile);
                outFile << "{ \"status\": \"success\", \"message\": \"Book returned successfully.\" }";
            } else {
                outFile << "{ \"status\": \"error\", \"message\": \"Issued book not found.\" }";
            }
        } else {
            outFile << "{ \"status\": \"error\", \"message\": \"Book ID not provided for return.\" }";
        }

    } else if (operation == "display") {
        displayIssuedBooks(outFile, false);
    } else if (operation == "display_sorted") {
        displayIssuedBooks(outFile, true);
    } else {
        outFile << "{ \"status\": \"error\", \"message\": \"Unknown operation.\" }";
    }

    outFile.close();
}