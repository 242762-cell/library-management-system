#ifndef ISSUEQUEUE_H
#define ISSUEQUEUE_H

#include <ostream>
#include <string>
#include <list>

struct IssueRecord {
    int bookId;
    int memberId;
    std::string issueDate; // YYYY-MM-DD
};

class IssueQueue {
private:
    std::list<IssueRecord> issuedBooks;

public:
    IssueQueue();
    ~IssueQueue();

    void issueBook(IssueRecord record);
    bool returnBook(int bookId);
    void displayIssuedBooks(std::ostream& os, bool sorted);

    void execute(const char* inputFile, const char* resultFile, const char* dataFile);
    void loadFromFile(const char* dataFile);
    void saveToFile(const char* dataFile);
};

#endif // ISSUEQUEUE_H