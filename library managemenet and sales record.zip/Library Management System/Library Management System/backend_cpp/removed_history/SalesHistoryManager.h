#ifndef SALESHISTORYMANAGER_H
#define SALESHISTORYMANAGER_H

#include <string>
#include <ostream>
#include "SalesList.h"

class SalesHistoryManager {
private:
    std::string historyPath;
    // helpers (internal)
    std::string readFileStr(const std::string &path);
    bool writeJsonArrayFile(const std::string &path, const std::vector<std::string> &objs);
    std::vector<std::string> extractObjects(const std::string &content);
    int parseIntField(const std::string &obj, const std::string &key, int defaultVal=0);
    double parseDoubleField(const std::string &obj, const std::string &key, double defaultVal=0.0);
    std::string parseStringField(const std::string &obj, const std::string &key);
public:
    SalesHistoryManager(const std::string &historyFile);

    // Record an operation: "add" or "delete" with sale and user info
    bool recordOperation(const std::string &opType, const Sale &s, const std::string &user="system");

    // List history into given ostream as JSON
    bool listHistory(std::ostream &os);

    // Undo last operation. Returns true on success and emits JSON result to os
    bool undoLast(SalesList &sales, const char* dataFile, std::ostream &os);

    // Recover a deleted sale by id (searches history for delete entry)
    bool recoverById(SalesList &sales, int id, const char* dataFile, std::ostream &os);
};

#endif // SALESHISTORYMANAGER_H