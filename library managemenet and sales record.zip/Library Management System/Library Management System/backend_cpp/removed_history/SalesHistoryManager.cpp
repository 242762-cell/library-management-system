#include "SalesHistoryManager.h"
#include "../util/FileUtils.h"
#include <fstream>
#include <sstream>
#include <ctime>
#include <vector>
#include <algorithm>

using namespace std;

// --- Small JSON-lite helpers (kept local and simple) ---
string SalesHistoryManager::readFileStr(const string &path) {
    ifstream f(path);
    if (!f.is_open()) return "";
    return string((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
}
vector<string> SalesHistoryManager::extractObjects(const string &content) {
    vector<string> objs; size_t idx=0;
    while (true) {
        size_t s = content.find('{', idx); if (s==string::npos) break;
        size_t e = content.find('}', s); if (e==string::npos) break;
        string o = content.substr(s, e-s+1);
        size_t a=0; while (a<o.size() && isspace((unsigned char)o[a])) a++; size_t b=o.size(); while (b>a && isspace((unsigned char)o[b-1])) b--; objs.push_back(o.substr(a,b-a)); idx = e+1;
    }
    return objs;
}
int SalesHistoryManager::parseIntField(const string& obj, const string& key, int defaultVal) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length();
    while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart;
    while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-')) ++numEnd;
    try { return stoi(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}
double SalesHistoryManager::parseDoubleField(const string& obj, const string& key, double defaultVal) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length();
    while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart;
    while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-' || obj[numEnd]=='.')) ++numEnd;
    try { return stod(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}
string SalesHistoryManager::parseStringField(const string& obj, const string& key) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return "";
    size_t start = obj.find('"', pos + key.length());
    if (start == string::npos) return "";
    size_t end = obj.find('"', start + 1);
    if (end == string::npos) return "";
    return obj.substr(start + 1, end - start - 1);
}

bool SalesHistoryManager::writeJsonArrayFile(const string &path, const vector<string> &objs) {
    string out = "[\n";
    for (size_t i=0;i<objs.size();++i) { out += "  " + objs[i]; if (i+1!=objs.size()) out += ",\n"; else out += "\n"; }
    out += "]\n";
    return writeWithBackup(path, out);
}

SalesHistoryManager::SalesHistoryManager(const string &historyFile) : historyPath(historyFile) {}

bool SalesHistoryManager::recordOperation(const string &opType, const Sale &s, const string &user) {
    string content = readFileStr(historyPath);
    auto objs = extractObjects(content);

    // build history object
    time_t t = time(nullptr);
    char buf[64]; string timestr;
    if (struct tm* lt = localtime(&t)) { if (strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", lt)) timestr = buf; }
    if (timestr.empty()) timestr = to_string((long long)t);

    ostringstream o;
    o << "{ \"op\": \"" << opType << "\", \"time\": \"" << timestr << "\", \"user\": \"" << user << "\", \"sale\": { \"id\": " << s.id << ", \"bookId\": " << s.bookId << ", \"amount\": " << s.amount << ", \"date\": \"" << s.date << "\"";
    if (!s.title.empty()) o << ", \"title\": \"" << s.title << "\"";
    if (!s.author.empty()) o << ", \"author\": \"" << s.author << "\"";
    o << " } }";

    objs.push_back(o.str());
    return writeJsonArrayFile(historyPath, objs);
}

bool SalesHistoryManager::listHistory(ostream &os) {
    string content = readFileStr(historyPath);
    if (content.empty()) { os << "{ \"status\": \"success\", \"data\": [] }"; return true; }
    // content is expected to be an array already
    os << "{ \"status\": \"success\", \"data\": " << content << " }";
    return true;
}

// Extract sale subobject string from a history object string
static string extractSaleObj(const string &histObj) {
    size_t pos = histObj.find("\"sale\":");
    if (pos == string::npos) return "";
    size_t s = histObj.find('{', pos);
    if (s == string::npos) return "";
    size_t e = histObj.find('}', s);
    if (e == string::npos) return "";
    return histObj.substr(s, e-s+1);
}

bool SalesHistoryManager::undoLast(SalesList &sales, const char* dataFile, ostream &os) {
    string content = readFileStr(historyPath);
    auto objs = extractObjects(content);
    if (objs.empty()) { os << "{ \"status\": \"error\", \"message\": \"No history to undo.\" }"; return false; }

    string last = objs.back();
    string op = parseStringField(last, "\"op\":");
    string saleObj = extractSaleObj(last);
    if (saleObj.empty()) { os << "{ \"status\": \"error\", \"message\": \"Malformed history entry.\" }"; return false; }

    Sale s{};
    s.id = parseIntField(saleObj, "\"id\":", 0);
    s.bookId = parseIntField(saleObj, "\"bookId\":", 0);
    s.amount = parseDoubleField(saleObj, "\"amount\":", 0.0);
    s.date = parseStringField(saleObj, "\"date\":");
    s.title = parseStringField(saleObj, "\"title\":");
    s.author = parseStringField(saleObj, "\"author\":");

    bool ok = false;
    if (op == "add") {
        // undo add -> delete sale with same id
        ok = sales.deleteSale(s.id);
        if (ok) sales.saveToFile(dataFile);
    } else if (op == "delete") {
        // undo delete -> re-add sale with original id
        sales.addSaleWithId(s);
        ok = true;
        sales.saveToFile(dataFile);
    } else {
        os << "{ \"status\": \"error\", \"message\": \"Unsupported op for undo: " << op << "\" }";
        return false;
    }

    if (!ok) { os << "{ \"status\": \"error\", \"message\": \"Undo failed (operation may be inconsistent).\" }"; return false; }

    // remove last entry and write history
    objs.pop_back();
    if (!writeJsonArrayFile(historyPath, objs)) { os << "{ \"status\": \"error\", \"message\": \"Failed to update history file after undo.\" }"; return false; }

    os << "{ \"status\": \"success\", \"message\": \"Undo completed successfully.\" }";
    return true;
}

bool SalesHistoryManager::recoverById(SalesList &sales, int id, const char* dataFile, ostream &os) {
    string content = readFileStr(historyPath);
    auto objs = extractObjects(content);
    // search from end for delete of id
    for (int i = (int)objs.size()-1; i >= 0; --i) {
        string op = parseStringField(objs[i], "\"op\":");
        string saleObj = extractSaleObj(objs[i]);
        if (op == "delete" && !saleObj.empty()) {
            int sid = parseIntField(saleObj, "\"id\":", 0);
            if (sid == id) {
                Sale s{};
                s.id = sid;
                s.bookId = parseIntField(saleObj, "\"bookId\":", 0);
                s.amount = parseDoubleField(saleObj, "\"amount\":", 0.0);
                s.date = parseStringField(saleObj, "\"date\":");
                s.title = parseStringField(saleObj, "\"title\":");
                s.author = parseStringField(saleObj, "\"author\":");
                // re-insert
                sales.addSaleWithId(s);
                sales.saveToFile(dataFile);
                // optionally append a history entry for 'recover'
                recordOperation("recover", s, "system");
                os << "{ \"status\": \"success\", \"message\": \"Recovered sale id: " << id << "\" }";
                return true;
            }
        }
    }
    os << "{ \"status\": \"error\", \"message\": \"No deleted sale found with id: " << id << "\" }";
    return false;
}