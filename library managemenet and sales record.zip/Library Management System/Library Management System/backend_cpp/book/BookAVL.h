#ifndef BOOKAVL_H
#define BOOKAVL_H

#include <string>
#include <vector>
#include "Book.h" // for Book struct

struct AVLNode {
    Book data;
    AVLNode* left;
    AVLNode* right;
    int height;
    AVLNode(const Book& b) : data(b), left(nullptr), right(nullptr), height(1) {}
};

class BookAVL {
private:
    AVLNode* root;
    void clearNode(AVLNode* node);
    int height(AVLNode* node);
    int balanceFactor(AVLNode* node);
    AVLNode* rotateRight(AVLNode* y);
    AVLNode* rotateLeft(AVLNode* x);
    AVLNode* insertNode(AVLNode* node, const Book& b);
    AVLNode* minValueNode(AVLNode* node);
    AVLNode* removeNode(AVLNode* node, int bookId);
    AVLNode* findNode(AVLNode* node, int bookId);
    void inorderNode(AVLNode* node, std::vector<Book>& out);
public:
    BookAVL();
    ~BookAVL();
    void clear();
    void insert(const Book& b);
    bool contains(int bookId);
    void remove(int bookId);
    std::vector<Book> inorder();
};

#endif // BOOKAVL_H
