#include "BookService.h"
#include "../util/FileUtils.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cctype>

using namespace std;

// small parsing helpers
static int parseIntField(const string& obj, const string& key, int defaultVal = 0) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length(); while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart; while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-')) ++numEnd;
    try { return stoi(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}
static string parseStringField(const string& obj, const string& key) {
    size_t pos = obj.find(key); if (pos == string::npos) return "";
    size_t start = obj.find('"', pos + key.length()); if (start == string::npos) return "";
    size_t end = obj.find('"', start + 1); if (end == string::npos) return "";
    return obj.substr(start + 1, end - start - 1);
}

BookService::BookService() {}
BookService::~BookService() { avl.clear(); }

void BookService::loadFromFile(const char* dataFile) {
    ifstream file(dataFile);
    if (!file.is_open()) return;
    avl.clear();
    string line;
    while (getline(file, line)) {
        if (line.find("{") != string::npos) {
            string obj = line;
            while (obj.find("}") == string::npos && getline(file, line)) obj += " " + line;
            Book book;
            book.id = parseIntField(obj, "\"id\":", 0);
            book.title = parseStringField(obj, "\"title\":");
            book.author = parseStringField(obj, "\"author\":");
            avl.insert(book);
        }
    }
    file.close();
}

void BookService::saveToFile(const char* dataFile) {
    ostringstream out;
    out << "[\n";
    vector<Book> v = avl.inorder();
    for (size_t i = 0; i < v.size(); ++i) {
        out << "  { \"id\": " << v[i].id
            << ", \"title\": \"" << v[i].title << "\", \"author\": \"" << v[i].author << "\" }";
        if (i + 1 != v.size()) out << ",\n"; else out << "\n";
    }
    out << "]\n";
    writeWithBackup(string(dataFile), out.str());
}

void BookService::addBook(Book b) {
    avl.insert(b);
}

int BookService::searchBook(int bookId) {
    vector<Book> v = avl.inorder();
    for (size_t i = 0; i < v.size(); ++i) if (v[i].id == bookId) return (int)i;
    return -1;
}

void BookService::deleteBook(int bookId) {
    avl.remove(bookId);
}

void BookService::displayBooks(ostream& os) {
    vector<Book> v = avl.inorder();
    os << "{\n  \"status\": \"success\",\n  \"data\": [\n";
    for (size_t i = 0; i < v.size(); ++i) {
        os << "    { \"id\": " << v[i].id << ", \"title\": \"" << v[i].title << "\", \"author\": \"" << v[i].author << "\" }";
        if (i + 1 != v.size()) os << ",\n"; else os << "\n";
    }
    os << "  ]\n}\n";
}

void BookService::execute(const char* inputFile, const char* resultFile, const char* dataFile) {
    loadFromFile(dataFile);

    ifstream inFile(inputFile);
    ofstream outFile(resultFile);
    if (!inFile.is_open()) { outFile << "{ \"status\": \"error\", \"message\": \"Could not open input file.\" }"; return; }

    string jsonContent((istreambuf_iterator<char>(inFile)), istreambuf_iterator<char>());
    inFile.close();

    string operation;
    size_t op_pos = jsonContent.find("\"operation\": \"");
    if (op_pos != string::npos) { size_t start = op_pos + 14; size_t end = jsonContent.find('"', start); operation = jsonContent.substr(start, end - start); }
    if (operation.empty()) { outFile << "{ \"status\": \"error\", \"message\": \"Operation not specified.\" }"; return; }

    if (operation == "add") {
        Book newBook; newBook.id = 0; newBook.title = ""; newBook.author = "";
        size_t id_pos = jsonContent.find("\"id\":");
        size_t title_pos = jsonContent.find("\"title\": \"");
        size_t author_pos = jsonContent.find("\"author\": \"");
        if (id_pos != string::npos && title_pos != string::npos && author_pos != string::npos) {
            try { newBook.id = stoi(jsonContent.substr(id_pos + 5)); } catch(...) { newBook.id = 0; }
            size_t title_start = title_pos + 10; newBook.title = jsonContent.substr(title_start, jsonContent.find('"', title_start) - title_start);
            size_t author_start = author_pos + 11; newBook.author = jsonContent.substr(author_start, jsonContent.find('"', author_start) - author_start);
            addBook(newBook); saveToFile(dataFile);
            outFile << "{ \"status\": \"success\", \"message\": \"Book added successfully.\" }";
        } else { outFile << "{ \"status\": \"error\", \"message\": \"Invalid book data for add operation.\" }"; }
    } else if (operation == "search") {
        size_t id_pos = jsonContent.find("\"id\":");
        if (id_pos != string::npos) {
            int bookId = stoi(jsonContent.substr(id_pos + 5));
            int index = searchBook(bookId);
            if (index != -1) {
                vector<Book> v = avl.inorder();
                Book b = v[index];
                outFile << "{\n  \"status\": \"success\",\n  \"data\": {\n    \"id\": " << b.id << ",\n    \"title\": \"" << b.title << "\",\n    \"author\": \"" << b.author << "\"\n  }\n}";
            } else { outFile << "{ \"status\": \"error\", \"message\": \"Book not found.\" }"; }
        } else { outFile << "{ \"status\": \"error\", \"message\": \"ID not provided for search.\" }"; }
    } else if (operation == "delete") {
        size_t id_pos = jsonContent.find("\"id\":");
        if (id_pos != string::npos) {
            int bookId = stoi(jsonContent.substr(id_pos + 5));
            deleteBook(bookId); saveToFile(dataFile); outFile << "{ \"status\": \"success\", \"message\": \"Book deleted successfully.\" }";
        } else { outFile << "{ \"status\": \"error\", \"message\": \"ID not provided for delete.\" }"; }
    } else if (operation == "display") {
        displayBooks(outFile);
    } else { outFile << "{ \"status\": \"error\", \"message\": \"Unknown operation.\" }"; }

    outFile.close();
}
