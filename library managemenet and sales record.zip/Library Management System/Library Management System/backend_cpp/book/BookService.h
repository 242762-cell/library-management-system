#ifndef BOOKSERVICE_H
#define BOOKSERVICE_H

#include "Book.h"
#include "BookAVL.h"
#include <ostream>

class BookService {
private:
    BookAVL avl;
public:
    BookService();
    ~BookService();
    void loadFromFile(const char* dataFile);
    void saveToFile(const char* dataFile);
    void addBook(Book b);
    int searchBook(int bookId);
    void deleteBook(int bookId);
    void displayBooks(std::ostream& os);
    void execute(const char* inputFile, const char* resultFile, const char* dataFile);
};

#endif // BOOKSERVICE_H
