#include "BookAVL.h"
#include <algorithm>

BookAVL::BookAVL() : root(nullptr) {}

BookAVL::~BookAVL() { clear(); }

void BookAVL::clearNode(AVLNode* node) {
    if (!node) return;
    clearNode(node->left);
    clearNode(node->right);
    delete node;
}

void BookAVL::clear() {
    clearNode(root);
    root = nullptr;
}

int BookAVL::height(AVLNode* node) {
    return node ? node->height : 0;
}

int BookAVL::balanceFactor(AVLNode* node) {
    return node ? height(node->left) - height(node->right) : 0;
}

AVLNode* BookAVL::rotateRight(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    return x;
}

AVLNode* BookAVL::rotateLeft(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    return y;
}

AVLNode* BookAVL::insertNode(AVLNode* node, const Book& b) {
    if (!node) return new AVLNode(b);
    if (b.id < node->data.id)
        node->left = insertNode(node->left, b);
    else if (b.id > node->data.id)
        node->right = insertNode(node->right, b);
    else
        return node; // duplicate ids not allowed

    node->height = 1 + std::max(height(node->left), height(node->right));
    int bf = balanceFactor(node);

    // Left Left
    if (bf > 1 && b.id < node->left->data.id)
        return rotateRight(node);
    // Right Right
    if (bf < -1 && b.id > node->right->data.id)
        return rotateLeft(node);
    // Left Right
    if (bf > 1 && b.id > node->left->data.id) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    // Right Left
    if (bf < -1 && b.id < node->right->data.id) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

AVLNode* BookAVL::minValueNode(AVLNode* node) {
    AVLNode* current = node;
    while (current && current->left) current = current->left;
    return current;
}

AVLNode* BookAVL::removeNode(AVLNode* node, int bookId) {
    if (!node) return node;
    if (bookId < node->data.id)
        node->left = removeNode(node->left, bookId);
    else if (bookId > node->data.id)
        node->right = removeNode(node->right, bookId);
    else {
        if (!node->left || !node->right) {
            AVLNode* temp = node->left ? node->left : node->right;
            if (!temp) {
                temp = node;
                node = nullptr;
            } else {
                *node = *temp;
            }
            delete temp;
        } else {
            AVLNode* temp = minValueNode(node->right);
            node->data = temp->data;
            node->right = removeNode(node->right, temp->data.id);
        }
    }

    if (!node) return node;

    node->height = 1 + std::max(height(node->left), height(node->right));
    int bf = balanceFactor(node);

    // Left Left
    if (bf > 1 && balanceFactor(node->left) >= 0) return rotateRight(node);
    // Left Right
    if (bf > 1 && balanceFactor(node->left) < 0) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    // Right Right
    if (bf < -1 && balanceFactor(node->right) <= 0) return rotateLeft(node);
    // Right Left
    if (bf < -1 && balanceFactor(node->right) > 0) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

AVLNode* BookAVL::findNode(AVLNode* node, int bookId) {
    if (!node) return nullptr;
    if (bookId == node->data.id) return node;
    if (bookId < node->data.id) return findNode(node->left, bookId);
    return findNode(node->right, bookId);
}

void BookAVL::inorderNode(AVLNode* node, std::vector<Book>& out) {
    if (!node) return;
    inorderNode(node->left, out);
    out.push_back(node->data);
    inorderNode(node->right, out);
}

void BookAVL::insert(const Book& b) {
    root = insertNode(root, b);
}

bool BookAVL::contains(int bookId) {
    return findNode(root, bookId) != nullptr;
}

void BookAVL::remove(int bookId) {
    root = removeNode(root, bookId);
}

std::vector<Book> BookAVL::inorder() {
    std::vector<Book> v;
    inorderNode(root, v);
    return v;
}
