#ifndef MEMBERLIST_H
#define MEMBERLIST_H

#include <ostream>
#include <string>
#include <list>
#include <algorithm> // Required for std::find_if

struct Member {
    int id;
    std::string name;
    std::string email;
};

class MemberList {
private:
    std::list<Member> members;

public:
    MemberList();
    ~MemberList();

    void addMember(Member newMember);
    std::list<Member>::iterator searchMember(int memberId);
    bool deleteMember(int memberId);
    void displayMembers(std::ostream& os);

    void execute(const char* inputFile, const char* resultFile, const char* dataFile);
    void loadFromFile(const char* dataFile);
    void saveToFile(const char* dataFile);
};

#endif // MEMBERLIST_H