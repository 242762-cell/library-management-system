#include "MemberList.h"
#include "../util/FileUtils.h"
#include <fstream>
#include <string>
#include <list>
#include <algorithm> // for std::find_if
#include <cctype>
#include <sstream>
#include <vector>

using namespace std;

// Helper: parse integer value for a given key in a JSON-like string.
static int parseIntField(const string& obj, const string& key, int defaultVal = 0) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return defaultVal;
    size_t numStart = pos + key.length();
    while (numStart < obj.size() && isspace((unsigned char)obj[numStart])) ++numStart;
    size_t numEnd = numStart;
    while (numEnd < obj.size() && (isdigit((unsigned char)obj[numEnd]) || obj[numEnd]=='-')) ++numEnd;
    try { return stoi(obj.substr(numStart, numEnd - numStart)); } catch(...) { return defaultVal; }
}

// Helper: parse a quoted string value for a given key
static string parseStringField(const string& obj, const string& key) {
    size_t pos = obj.find(key);
    if (pos == string::npos) return "";
    size_t start = obj.find('"', pos + key.length());
    if (start == string::npos) return "";
    size_t end = obj.find('"', start + 1);
    if (end == string::npos) return "";
    return obj.substr(start + 1, end - start - 1);
}

// small helpers
static string readFileStr(const string &path) {
    ifstream f(path);
    if (!f.is_open()) return "";
    return string((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
}
static vector<string> extractObjects(const string &content) {
    vector<string> objs; size_t idx=0;
    while (true) {
        size_t s = content.find('{', idx); if (s==string::npos) break;
        size_t e = content.find('}', s); if (e==string::npos) break;
        string o = content.substr(s, e-s+1);
        size_t a=0; while (a<o.size() && isspace((unsigned char)o[a])) a++; size_t b=o.size(); while (b>a && isspace((unsigned char)o[b-1])) b--; objs.push_back(o.substr(a,b-a)); idx = e+1;
    }
    return objs;
}
// Constructor and Destructor
MemberList::MemberList() {}
MemberList::~MemberList() {}

// Load members from a JSON-like file
void MemberList::loadFromFile(const char* dataFile) {
    string content = readFileStr(dataFile);
    members.clear();
    if (content.empty()) return;
    auto objs = extractObjects(content);
    for (auto &o : objs) {
        Member m{};
        m.id = parseIntField(o, "\"id\":", 0);
        m.name = parseStringField(o, "\"name\":");
        m.email = parseStringField(o, "\"email\":");
        members.push_back(m);
    }
}

// Save members to a JSON-like file
void MemberList::saveToFile(const char* dataFile) {
    ostringstream out;
    out << "[\n";
    int idx = 0;
    int n = members.size();
    for (auto it = members.begin(); it != members.end(); ++it, ++idx) {
        const Member& m = *it;
        out << "  { \"id\": " << m.id
            << ", \"name\": \"" << m.name
            << "\", \"email\": \"" << m.email << "\" }";
        if (idx + 1 < n) out << ",\n"; else out << "\n";
    }
    out << "]\n";
    writeWithBackup(string(dataFile), out.str());
}

// Add a member to the list
void MemberList::addMember(Member newMember) {
    members.push_back(newMember);
}

// Search for a member by ID
list<Member>::iterator MemberList::searchMember(int memberId) {
    return find_if(members.begin(), members.end(), 
        [memberId](const Member& m) {
            return m.id == memberId;
        });
}

// Delete a member by ID
bool MemberList::deleteMember(int memberId) {
    auto it = searchMember(memberId);
    if (it != members.end()) {
        members.erase(it);
        return true;
    }
    return false;
}

// Display all members in a JSON format
void MemberList::displayMembers(ostream& os) {
    os << "{\n  \"status\": \"success\",\n  \"data\": [\n";
    int i = 0;
    int n = members.size();
    for (auto it = members.begin(); it != members.end(); ++it, ++i) {
        const Member& m = *it;
        os << "    { \"id\": " << m.id
           << ", \"name\": \"" << m.name
           << "\", \"email\": \"" << m.email << "\" }";
        if (i + 1 < n) os << ",\n"; else os << "\n";
    }
    os << "  ]\n";
    os << "}\n";
}

// Main execution logic
void MemberList::execute(const char* inputFile, const char* resultFile, const char* dataFile) {
    loadFromFile(dataFile);

    ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        ofstream out(resultFile);
        out << "{ \"status\": \"error\", \"message\": \"Could not open input file.\" }";
        return;
    }

    string json((istreambuf_iterator<char>(inFile)), istreambuf_iterator<char>());
    inFile.close();

    string op;
    size_t p = json.find("\"operation\": \"");
    if (p != string::npos) {
        size_t s = p + 14;
        size_t e = json.find("\"", s);
        op = json.substr(s, e - s);
    }

    ofstream out(resultFile);
    if (op.empty()) {
        out << "{ \"status\": \"error\", \"message\": \"Operation not specified.\" }";
        return;
    }

    if (op == "add") {
        int id = parseIntField(json, "\"id\":", -1);
        string name = parseStringField(json, "\"name\":");
        string email = parseStringField(json, "\"email\":");
        if (id != -1 && !name.empty() && !email.empty()) {
            Member m; m.id = id; m.name = name; m.email = email;
            addMember(m);
            saveToFile(dataFile);
            out << "{ \"status\": \"success\", \"message\": \"Member added successfully.\" }";
        } else {
            out << "{ \"status\": \"error\", \"message\": \"Invalid member data for add operation.\" }";
        }

    } else if (op == "search") {
        int id = parseIntField(json, "\"id\":", -1);
        if (id != -1) {
            auto it = searchMember(id);
            if (it != members.end()) {
                out << "{\n  \"status\": \"success\",\n  \"data\": {\n"
                    << "    \"id\": " << it->id << ",\n"
                    << "    \"name\": \"" << it->name << "\",\n"
                    << "    \"email\": \"" << it->email << "\"\n  }\n}";
            } else {
                out << "{ \"status\": \"error\", \"message\": \"Member not found.\" }";
            }
        } else {
            out << "{ \"status\": \"error\", \"message\": \"ID not provided for search.\" }";
        }

    } else if (op == "delete") {
        int id = parseIntField(json, "\"id\":", -1);
        if (id != -1) {
            if (deleteMember(id)) {
                saveToFile(dataFile);
                out << "{ \"status\": \"success\", \"message\": \"Member deleted successfully.\" }";
            } else {
                out << "{ \"status\": \"error\", \"message\": \"Member not found for deletion.\" }";
            }
        } else {
            out << "{ \"status\": \"error\", \"message\": \"ID not provided for delete.\" }";
        }

    } else if (op == "display") {
        displayMembers(out);

    } else {
        out << "{ \"status\": \"error\", \"message\": \"Unknown operation.\" }";
    }

    out.close();
}
