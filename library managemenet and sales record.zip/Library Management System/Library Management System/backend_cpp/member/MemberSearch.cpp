#include "MemberList.h"
#include <fstream>
#include <cstdlib>

using namespace std;

// Compatibility wrapper: expose simple functions while using MemberList internally.
static MemberList membersDb;

void loadMembers() {
    // Load members from JSON-like data file used by the backend
    membersDb.loadFromFile("data/members_data.json");
}

void saveMembers() {
    // Persist members to JSON-like data file
    membersDb.saveToFile("data/members_data.json");
}

// Old signature compatibility: id is a string representation of number
void addMember(char id[], char name[]) {
    Member m;
    m.id = atoi(id);
    m.name = string(name);
    m.email = "";
    membersDb.addMember(m);
}
