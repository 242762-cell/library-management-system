#ifndef FILE_UTILS_H
#define FILE_UTILS_H

#include <string>

bool writeWithBackup(const std::string& path, const std::string& content);

#endif // FILE_UTILS_H
