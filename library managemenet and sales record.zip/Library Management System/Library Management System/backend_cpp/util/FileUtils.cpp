#include "FileUtils.h"
#include <fstream>
#include <string>
#include <iterator>
#include <cctype>

using namespace std;

bool writeWithBackup(const std::string& path, const std::string& content) {
    std::ifstream r(path);
    std::string existing;
    if (r.is_open()) {
        existing.assign((std::istreambuf_iterator<char>(r)), std::istreambuf_iterator<char>());
        r.close();
        std::ofstream bak(path + ".bak");
        if (bak.is_open()) { bak << existing; bak.close(); }
    }
    std::ofstream w(path);
    if (!w.is_open()) return false;
    w << content;
    w.close();
    int openBraces = 0, closeBraces = 0;
    for (char ch : content) { if (ch == '{') openBraces++; if (ch == '}') closeBraces++; }
    if (openBraces != closeBraces) {
        std::ifstream bak(path + ".bak");
        if (bak.is_open()) {
            std::string backContent((std::istreambuf_iterator<char>(bak)), std::istreambuf_iterator<char>());
            bak.close();
            std::ofstream restore(path);
            if (restore.is_open()) { restore << backContent; restore.close(); }
        }
        return false;
    }
    return true;
}
