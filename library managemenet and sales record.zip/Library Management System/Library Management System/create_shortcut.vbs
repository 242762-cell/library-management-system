Set WshShell = WScript.CreateObject("WScript.Shell")
desktop = WshShell.SpecialFolders("Desktop")
Set shortcut = WshShell.CreateShortcut(desktop & "\Run Library Management System.lnk")
shortcut.TargetPath = "C:\Windows\System32\cmd.exe"
shortcut.Arguments = "/k ""C:\Users\user\Desktop\Library Management System\Library Management System\run_with_jdk17.bat"""
shortcut.WorkingDirectory = "C:\Users\user\Desktop\Library Management System\Library Management System"
shortcut.IconLocation = "C:\Windows\System32\shell32.dll, 4"
shortcut.Save
WScript.Echo "Shortcut created on Desktop"
