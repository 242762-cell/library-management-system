@echo off
echo ==========================================
echo 1. Compiling C++ Backend...
echo ==========================================
g++ -o backend_cpp/main.exe backend_cpp/main.cpp backend_cpp/book/BookService.cpp backend_cpp/book/BookAVL.cpp backend_cpp/member/MemberList.cpp backend_cpp/issue_return/IssueQueue.cpp backend_cpp/sales/SalesList.cpp backend_cpp/util/FileUtils.cpp -std=c++11

IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] C++ Compilation Failed! Please check if MinGW/g++ is installed.
    pause
    exit /b %ERRORLEVEL%
)

IF NOT EXIST "backend_cpp\main.exe" (
    echo.
    echo [ERROR] main.exe was not created! Compilation failed silently?
    pause
    exit /b 1
)

echo ==========================================
echo 2. Compiling Java Frontend...
echo ==========================================
javac -cp ".;frontend_java/lib/gson.jar" -d . frontend_java/src/app/Main.java frontend_java/src/app/Modules/*.java frontend_java/src/app/util/*.java frontend_java/src/app/Components/*.java frontend_java/src/app/models/*.java

echo ==========================================
echo 3. Running Application...
echo ==========================================
java -cp ".;frontend_java/lib/gson.jar" app.Main