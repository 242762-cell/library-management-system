@echo off
REM Wrapper to set Java 17 and run the project's run_project.bat
setlocal
set "JAVA_HOME=C:\Program Files\Java\jdk-17"
set "PATH=%JAVA_HOME%\bin;%PATH%"
cd /d "%~dp0"
echo Using JAVA_HOME=%JAVA_HOME%
call "%~dp0run_project.bat"
endlocal

npause