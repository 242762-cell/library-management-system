import java.nio.file.*;
import java.nio.charset.StandardCharsets;
public class WriteJson {
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java WriteJson <json-string>");
            return;
        }
        String s = args[0];
        Files.write(Paths.get("frontend_java/data/book.json"), s.getBytes(StandardCharsets.UTF_8));
        System.out.println("Wrote book.json");
    }
}