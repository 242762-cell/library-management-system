import java.nio.file.*;
import java.nio.charset.StandardCharsets;
public class WriteBookSearch {
    public static void main(String[] args) throws Exception {
        String s = "{ \"operation\": \"search\", \"id\": 101 }";
        Files.write(Paths.get("frontend_java/data/book.json"), s.getBytes(StandardCharsets.UTF_8));
        System.out.println("Wrote search JSON");
    }
}