package app.Modules;

import app.util.JsonHandler;
import app.util.PathsUtil;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class IssueReturnModule extends JPanel {

    private final app.util.PlaceholderTextField bookIdField = new app.util.PlaceholderTextField(12);
    private final app.util.PlaceholderTextField memberIdField = new app.util.PlaceholderTextField(12);

    private String dataPath;
    private String resultJsonPath;
    private final String backendExecutablePath = "backend_cpp/main.exe";

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new Object[]{"Book ID","Member ID","Issue Date","Status"},0);

    private final JTable issueTable = new JTable(tableModel);

    private JButton issueBtn;
    private JButton returnBtn;
    private JButton listBtn;
    private JButton sortBtn;

    public IssueReturnModule() {

        try {
            dataPath = PathsUtil.dataPath();
            resultJsonPath = dataPath + "result.json";
            System.out.println("DATA PATH = " + dataPath);
        } catch (Exception e) {
            throw new RuntimeException("Cannot resolve data path", e);
        }

        setLayout(new BorderLayout(10,10));
        app.util.UITheme.stylePanel(this);
        add(createFormPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
    }

    private JPanel createFormPanel() {

        JPanel panel = new JPanel(new GridBagLayout());
        app.util.UITheme.stylePanel(panel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6,6,6,6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx=0; gbc.gridy=0;
        panel.add(new JLabel("Book ID"), gbc);
        gbc.gridx=1;
        panel.add(bookIdField, gbc);

        gbc.gridx=0; gbc.gridy=1;
        panel.add(new JLabel("Member ID"), gbc);
        gbc.gridx=1;
        panel.add(memberIdField, gbc);

        JPanel btnPanel = new JPanel();
        app.util.UITheme.stylePanel(btnPanel);

        issueBtn  = createButton("Issue Book"); issueBtn.setToolTipText("Issue book to member");
        returnBtn = createButton("Return Book"); returnBtn.setToolTipText("Return an issued book");
        listBtn   = createButton("List Issued Books"); listBtn.setToolTipText("Show all issued books");
        sortBtn   = createButton("Sort by Book ID"); sortBtn.setToolTipText("Sort issued list by Book ID");

        btnPanel.add(issueBtn);
        btnPanel.add(returnBtn);
        btnPanel.add(listBtn);
        btnPanel.add(sortBtn);

        // Style text fields and bind Enter: if both present -> issue, if only book present -> return
        bookIdField.setPlaceholder("Book ID");
        memberIdField.setPlaceholder("Member ID");
        app.util.UITheme.styleTextField(bookIdField);
        app.util.UITheme.styleTextField(memberIdField);

        bookIdField.addActionListener(e -> {
            if (!memberIdField.getText().isEmpty()) issueBtn.doClick();
            else returnBtn.doClick();
        });
        memberIdField.addActionListener(e -> {
            if (!bookIdField.getText().isEmpty()) issueBtn.doClick();
        });

        issueBtn.addActionListener(e -> perform("issue"));
        returnBtn.addActionListener(e -> perform("return"));
        listBtn.addActionListener(e -> perform("display"));
        sortBtn.addActionListener(e -> perform("display_sorted"));

        gbc.gridx=0; gbc.gridy=2; gbc.gridwidth=2;
        panel.add(btnPanel, gbc);

        return panel;
    }

    private JScrollPane createTablePanel() {
        app.util.UITheme.styleTable(issueTable);
        return new JScrollPane(issueTable);
    }

    private JButton createButton(String text) {
        switch (text) {
            case "Issue Book": return app.util.UITheme.createIconButton("[Issue]","Issue Book", true);
            case "Return Book": return app.util.UITheme.createIconButton("[Return]","Return Book", false);
            case "List Issued Books": return app.util.UITheme.createIconButton("[List]","List Issued Books", false);
            case "Sort by Book ID": return app.util.UITheme.createIconButton("[Sort]","Sort by Book ID", false);
            default: return app.util.UITheme.createButton(text);
        }
    }

    private void perform(String operation) {

        setButtons(false);

        new SwingWorker<Void,Void>() {

            String err = null;

            @Override
            protected Void doInBackground() {

                try {
                    String json;

                    switch (operation) {

                        case "issue": {
                            if (bookIdField.getText().isEmpty() || memberIdField.getText().isEmpty())
                                throw new IllegalArgumentException("Book ID & Member ID required");

                            int bId = Integer.parseInt(bookIdField.getText());
                            int mId = Integer.parseInt(memberIdField.getText());

                            String date = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
                            json = JsonHandler.createIssueJson(operation, bId, mId, date);
                            break;
                        }

                        case "return": {
                            if (bookIdField.getText().isEmpty())
                                throw new IllegalArgumentException("Book ID required");

                            int bId = Integer.parseInt(bookIdField.getText());
                            json = JsonHandler.createIssueJson(operation, bId);
                            break;
                        }

                        case "display":
                        case "display_sorted":
                            json = JsonHandler.createIssueJson(operation);
                            break;

                        default:
                            throw new IllegalArgumentException("Invalid operation");
                    }

                    try (FileWriter fw = new FileWriter(dataPath + "issue.json")) {
                        fw.write(json);
                    }

                    Process p = new ProcessBuilder(
                            backendExecutablePath, "issue", operation
                    ).directory(new File(".")).start();

                    if (p.waitFor() != 0)
                        err = "Backend failed";

                } catch (Exception ex) {
                    err = ex.getMessage();
                }

                return null;
            }

            @Override
            protected void done() {

                if (err != null) show(err);
                else {
                    refresh();
                    bookIdField.setText("");
                    memberIdField.setText("");
                    show("Operation completed");
                }

                setButtons(true);
            }

        }.execute();
    }

    private void refresh() {
        try {
            tableModel.setRowCount(0);

            for (var r : JsonHandler.parseIssueList(resultJsonPath)) {
                tableModel.addRow(new Object[]{
                        r.getBookId(),
                        r.getMemberId(),
                        r.getIssueDate(),
                        r.getStatus()
                });
            }

        } catch (Exception e) {
            show("Error loading issue list: " + e.getMessage());
        }
    }

    private void setButtons(boolean enabled) {
        issueBtn.setEnabled(enabled);
        returnBtn.setEnabled(enabled);
        listBtn.setEnabled(enabled);
        sortBtn.setEnabled(enabled);
    }

    private void show(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Issue/Return", JOptionPane.INFORMATION_MESSAGE);
    }
}
