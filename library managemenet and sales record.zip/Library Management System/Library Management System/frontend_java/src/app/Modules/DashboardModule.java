package app.Modules;

import app.util.JsonHandler;
import app.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Dashboard module with KPI cards and a large chart area. Works without external libraries.
 */
public class DashboardModule extends JPanel {

    public DashboardModule() {
        setLayout(new BorderLayout(12,12));
        UITheme.stylePanel(this);

        // Hero banner (large orange card)
        // Hero banner using RoundedCard with left text and right illustration placeholder
        app.Components.RoundedCard hero = new app.Components.RoundedCard(18,10);
        hero.setLayout(new BorderLayout());
        hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));
        hero.setBackground(UITheme.ACCENT);
        hero.setBorder(BorderFactory.createEmptyBorder(12,14,12,14));

        JPanel heroText = new JPanel(new BorderLayout()); heroText.setOpaque(false);
        // Use HTML label to allow wrapping and responsive width
        JLabel heroTitle = new JLabel("<html><div style='width:620px'><b>Keep track of everything your library has in it</b></div></html>");
        heroTitle.setForeground(Color.WHITE);
        heroTitle.setFont(UITheme.TITLE_FONT.deriveFont(Font.BOLD, 18f));
        heroText.add(heroTitle, BorderLayout.NORTH);
        JLabel heroSub = new JLabel("<html><div style='width:620px'>Beautifully track books, members, and interactions with a modern dashboard.</div></html>");
        heroSub.setForeground(new Color(255,235,225)); heroSub.setFont(UITheme.DEFAULT_FONT.deriveFont(12f));
        heroText.add(heroSub, BorderLayout.CENTER);

        // CTA removed (non-functional) to match mockup and reduce clutter

        // hero text only — illustration removed as requested
        hero.add(heroText, BorderLayout.CENTER);
        add(hero, BorderLayout.NORTH);

        // KPI strip below hero (use FlowLayout to avoid grid Wrapping artifacts)
        JPanel topStrip = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 8));
        topStrip.setOpaque(false);
        topStrip.setBorder(BorderFactory.createEmptyBorder(12,8,12,8));

        // enforce sizes on KPI cards so FlowLayout is stable
        app.Components.RoundedCard k0 = (app.Components.RoundedCard) buildKpiCard("Active Members", "—", 0);
        app.Components.RoundedCard k1 = (app.Components.RoundedCard) buildKpiCard("New Books", "—", 0);
        app.Components.RoundedCard k2 = (app.Components.RoundedCard) buildKpiCard("Total Books", "—", 0);
        app.Components.RoundedCard k3 = (app.Components.RoundedCard) buildKpiCard("Borrowing Peak", "—", 0);
        k0.setPreferredSize(new Dimension(220,90)); k1.setPreferredSize(new Dimension(220,90)); k2.setPreferredSize(new Dimension(220,90)); k3.setPreferredSize(new Dimension(220,90));

        topStrip.add(k0); topStrip.add(k1); topStrip.add(k2); topStrip.add(k3);

        // put topStrip into a center panel so it stays above the main content
        JPanel centerPanel = new JPanel(new BorderLayout()); centerPanel.setOpaque(false);
        centerPanel.add(topStrip, BorderLayout.NORTH);

        // Main content area: left = stock card, center = large chart, right = widgets
        JPanel main = new JPanel(new BorderLayout(12,12));
        main.setOpaque(false);
        centerPanel.add(main, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // left column with Stock card
        JPanel leftCol = new JPanel(); leftCol.setOpaque(false); leftCol.setLayout(new BoxLayout(leftCol, BoxLayout.Y_AXIS));
        leftCol.setPreferredSize(new Dimension(320, 0));
        leftCol.add(makeStockCard());
        leftCol.add(Box.createRigidArea(new Dimension(0,12)));

        main.add(leftCol, BorderLayout.WEST);

        // center chart (wider)
        // center chart (wider)
        this.chartPanel = new ChartPanel();
        chartPanel.setPreferredSize(new Dimension(680, 420));
        main.add(chartPanel, BorderLayout.CENTER);

        // right column: circular summary and messages below
        JPanel rightCol = new JPanel(); rightCol.setOpaque(false); rightCol.setLayout(new BoxLayout(rightCol, BoxLayout.Y_AXIS));
        rightCol.setPreferredSize(new Dimension(300,0));

        app.Components.RoundedCard circleCard = new app.Components.RoundedCard(8,6);
        circleCard.setLayout(new BorderLayout());
        circleCard.setPreferredSize(new Dimension(280,200));
        JLabel t = new JLabel("Library Health"); t.setForeground(new Color(200,200,205)); t.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD));
        circleCard.add(t, BorderLayout.NORTH);

        // create two circular charts: borrowed books and members with issues
        ccBooks = new app.Components.CircularChart();
        ccMembers = new app.Components.CircularChart();

        // set initial values (will be updated by timer)
        int totalBooks = JsonHandler.parseBooks("frontend_java/data/books_data.json").size();
        if (totalBooks == 0) totalBooks = JsonHandler.parseBooks("data/books_data.json").size();
        int borrowed = 0; // Issue module removed: no borrowed data available

        int totalMembers = JsonHandler.parseMemberList("frontend_java/data/members_data.json").size();
        if (totalMembers == 0) totalMembers = JsonHandler.parseMemberList("data/members_data.json").size();

        java.util.Set<Integer> membersWithIssues = new java.util.HashSet<>();

        // configure charts to show Remaining inside and auto-generate legend (Total / Remaining)
        ccBooks.setDisplayAsRemaining(true);
        ccBooks.setAutoLegend(true, "Total Books", "Remaining");
        ccBooks.setAutoColor(true);
        ccBooks.setData(borrowed, Math.max(1, totalBooks), "Remaining", UITheme.ACCENT);
        ccBooks.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                // open Books tab
                java.awt.Window w = SwingUtilities.getWindowAncestor(DashboardModule.this);
                if (w instanceof JFrame) {
                    Container content = ((JFrame) w).getContentPane();
                    for (Component c : content.getComponents()) {
                        if (c instanceof JTabbedPane) {
                            JTabbedPane tabs = (JTabbedPane) c;
                            for (int ti=0; ti<tabs.getTabCount(); ti++) {
                                if (tabs.getTitleAt(ti).equalsIgnoreCase("books")) { tabs.setSelectedIndex(ti); return; }
                            }
                        }
                    }
                }
            }
        });

        ccMembers.setDisplayAsRemaining(true);
        ccMembers.setAutoLegend(true, "Total Members", "Remaining");
        ccMembers.setAutoColor(true);
        ccMembers.setData(membersWithIssues.size(), Math.max(1, totalMembers), "Remaining", UITheme.ACCENT.brighter());
        ccMembers.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                // open Members tab
                java.awt.Window w = SwingUtilities.getWindowAncestor(DashboardModule.this);
                if (w instanceof JFrame) {
                    Container content = ((JFrame) w).getContentPane();
                    for (Component c : content.getComponents()) {
                        if (c instanceof JTabbedPane) {
                            JTabbedPane tabs = (JTabbedPane) c;
                            for (int ti=0; ti<tabs.getTabCount(); ti++) {
                                if (tabs.getTitleAt(ti).equalsIgnoreCase("members")) { tabs.setSelectedIndex(ti); return; }
                            }
                        }
                    }
                }
            }
        });

        // add control buttons (demo toggle + settings)
        JPanel headerRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6)); headerRow.setOpaque(false);
        JButton demoToggle = new JButton("Simulate");
        JButton resetBtn = new JButton("Reset");
        JButton settings = new JButton("⚙"); settings.setPreferredSize(new Dimension(28,28));
        headerRow.add(resetBtn); headerRow.add(demoToggle); headerRow.add(settings);
        circleCard.add(headerRow, BorderLayout.SOUTH);

        JPanel ccWrap = new JPanel(new GridLayout(1,2,12,0)); ccWrap.setOpaque(false);
        ccWrap.add(ccBooks); ccWrap.add(ccMembers);
        circleCard.add(ccWrap, BorderLayout.CENTER);

        // Poll for changes every 1500ms and animate charts when values change (disabled while simulating)
        dataTimer = new javax.swing.Timer(1500, ev -> updateChartsFromData());
        dataTimer.setRepeats(true);
        dataTimer.start();

        // Demo simulator
        javax.swing.Timer demoTimer = new javax.swing.Timer(1000, null);
        final boolean[] simulating = new boolean[]{false};
        demoTimer.addActionListener(ev -> {
            // small random perturbation around current totals
            int tb = Math.max(100, JsonHandler.parseBooks("frontend_java/data/books_data.json").size());
            int tm = Math.max(10, JsonHandler.parseMemberList("frontend_java/data/members_data.json").size());
            int bd = Math.max(0, ccBooks==null?0:ccBooks.getDisplayedValue());
            int mm = Math.max(0, ccMembers==null?0:ccMembers.getDisplayedValue());

            int addBorrowed = (int)Math.round((Math.random()-0.3) * Math.max(1, tb * 0.03));
            bd = Math.max(0, Math.min(tb, bd + addBorrowed));
            int addMembers = (int)Math.round((Math.random()-0.4) * Math.max(1, tm * 0.02));
            mm = Math.max(0, Math.min(tm, mm + addMembers));

            ccBooks.setData(bd, tb, "Borrowed", UITheme.ACCENT);
            ccMembers.setData(mm, tm, "Members", UITheme.ACCENT.brighter());

            // KPIs
            setKpiText(0, Integer.toString(tm));
            setKpiText(1, Integer.toString(tb));
            setKpiText(2, Integer.toString(tb));
        });

        demoToggle.addActionListener(e -> {
            simulating[0] = !simulating[0];
            if (simulating[0]) {
                demoToggle.setText("Stop");
                dataTimer.stop();
                demoTimer.start();
            } else {
                demoToggle.setText("Simulate");
                demoTimer.stop();
                dataTimer.start();
                updateChartsFromData();
            }
        });

        resetBtn.addActionListener(e -> {
            // reload real data and animate to it
            updateChartsFromData();
        });

        settings.addActionListener(e -> {
            // edit durations and easing
            JPanel p = new JPanel(new GridLayout(3,2,6,6));
            p.add(new JLabel("Books duration (ms):"));
            JSpinner sb = new JSpinner(new SpinnerNumberModel(600, 80, 5000, 50));
            p.add(sb);
            p.add(new JLabel("Members duration (ms):"));
            JSpinner sm = new JSpinner(new SpinnerNumberModel(600, 80, 5000, 50));
            p.add(sm);
            p.add(new JLabel("Easing:"));
            JComboBox<String> ce = new JComboBox<>(new String[]{"linear","easeOutCubic","easeInOut"});
            p.add(ce);
            int res = JOptionPane.showConfirmDialog(this, p, "Chart settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (res == JOptionPane.OK_OPTION) {
                ccBooks.setAnimationDuration((int)sb.getValue());
                ccMembers.setAnimationDuration((int)sm.getValue());
                String eType = (String)ce.getSelectedItem();
                ccBooks.setEasingType(eType);
                ccMembers.setEasingType(eType);
            }
        });


        // messages panel (kept as a field so it can be refreshed)
        this.messagesPanel = makeMessagesPanel(); this.messagesPanel.setPreferredSize(new Dimension(300,240));
        rightCol.add(circleCard); rightCol.add(Box.createRigidArea(new Dimension(0,12))); rightCol.add(this.messagesPanel);

        main.add(rightCol, BorderLayout.EAST);

        add(main, BorderLayout.SOUTH);

        loadData(chartPanel);

    }

    // helper to (re)load and push data into charts
    public void refresh() { updateChartsFromData(); loadData(chartPanel); revalidate(); repaint(); }

    private void updateChartsFromData() {
        int tb = JsonHandler.parseBooks("frontend_java/data/books_data.json").size();
        if (tb == 0) tb = JsonHandler.parseBooks("data/books_data.json").size();
        int bd = 0; // Issue module removed: no borrowed data available

        int tm = JsonHandler.parseMemberList("frontend_java/data/members_data.json").size();
        if (tm == 0) tm = JsonHandler.parseMemberList("data/members_data.json").size();
        java.util.Set<Integer> mwi = new java.util.HashSet<>();

        if (ccBooks != null) { ccBooks.setDisplayAsRemaining(true); ccBooks.setAutoLegend(true, "Total Books", "Remaining"); ccBooks.setData(bd, Math.max(1, tb), "Remaining", UITheme.ACCENT); }
        if (ccMembers != null) { ccMembers.setDisplayAsRemaining(true); ccMembers.setAutoLegend(true, "Total Members", "Remaining"); ccMembers.setData(mwi.size(), Math.max(1, tm), "Remaining", UITheme.ACCENT.brighter()); }

        setKpiText(0, Integer.toString(tm));
        setKpiText(1, Integer.toString(tb));
        setKpiText(2, Integer.toString(tb));
    }

    // KPI storage so we can update donuts and values later
    private MiniDonut[] kpiDonuts = new MiniDonut[4];
    private JLabel[] kpiVals = new JLabel[4];
    private int kpiIndex = 0;

    // Chart panel reference for refresh
    private ChartPanel chartPanel;

    // Circular charts (borrowed books, members with issues)
    private app.Components.CircularChart ccBooks;
    private app.Components.CircularChart ccMembers;
    private javax.swing.Timer dataTimer;

    // Messages panel references (outer card + inner list) so we can refresh dynamically
    private JPanel messagesPanel;
    private JPanel messagesListPanel;

    // Stock display fields (big number + progress)
    private JLabel stockBigLabel;
    private app.Components.SmallProgressBar stockProgressBar;
    private int stockPrevValue = 0;

    private JComponent buildKpiCard(String title, String value, int pct) {
        int idx = kpiIndex++;
        app.Components.RoundedCard c = new app.Components.RoundedCard(12,6);
        c.setLayout(new BorderLayout());
        c.setPreferredSize(new Dimension(240,90));
        c.setBackground(UITheme.PANEL);

        JLabel t = new JLabel(title);
        t.setForeground(new Color(200,200,205));
        t.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.PLAIN, 12f));
        c.add(t, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout()); mid.setOpaque(false);
        JLabel v = new JLabel(value); v.setForeground(UITheme.ACCENT); v.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 20f));
        mid.add(v, BorderLayout.CENTER);
        MiniDonut md = new MiniDonut(Math.max(0f, Math.min(1f, pct/100f)));
        md.setPreferredSize(new Dimension(56,56));
        mid.add(md, BorderLayout.EAST);

        c.add(mid, BorderLayout.CENTER);

        // store references for updates
        if (idx >= 0 && idx < kpiDonuts.length) {
            kpiDonuts[idx] = md;
            kpiVals[idx] = v;
        }

        return c;
    }

    private JPanel makeMessagesPanel() {
        app.Components.RoundedCard p = new app.Components.RoundedCard(10,6);
        p.setLayout(new BorderLayout());
        p.setPreferredSize(new Dimension(260,220));
        JLabel t = new JLabel("Messages"); t.setForeground(new Color(200,200,205)); t.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD));
        p.add(t, BorderLayout.NORTH);

        messagesListPanel = new JPanel(); messagesListPanel.setOpaque(false); messagesListPanel.setLayout(new BoxLayout(messagesListPanel, BoxLayout.Y_AXIS));
        JScrollPane sp = new JScrollPane(messagesListPanel);
        sp.setBorder(null);
        sp.getViewport().setBackground(UITheme.PANEL);
        sp.setBackground(UITheme.PANEL);
        p.add(sp, BorderLayout.CENTER);

        // initial population
        updateMessagesList();
        return p;
    }

    private ImageIcon makeAvatar(String initials, int size) {
        BufferedImage img = new BufferedImage(size,size,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(255,130,80));
            g2.fillOval(0,0,size,size);
            // subtle inner circle
            g2.setColor(new Color(255,160,120,80));
            g2.fillOval(4,4,size-8,size-8);
            g2.setColor(Color.WHITE);
            g2.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, size/3f));
            FontMetrics fm = g2.getFontMetrics();
            int x = (size - fm.stringWidth(initials))/2;
            int y = (size + fm.getAscent())/2 - 2;
            g2.drawString(initials,x,y);
        } finally { g2.dispose(); }
        return new ImageIcon(img);
    }

    private void loadData(ChartPanel chart) {
        List<JsonHandler.Book> books = JsonHandler.parseBooks("frontend_java/data/books_data.json");
        if (books.isEmpty()) books = JsonHandler.parseBooks("data/books_data.json");

        Map<String, Long> counts = books.stream()
            .filter(b -> b != null)
            .collect(Collectors.groupingBy(b -> (b.getAuthor() == null || b.getAuthor().isEmpty()) ? "Unknown" : b.getAuthor(), Collectors.counting()));

        var top = counts.entrySet().stream()
                .sorted((a,b)->Long.compare(b.getValue(), a.getValue()))
                .limit(10)
                .collect(Collectors.toList());

        chart.setData(top);

        // update KPI numbers
        int members = JsonHandler.parseMemberList("frontend_java/data/members_data.json").size();
        int totalBooks = books.size();
        setKpiText(0, Integer.toString(members));
        setKpiText(1, Integer.toString(totalBooks));
        setKpiText(2, Integer.toString(totalBooks));
        setKpiText(3, "Evenings");

        // update stock display (big number animation + progress bar)
        if (stockBigLabel != null) animateStockNumber(totalBooks);
        if (stockProgressBar != null) { stockProgressBar.setPct(Math.min(1f, totalBooks / 1000f)); }

        // set donut percentages (simple heuristics to make them visible)
        if (kpiDonuts[0] != null) kpiDonuts[0].setPct(Math.min(1f, members / 120f));
        if (kpiDonuts[1] != null) kpiDonuts[1].setPct(Math.min(1f, totalBooks / 1000f));
        if (kpiDonuts[2] != null) kpiDonuts[2].setPct(Math.min(1f, totalBooks / 1000f));
        if (kpiDonuts[3] != null) kpiDonuts[3].setPct(0.65f);

        // also refresh the messages list on the right column
        updateMessagesList();
    }

    // Populate or refresh messages list from JSON files
    private void updateMessagesList() {
        if (messagesListPanel == null) return;
        messagesListPanel.removeAll();
        java.util.List<JsonHandler.Message> msgs = JsonHandler.parseMessages("frontend_java/data/messages.json");
        if (msgs.isEmpty()) msgs = JsonHandler.parseMessages("data/messages.json");

        if (msgs.isEmpty()) {
            JLabel empty = new JLabel("No messages"); empty.setForeground(new Color(160,160,160));
            empty.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
            messagesListPanel.add(empty);
        } else {
            for (JsonHandler.Message m : msgs) {
                JPanel row = new JPanel(new BorderLayout()); row.setOpaque(false); row.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
                JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0)); left.setOpaque(false);
                JLabel avatar = new JLabel(makeAvatar(m.from!=null && m.from.length()>0?m.from.substring(0,1).toUpperCase():"?", 36)); left.add(avatar);
                JPanel meta = new JPanel(new GridLayout(2,1)); meta.setOpaque(false);
                JLabel name = new JLabel(m.from!=null?m.from:"Unknown"); name.setForeground(Color.WHITE); name.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f));
                JLabel txt = new JLabel(m.body!=null?m.body:" "); txt.setForeground(new Color(180,180,180)); txt.setFont(UITheme.DEFAULT_FONT.deriveFont(11f));
                meta.add(name); meta.add(txt);
                left.add(meta);
                row.add(left, BorderLayout.CENTER);
                JLabel time = new JLabel(m.time!=null?m.time:"-"); time.setForeground(new Color(150,150,150));
                row.add(time, BorderLayout.EAST);
                messagesListPanel.add(row);
                messagesListPanel.add(Box.createRigidArea(new Dimension(0,6)));
            }
        }
        messagesListPanel.revalidate(); messagesListPanel.repaint();
    }

    // Minimal KPI card builder
    private JPanel[] kpis = new JPanel[4];
    private JLabel[] kpiValues = new JLabel[4];

    private JPanel makeKpiCard(String title, String value, String icon) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.PANEL);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // Title and small icon area
        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        JLabel t = new JLabel(title);
        t.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.PLAIN, 12f));
        t.setForeground(new Color(190,190,190));
        top.add(t, BorderLayout.WEST);

        JLabel ell = new JLabel("\u22EE"); ell.setForeground(new Color(120,120,120)); top.add(ell, BorderLayout.EAST);

        // center: value + micro donut
        JPanel center = new JPanel(new BorderLayout()); center.setOpaque(false);
        JLabel v = new JLabel(value);
        v.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 20f));
        v.setForeground(UITheme.ACCENT);
        center.add(v, BorderLayout.CENTER);

        MiniDonut md = new MiniDonut(0.7f); // placeholder percentage
        md.setPreferredSize(new Dimension(44,44));
        center.add(md, BorderLayout.EAST);

        p.add(top, BorderLayout.NORTH);
        p.add(center, BorderLayout.CENTER);

        int idx = java.util.Arrays.asList(kpis).indexOf(null);
        if (idx < 0) idx = 0;
        kpis[idx] = p;
        kpiValues[idx] = v;

        return p;
    }

    // Small donut component used in KPI cards
    private static class MiniDonut extends JComponent {
        private float pct = 0.0f; // 0..1
        MiniDonut(float pct) { this.pct = pct; setOpaque(false); }
        public void setPct(float p) { this.pct = Math.max(0f, Math.min(1f,p)); repaint(); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = Math.max(56, getWidth()), h = Math.max(56, getHeight());
                int size = Math.min(w,h);
                int thickness = Math.max(8, size/5);

                // full ring background
                g2.setColor(new Color(70, 72, 76));
                Stroke old = g2.getStroke();
                g2.setStroke(new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawArc((w-size)/2 + thickness/2, (h-size)/2 + thickness/2, size-thickness, size-thickness, 0, 360);

                // progress arc
                g2.setColor(UITheme.ACCENT.brighter());
                int start = 90; int angle = (int)(-360 * pct);
                g2.drawArc((w-size)/2 + thickness/2, (h-size)/2 + thickness/2, size-thickness, size-thickness, start, angle);
                g2.setStroke(old);

                // inner hole (card background)
                g2.setColor(UITheme.PANEL);
                int hole = size - thickness*2 - 4;
                g2.fillOval((w-hole)/2, (h-hole)/2, hole, hole);

                // percentage text (bolder, use theme foreground)
                g2.setColor(new Color(220,220,220));
                g2.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 12f));
                String s = String.format("%d%%", Math.round(pct*100));
                FontMetrics fm = g2.getFontMetrics();
                int sx = (w - fm.stringWidth(s))/2; int sy = (h + fm.getAscent())/2 - 2;
                g2.drawString(s, sx, sy);
            } finally { g2.dispose(); }
        }
    }
    // Gradient text label used for stock number
    private static class GradientLabel extends JLabel {
        private Color left;
        private Color right;
        public GradientLabel(String text) { this(text, UITheme.ACCENT.brighter(), UITheme.ACCENT.darker()); }
        public GradientLabel(String text, Color left, Color right) { super(text); setOpaque(false); this.left = left; this.right = right; }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                Font f = getFont(); g2.setFont(f);
                FontMetrics fm = g2.getFontMetrics();
                String s = getText();
                int sx = 0; int sy = (h + fm.getAscent())/2 - 2;
                // shadow for contrast
                g2.setColor(new Color(0,0,0,100));
                g2.drawString(s, sx + 2, sy + 2);
                // gradient paint left->right using supplied colors
                GradientPaint gp = new GradientPaint(0, 0, left, w, 0, right);
                g2.setPaint(gp);
                g2.drawString(s, sx, sy);
                // subtle highlight
                g2.setColor(new Color(255,255,255,32));
                g2.drawString(s, sx, sy-1);
            } finally { g2.dispose(); }
        }
    }

    private void setKpiText(int idx, String text) {
        if (idx >=0 && idx < kpiValues.length && kpiValues[idx] != null) {
            kpiValues[idx].setText(text);
        }
    }

    // Animate stock big number from previous to new value
    private void animateStockNumber(int newValue) {
        if (stockBigLabel == null) return;
        int start = stockPrevValue;
        int end = newValue;
        if (start == end) { stockBigLabel.setText(java.text.NumberFormat.getInstance().format(end)); stockPrevValue = end; return; }
        int duration = 600; int delay = 30;
        int steps = Math.max(1, duration / delay);
        final int[] step = {0};
        javax.swing.Timer t = new javax.swing.Timer(delay, null);
        t.addActionListener(e -> {
            step[0]++;
            double p = (double)step[0] / (double)steps;
            double eased = Math.pow(p, 0.6);
            int val = (int)Math.round(start + (end - start) * eased);
            stockBigLabel.setText(java.text.NumberFormat.getInstance().format(val));
            if (step[0] >= steps) { t.stop(); stockPrevValue = end; stockBigLabel.setText(java.text.NumberFormat.getInstance().format(end)); }
        });
        t.setRepeats(true);
        t.start();
    }

    // Left column stock card summarizing total books (improved visual)
    private JPanel makeStockCard() {
        app.Components.RoundedCard p = new app.Components.RoundedCard(10,6);
        p.setLayout(new BorderLayout());
        p.setPreferredSize(new Dimension(300,140));
        JLabel t = new JLabel("Total Book Stock"); t.setForeground(new Color(200,200,205)); t.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 14f));
        p.add(t, BorderLayout.NORTH);

        int totalBooks = JsonHandler.parseBooks("frontend_java/data/books_data.json").size();
        if (totalBooks == 0) totalBooks = JsonHandler.parseBooks("data/books_data.json").size();

        // sales list for sparkline and recent badge (prefer backend result then persisted store)
        java.util.List<JsonHandler.Sale> _salesTemp = JsonHandler.parseSales("frontend_java/data/result.json");
        if (_salesTemp.isEmpty()) _salesTemp = JsonHandler.parseSales("frontend_java/data/sales_data.json");
        if (_salesTemp.isEmpty()) _salesTemp = JsonHandler.parseSales("frontend_java/data/sales.json");
        if (_salesTemp.isEmpty()) _salesTemp = JsonHandler.parseSales("data/sales_data.json");
        if (_salesTemp.isEmpty()) _salesTemp = JsonHandler.parseSales("data/sales.json");
        final java.util.List<JsonHandler.Sale> sales = _salesTemp;
        final int recent = Math.min(99, sales.size());

        // GridBag layout for well-aligned stock elements
        JPanel center = new JPanel(new GridBagLayout()); center.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6,8,6,8);

        // book icon
        JComponent bookIcon = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                try {
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    int bw = Math.min(34, Math.max(20, Math.min(getWidth(), getHeight()) - 6));
                    int x = (getWidth()-bw)/2, y = (getHeight()-bw)/2;
                    g2.setColor(UITheme.ACCENT.darker());
                    g2.fillRoundRect(x, y, bw, bw-6, 6, 6);
                    g2.setColor(UITheme.ACCENT.darker().darker());
                    g2.fillRect(x+3, y+3, Math.max(4, bw/6), bw-12);
                    g2.setColor(new Color(255,255,255,45));
                    g2.fillRect(x+bw-6, y+3, 4, bw-12);
                } finally { g2.dispose(); }
            }
            @Override public Dimension getPreferredSize(){ return new Dimension(40,40); }
        };
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridheight = 2; gbc.anchor = GridBagConstraints.CENTER; gbc.weightx = 0; center.add(bookIcon, gbc);

        // big number + inline recent badge (cleaner layout)
        // stockBigLabel will be created using VIP gold styling below

        // VIP gold accent
        Color goldLeft = new Color(212,175,55);
        Color goldRight = new Color(170,135,45);
        // apply gold gradient to stock number for VIP effect (create before adding to layout)
        stockBigLabel = new GradientLabel(java.text.NumberFormat.getInstance().format(totalBooks), goldLeft.brighter(), goldRight.darker());
        stockBigLabel.setFont(UITheme.TITLE_FONT.deriveFont(Font.BOLD, 36f));
        stockBigLabel.setHorizontalAlignment(SwingConstants.LEFT);
        stockBigLabel.setBorder(BorderFactory.createEmptyBorder(4,8,4,8));
        JPanel numRow = new JPanel(new BorderLayout()); numRow.setOpaque(false);
        JPanel leftNum = new JPanel(new BorderLayout()); leftNum.setOpaque(false); leftNum.add(stockBigLabel, BorderLayout.CENTER);
        JLabel recentBadge = new JLabel("Recent: " + recent, SwingConstants.CENTER);
        recentBadge.setOpaque(true);
        recentBadge.setBackground(goldRight);
        recentBadge.setForeground(Color.WHITE);
        recentBadge.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 12f)); recentBadge.setBorder(BorderFactory.createEmptyBorder(8,10,8,10));
        recentBadge.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0,0,0,40)), recentBadge.getBorder()));
        numRow.add(leftNum, BorderLayout.CENTER); numRow.add(recentBadge, BorderLayout.EAST);

        gbc.gridx = 1; gbc.gridy = 0; gbc.gridheight = 1; gbc.gridwidth = 3; gbc.anchor = GridBagConstraints.CENTER; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; center.add(numRow, gbc);

        // progress bar under the big number (full-width)
        float pct = Math.min(1f, totalBooks / 1000f);
        stockProgressBar = new app.Components.SmallProgressBar(pct, String.format("Available: %d", totalBooks));
        // make the progress bar slightly thinner so it doesn't dominate the card
        stockProgressBar.setPreferredSize(new Dimension(240,12)); stockProgressBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 12));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 4; gbc.anchor = GridBagConstraints.CENTER; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; center.add(stockProgressBar, gbc);

        // last sale row (aligned beneath the progress bar)
        String lastSaleInfo = "No recent sales";
        if (!sales.isEmpty()) {
            JsonHandler.Sale s = sales.get(sales.size()-1);
            lastSaleInfo = String.format("Last sale: %.2f on %s", s.amount, s.date!=null? s.date : "-");
        }
        JLabel saleIcon = new JLabel(); saleIcon.setIcon(makeAvatar("$", 18)); saleIcon.setBorder(BorderFactory.createEmptyBorder(0,0,0,6));
        JLabel last = new JLabel(lastSaleInfo); last.setForeground(new Color(170,170,170)); last.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.PLAIN, 12f));
        JPanel lastWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0)); lastWrap.setOpaque(false); lastWrap.add(saleIcon); lastWrap.add(last);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 4; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; center.add(lastWrap, gbc);

        // compact bar chart showing recent sales (last 7 entries)
        app.Components.SimpleBarChart chart = new app.Components.SimpleBarChart();
        java.util.List<JsonHandler.Sale> recentList = new java.util.ArrayList<>();
        int n = Math.min(7, sales.size());
        for (int i=0;i<n;i++) recentList.add(sales.get(sales.size() - n + i));
        chart.setDataFromSales(recentList);
        chart.setPreferredSize(new Dimension(280,72));
        chart.setBorder(BorderFactory.createEmptyBorder(8,6,8,6));
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 4; gbc.anchor = GridBagConstraints.CENTER; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; center.add(chart, gbc);

        // Top 3 sales list (inline compact)
        JPanel top3 = new JPanel(); top3.setOpaque(false); top3.setLayout(new BoxLayout(top3, BoxLayout.Y_AXIS));
        java.util.List<JsonHandler.Sale> sorted = new java.util.ArrayList<>(sales);
        sorted.sort((a,b)->Double.compare(b.amount, a.amount));
        int shown = Math.min(3, sorted.size());
        if (shown == 0) {
            JLabel none = new JLabel("No recent sales"); none.setForeground(new Color(160,160,160)); none.setFont(UITheme.DEFAULT_FONT.deriveFont(12f)); top3.add(none);
        } else {
            for (int i=0;i<shown;i++) {
                JsonHandler.Sale s = sorted.get(i);
                JLabel lbl = new JLabel(String.format("%d. %s — %.2f", i+1, s.title!=null? s.title : ("#"+s.bookId), s.amount));
                lbl.setForeground(new Color(220,220,220)); lbl.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 12f));
                lbl.setBorder(BorderFactory.createEmptyBorder(2,4,2,4));
                final int bid = s.bookId;
                lbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                lbl.setToolTipText("Click to open Sales view for this book");
                lbl.addMouseListener(new java.awt.event.MouseAdapter(){ @Override public void mouseClicked(java.awt.event.MouseEvent e){
                    // switch to Sales tab and focus the specific book (silent)
                    app.Main.selectTab("Sales");
                    try {
                        if (app.Main.salesModuleRef != null) app.Main.salesModuleRef.focusOnBook(bid);
                    } catch(Exception ex) { /* best-effort */ }
                }});
                top3.add(lbl);
            }
        }
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 4; gbc.anchor = GridBagConstraints.CENTER; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; center.add(top3, gbc);

        // animate stock number if it changed (subtle)
        if (stockPrevValue > 0 && stockPrevValue != totalBooks) animateStockNumber(totalBooks); else stockBigLabel.setText(java.text.NumberFormat.getInstance().format(totalBooks));
        stockPrevValue = totalBooks;

        p.add(center, BorderLayout.CENTER);

        stockPrevValue = totalBooks;
        return p;
    }

    private JPanel makeMiniPanel(String title) {
        app.Components.RoundedCard p = new app.Components.RoundedCard(10,6);
        p.setLayout(new BorderLayout());
        p.setPreferredSize(new Dimension(280,180));
        JLabel t = new JLabel(title); t.setForeground(new Color(200,200,205)); t.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD));
        p.add(t, BorderLayout.NORTH);
        JTextArea ta = new JTextArea("Top authors and small charts");
        ta.setEditable(false);
        ta.setBackground(UITheme.PANEL);
        ta.setForeground(new Color(180,180,180));
        p.add(ta, BorderLayout.CENTER);
        return p;
    }

    // Simple chart panel reusing logic from ReportsModule
    private static class ChartPanel extends JPanel {
        private java.util.List<java.util.Map.Entry<String, Long>> data = java.util.List.of();
        void setData(java.util.List<java.util.Map.Entry<String, Long>> d) { this.data = d; repaint(); }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            int padding = 48; int labelH = 46;
            // background card
            g2.setColor(UITheme.PANEL);
            g2.fillRoundRect(8, 8, w-16, h-16, 12, 12);

            if (data == null || data.isEmpty()) {
                g2.setColor(new Color(120,120,120));
                g2.setFont(UITheme.DEFAULT_FONT);
                g2.drawString("No data", w/2-20, h/2);
                g2.dispose(); return;
            }

            long max = data.stream().mapToLong(java.util.Map.Entry::getValue).max().orElse(1);
            // limit bars to top 8 to avoid label overlap
            int barCount = Math.min(8, data.size());
            int chartW = w - padding*2; int chartH = h - padding*2 - labelH; int gap = 16; int barW = Math.max(18, (chartW - gap*(barCount+1)) / Math.max(1, barCount));

            // chart area background (slightly darker)
            int cx = padding, cy = padding, ch = chartH, cw = chartW;
            g2.setColor(new Color(40,42,46));
            g2.fillRoundRect(cx, cy, cw, ch, 8, 8);

            int x = cx + gap; int yBase = cy + ch - 8;
            for (int i=0;i<barCount;++i){
                long val = data.get(i).getValue();
                int barH = (int)((double)val/(double)max*(ch-24));
                int y = yBase - barH;

                // gradient bar
                GradientPaint gp = new GradientPaint(x, y, UITheme.ACCENT.brighter(), x, y+barH, UITheme.ACCENT.darker());
                g2.setPaint(gp);
                g2.fillRoundRect(x, y, barW, barH, 8, 8);

                // subtle top highlight
                g2.setColor(new Color(255,255,255,30));
                g2.fillRoundRect(x, y, barW, Math.max(4, barH/6), 8, 8);

                // value label above bar
                String s = String.valueOf(val);
                g2.setColor(new Color(200,200,200));
                g2.setFont(UITheme.DEFAULT_FONT.deriveFont(11f));
                FontMetrics fm = g2.getFontMetrics();
                int sx = x + (barW - fm.stringWidth(s))/2;
                g2.drawString(s, sx, Math.max(cy+12, y-6));

                // short author label (first name + last initial to save space)
                String author = data.get(i).getKey();
                String shortAuthor = author.split(" ").length>1 ? author.split(" ")[0] + " " + author.split(" ")[author.split(" ").length-1].charAt(0)+"." : (author.length()>12?author.substring(0,10)+"...":author);
                g2.setColor(new Color(170,170,170));
                g2.setFont(UITheme.DEFAULT_FONT.deriveFont(11f));
                int lblX = x + (barW - g2.getFontMetrics().stringWidth(shortAuthor))/2;
                g2.drawString(shortAuthor, lblX, yBase + 18);

                x += barW + gap;
            }

            g2.dispose();
        }
    }
}
