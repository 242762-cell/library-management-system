package app.Modules;

import app.util.JsonHandler;
import app.util.UITheme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MessagesModule extends JPanel {
    private DefaultTableModel model;

    public MessagesModule() {
        setLayout(new BorderLayout(12,12));
        UITheme.stylePanel(this);

        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        app.Components.RoundedCard card = new app.Components.RoundedCard(8,6);
        card.setLayout(new BorderLayout()); card.setPreferredSize(new Dimension(0,120));

        // input area with headings above each control
        JPanel form = new JPanel(new GridLayout(2,3,8,6)); form.setOpaque(false);
        JLabel lFrom = new JLabel("From"); lFrom.setForeground(new Color(200,200,200)); lFrom.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f));
        JLabel lMsg = new JLabel("Message"); lMsg.setForeground(new Color(200,200,200)); lMsg.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f));
        JLabel lAction = new JLabel("");
        JTextField author = new JTextField(); author.setToolTipText("From");
        JTextField body = new JTextField(); body.setToolTipText("Message");
        JButton add = UITheme.createPrimaryButton("Send");
        // first row: labels
        form.add(lFrom); form.add(lMsg); form.add(lAction);
        // second row: inputs and button
        form.add(author); form.add(body); form.add(add);
        card.add(form, BorderLayout.CENTER);
        top.add(card, BorderLayout.NORTH);
        add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"From","Message","Time"}, 0);
        JTable table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        add(sp, BorderLayout.CENTER);

        loadData();

        add.addActionListener(e -> {
            String name = author.getText().trim(); String msg = body.getText().trim();
            if (name.isEmpty() || msg.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Author and message required"); return;
            }
            JsonHandler.Message m = new JsonHandler.Message();
            m.from = name; m.body = msg; m.time = java.time.LocalDateTime.now().toString();
            var list = JsonHandler.parseMessages("frontend_java/data/messages.json");
            if (list.isEmpty()) list = JsonHandler.parseMessages("data/messages.json");
            list.add(m);
            JsonHandler.write("frontend_java/data/messages.json", list);
            loadData();
            // notify dashboard (if present) to refresh its messages panel
            java.awt.Window w = SwingUtilities.getWindowAncestor(MessagesModule.this);
            if (w instanceof javax.swing.JFrame) {
                Container content = ((javax.swing.JFrame) w).getContentPane();
                for (Component c : content.getComponents()) {
                    if (c instanceof JTabbedPane) {
                        JTabbedPane tabs = (JTabbedPane) c;
                        for (int i=0;i<tabs.getTabCount();i++) {
                            Component tcomp = tabs.getComponentAt(i);
                            if (tcomp instanceof app.Modules.DashboardModule) {
                                ((app.Modules.DashboardModule) tcomp).refresh();
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            author.setText(""); body.setText("");
        });
    }

    private void loadData() {
        java.util.List<JsonHandler.Message> msgs = JsonHandler.parseMessages("frontend_java/data/messages.json");
        if (msgs.isEmpty()) msgs = JsonHandler.parseMessages("data/messages.json");
        model.setRowCount(0);
        for (JsonHandler.Message m : msgs) model.addRow(new Object[]{m.from, m.body, m.time});
    }
}
