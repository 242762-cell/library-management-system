package app.Modules;

import app.util.JsonHandler;
import app.util.PathsUtil;
import java.awt.*;
import java.io.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MemberModule extends JPanel {

    private final app.util.PlaceholderTextField idField=new app.util.PlaceholderTextField(12);
    private final app.util.PlaceholderTextField nameField=new app.util.PlaceholderTextField(20);
    private final app.util.PlaceholderTextField emailField=new app.util.PlaceholderTextField(20);

    private String dataPath;
    private String resultJsonPath;
    private final String backendExecutablePath="backend_cpp/main.exe";

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new Object[]{"ID","Name","Email"},0) {
                @Override public boolean isCellEditable(int row, int column) { return false; }
            };

    private final JTable memberTable = new JTable(tableModel);

    public MemberModule(){

        try{
            dataPath=PathsUtil.dataPath();
            resultJsonPath=dataPath+"result.json";
        }catch(Exception e){ throw new RuntimeException(e); }

        setLayout(new BorderLayout());
        app.util.UITheme.stylePanel(this);
        add(createForm(),BorderLayout.NORTH);
        app.util.UITheme.styleTable(memberTable);
        add(new JScrollPane(memberTable),BorderLayout.CENTER);
    }

    private JPanel createForm(){
        JPanel p=new JPanel(new GridBagLayout());
        app.util.UITheme.stylePanel(p);
        GridBagConstraints g=new GridBagConstraints();
        g.insets=new Insets(6,6,6,6);
        g.fill=GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; p.add(new JLabel("ID"),g);
        g.gridx=1; p.add(idField,g);

        g.gridx=0; g.gridy=1; p.add(new JLabel("Name"),g);
        g.gridx=1; p.add(nameField,g);

        g.gridx=0; g.gridy=2; p.add(new JLabel("Email"),g);
        g.gridx=1; p.add(emailField,g);

        JPanel b=new JPanel();
        JButton add=app.util.UITheme.createIconButton("[+]","Add",true); add.setToolTipText("Add a new member");
        JButton search=app.util.UITheme.createIconButton("[?]","Search",false); search.setToolTipText("Search member by ID");
        JButton del=app.util.UITheme.createIconButton("[x]","Delete",false); del.setToolTipText("Delete a member by ID");
        JButton list=app.util.UITheme.createIconButton("[List]","List All",false); list.setToolTipText("List all members");
        b.add(add); b.add(search); b.add(del); b.add(list);

        add.addActionListener(e->perform("add"));
        search.addActionListener(e->perform("search"));
        del.addActionListener(e->perform("delete"));
        list.addActionListener(e->perform("display"));

        // placeholders + Enter triggers Add
        idField.setPlaceholder("Enter Member ID");
        nameField.setPlaceholder("Full name");
        emailField.setPlaceholder("Email address");
        app.util.UITheme.styleTextField(idField);
        app.util.UITheme.styleTextField(nameField);
        app.util.UITheme.styleTextField(emailField);
        idField.addActionListener(e->add.doClick());
        nameField.addActionListener(e->add.doClick());
        emailField.addActionListener(e->add.doClick());

        g.gridx=0; g.gridy=3; g.gridwidth=2;
        p.add(b,g);

        return p;
    }

    private void perform(String op){
        new SwingWorker<Void,Void>(){
            String err=null;
            protected Void doInBackground(){
                try{
                    int id=idField.getText().isEmpty()?0:Integer.parseInt(idField.getText());
                    String json;

                    switch(op){
                        case "add":
                            json=JsonHandler.createMemberJson(op,id,nameField.getText(),emailField.getText());
                            break;
                        case "delete":
                        case "search":
                            json=JsonHandler.createMemberJson(op,id);
                            break;
                        default:
                            json=JsonHandler.createMemberJson(op);
                    }

                    try(FileWriter f=new FileWriter(dataPath+"member.json")){
                        f.write(json);
                    }

                    Process p = new ProcessBuilder(backendExecutablePath,"member",op)
                            .directory(new File(".")).start();

                    if(p.waitFor()!=0) err="Backend failed";

                }catch(Exception ex){ err=ex.getMessage();}
                return null;
            }
            protected void done(){
                if(err!=null) show(err);
                else { refresh(); show("Done "+op); }
            }
        }.execute();
    }

    private void refresh(){
        try{
            tableModel.setRowCount(0);
            for(var m: JsonHandler.parseMemberList(resultJsonPath)){
                tableModel.addRow(new Object[]{m.getId(),m.getName(),m.getEmail()});
            }
        }catch(Exception e){ show(e.getMessage());}
    }

    private void show(String s){ JOptionPane.showMessageDialog(this,s,"Members",JOptionPane.INFORMATION_MESSAGE); }
}
