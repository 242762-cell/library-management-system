package app.Modules;

import app.util.JsonHandler;
import app.util.UITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Simple reports panel that draws a bar chart of top authors by book count.
 * Lightweight, no external chart libraries required.
 */
public class ReportsModule extends JPanel {
    private final ChartPanel chartPanel = new ChartPanel();

    public ReportsModule() {
        setLayout(new BorderLayout(8,8));
        UITheme.stylePanel(this);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);
        JButton refresh = UITheme.createIconButton("[R]", "Refresh", false);
        refresh.addActionListener(this::refresh);
        top.add(refresh);

        JLabel info = new JLabel("Top Authors (by number of books)");
        info.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 14f));
        top.add(info);

        add(top, BorderLayout.NORTH);

        chartPanel.setPreferredSize(new Dimension(900, 420)); // larger display per user request
        add(chartPanel, BorderLayout.CENTER);

        // initial load
        refresh(null);
    }

    private void refresh(ActionEvent e) {
        List<JsonHandler.Book> books = JsonHandler.parseBooks("frontend_java/data/books_data.json");
        // fall back if file not there
        if (books.isEmpty()) books = JsonHandler.parseBooks("data/books_data.json");

        Map<String, Long> counts = books.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.groupingBy(b -> (b.getAuthor() == null || b.getAuthor().isEmpty()) ? "Unknown" : b.getAuthor(), Collectors.counting()));

        // sort by count desc
        List<Map.Entry<String, Long>> top = counts.entrySet().stream()
                .sorted((a,b)-> Long.compare(b.getValue(), a.getValue()))
                .limit(10)
                .collect(Collectors.toList());

        chartPanel.setData(top);
    }

    // inner lightweight chart panel
    private static class ChartPanel extends JPanel {
        private List<Map.Entry<String, Long>> data = List.of();

        void setData(List<Map.Entry<String, Long>> d) {
            this.data = d;
            repaint();
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int padding = 40;
            int labelHeight = 40;

            // background
            g2.setColor(getBackground());
            g2.fillRect(0,0,w,h);

            if (data == null || data.isEmpty()) {
                g2.setColor(Color.DARK_GRAY);
                g2.drawString("No data", w/2 - 20, h/2);
                g2.dispose();
                return;
            }

            long max = data.stream().mapToLong(Map.Entry::getValue).max().orElse(1);

            int chartW = w - padding*2;
            int chartH = h - padding*2 - labelHeight;
            int barCount = data.size();
            int gap = 12;
            int barW = Math.max(10, (chartW - gap*(barCount+1)) / Math.max(1, barCount));

            // axes
            g2.setColor(new Color(200,200,200));
            g2.fillRect(padding, padding, chartW, chartH);

            // draw bars
            int x = padding + gap;
            int yBase = padding + chartH;
            for (int i=0;i<data.size();++i) {
                long val = data.get(i).getValue();
                int barH = (int) ((double)val / (double)max * (chartH - 10));
                int y = yBase - barH;

                // bar color using UI theme accent
                g2.setColor(UITheme.ACCENT);
                g2.fillRoundRect(x, y, barW, barH, 10, 10);

                // value label above
                g2.setColor(Color.BLACK);
                String s = String.valueOf(val);
                FontMetrics fm = g2.getFontMetrics();
                int sx = x + (barW - fm.stringWidth(s))/2;
                g2.drawString(s, sx, Math.max(padding + 10, y - 4));

                // author label below (rotate if necessary)
                String author = data.get(i).getKey();
                String shortAuthor = author.length() > 18 ? author.substring(0,15) + "..." : author;
                int lblX = x + (barW - fm.stringWidth(shortAuthor))/2;
                g2.drawString(shortAuthor, lblX, yBase + 16);

                x += barW + gap;
            }

            g2.dispose();
        }
    }
}
