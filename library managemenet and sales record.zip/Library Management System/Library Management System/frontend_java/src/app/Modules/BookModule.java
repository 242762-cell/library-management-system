package app.Modules;

import app.util.JsonHandler;
import app.util.PathsUtil;
import java.awt.*;
import java.io.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class BookModule extends JPanel {

    private final app.util.PlaceholderTextField idField = new app.util.PlaceholderTextField(12);
    private final app.util.PlaceholderTextField titleField = new app.util.PlaceholderTextField(20);
    private final app.util.PlaceholderTextField authorField = new app.util.PlaceholderTextField(20);

    private String dataPath;
    private String resultJsonPath;
    private final String backendExecutablePath = "backend_cpp/main.exe";

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new Object[]{"ID","Title","Author"},0) {
                @Override public boolean isCellEditable(int row, int column) { return false; }
            };

    private final JTable bookTable = new JTable(tableModel);

    private JButton addBtn, searchBtn, deleteBtn, listBtn;

    public BookModule() {

        try {
            dataPath = PathsUtil.dataPath();
            resultJsonPath = dataPath + "result.json";
            System.out.println("DATA PATH = " + dataPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        setLayout(new BorderLayout(10,10));
        app.util.UITheme.stylePanel(this);

        // placeholders and initial styling
        idField.setPlaceholder("Enter Book ID");
        titleField.setPlaceholder("Enter Title");
        authorField.setPlaceholder("Enter Author");

        add(createFormPanel(), BorderLayout.NORTH);
        app.util.UITheme.styleTable(bookTable);
        add(new JScrollPane(bookTable), BorderLayout.CENTER);
    }

    private JPanel createFormPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        app.util.UITheme.stylePanel(p);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6,6,6,6);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; p.add(new JLabel("Book ID"), g);
        g.gridx=1; p.add(idField, g);

        g.gridx=0; g.gridy=1; p.add(new JLabel("Title"), g);
        g.gridx=1; p.add(titleField, g);

        g.gridx=0; g.gridy=2; p.add(new JLabel("Author"), g);
        g.gridx=1; p.add(authorField, g);

        // Style text fields and bind Enter => Add
        app.util.UITheme.styleTextField(idField);
        app.util.UITheme.styleTextField(titleField);
        app.util.UITheme.styleTextField(authorField);

        JPanel b = new JPanel();
        app.util.UITheme.stylePanel(b);
        addBtn=createButton("Add"); addBtn.setToolTipText("Add a new book to the collection");
        searchBtn=createButton("Search"); searchBtn.setToolTipText("Search for a book by ID");
        deleteBtn=createButton("Delete"); deleteBtn.setToolTipText("Delete a book by ID");
        listBtn=createButton("List All"); listBtn.setToolTipText("List all books");

        b.add(addBtn); b.add(searchBtn); b.add(deleteBtn); b.add(listBtn);

        g.gridx=0; g.gridy=3; g.gridwidth=2;
        p.add(b,g);

        addBtn.addActionListener(e->perform("add"));
        searchBtn.addActionListener(e->perform("search"));
        deleteBtn.addActionListener(e->perform("delete"));
        listBtn.addActionListener(e->perform("display"));

        // Enter triggers Add
        idField.addActionListener(e -> addBtn.doClick());
        titleField.addActionListener(e -> addBtn.doClick());
        authorField.addActionListener(e -> addBtn.doClick());

        return p;
    }

    private JButton createButton(String t){
        switch(t){
            case "Add": return app.util.UITheme.createIconButton("[+]", "Add", true);
            case "Search": return app.util.UITheme.createIconButton("[?]", "Search", false);
            case "Delete": return app.util.UITheme.createIconButton("[x]", "Delete", false);
            case "List All": return app.util.UITheme.createIconButton("[List]", "List All", false);
            default: return app.util.UITheme.createButton(t);
        }
    }

    private void perform(String op){
        new SwingWorker<Void,Void>() {
            String err=null;
            @Override protected Void doInBackground(){
                try{
                    int id = idField.getText().isEmpty()?0:Integer.parseInt(idField.getText());
                    String json;

                    switch(op){
                        case "add":
                            json = JsonHandler.createBookJson(op,id,titleField.getText(),authorField.getText());
                            break;
                        case "search":
                        case "delete":
                            json = JsonHandler.createBookJson(op,id);
                            break;
                        default:
                            json = JsonHandler.createBookJson(op);
                    }

                    try(FileWriter f=new FileWriter(dataPath+"book.json")){
                        f.write(json);
                    }

                    Process p = new ProcessBuilder(backendExecutablePath,"book",op)
                            .directory(new File(".")).start();

                    if(p.waitFor()!=0) err="Backend failed";

                }catch(Exception ex){ err=ex.getMessage();}
                return null;
            }
            @Override protected void done(){
                if(err!=null) show(err);
                else { refresh(); show("Done " + op); }
            }
        }.execute();
    }

    private void refresh(){
        try{
            tableModel.setRowCount(0);
            for(var b: JsonHandler.parseBooks(resultJsonPath)){
                tableModel.addRow(new Object[]{b.getId(),b.getTitle(),b.getAuthor()});
            }
        }catch(Exception e){ show(e.getMessage()); }
    }

    private void show(String m){
        JOptionPane.showMessageDialog(this,m,"Books",JOptionPane.INFORMATION_MESSAGE);
    }
}
