package app.Modules;

import app.util.JsonHandler;
import app.util.UITheme;
import app.util.PathsUtil;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SalesModule extends JPanel {
    private DefaultTableModel model;
    private JTable table;
    private app.Components.SimpleBarChart chart;
    private app.Components.CircularChart soldChart;
    private JLabel totalLabel;
    private final String backendExecutablePath = "backend_cpp/main.exe";

    public SalesModule() {
        setLayout(new BorderLayout(12,12));
        UITheme.stylePanel(this);

        // header with title + subtitle
        app.Components.RoundedCard header = new app.Components.RoundedCard(10,8);
        header.setLayout(new BorderLayout()); header.setPreferredSize(new Dimension(0,72));
        JLabel title = new JLabel("Sales Dashboard"); title.setFont(UITheme.TITLE_FONT.deriveFont(Font.BOLD,16f)); title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Track revenue, books sold, and items sold out"); sub.setFont(UITheme.DEFAULT_FONT.deriveFont(12f)); sub.setForeground(new Color(200,200,200));
        JPanel titleP = new JPanel(new BorderLayout()); titleP.setOpaque(false); titleP.setBorder(BorderFactory.createEmptyBorder(8,10,8,10));
        titleP.add(title, BorderLayout.NORTH); titleP.add(sub, BorderLayout.SOUTH);
        header.add(titleP, BorderLayout.CENTER);

        // top area: header + compact entry bar for quick sale
        JPanel northPanel = new JPanel(new BorderLayout()); northPanel.setOpaque(false);
        northPanel.add(header, BorderLayout.NORTH);

        // compact entry bar (Book ID | Amount | Title | Author | Sell)
        JPanel entryBar = new JPanel(new GridBagLayout()); entryBar.setOpaque(false);
        GridBagConstraints eb = new GridBagConstraints(); eb.insets = new Insets(6,6,6,6); eb.fill = GridBagConstraints.HORIZONTAL;
        JTextField ebBookId = new JTextField(); ebBookId.setToolTipText("Book ID"); ebBookId.setPreferredSize(new Dimension(80,28));
        JTextField ebAmount = new JTextField(); ebAmount.setToolTipText("Amount"); ebAmount.setPreferredSize(new Dimension(80,28));
        JTextField ebTitle = new JTextField(); ebTitle.setToolTipText("Title"); ebTitle.setPreferredSize(new Dimension(240,28));
        JTextField ebAuthor = new JTextField(); ebAuthor.setToolTipText("Author"); ebAuthor.setPreferredSize(new Dimension(200,28));
        JButton ebAdd = UITheme.createPrimaryButton("Sell");

        eb.gridx=0; eb.weightx=0.12; entryBar.add(ebBookId, eb);
        eb.gridx=1; eb.weightx=0.12; entryBar.add(ebAmount, eb);
        eb.gridx=2; eb.weightx=0.38; entryBar.add(ebTitle, eb);
        eb.gridx=3; eb.weightx=0.28; entryBar.add(ebAuthor, eb);
        eb.gridx=4; eb.weightx=0.10; ebAdd.setPreferredSize(new Dimension(78,28)); entryBar.add(ebAdd, eb);

        // labels row above the entry bar (ID | Amount | Title | Author)
        JPanel labelRow = new JPanel(new GridBagLayout()); labelRow.setOpaque(false);
        GridBagConstraints lbl = new GridBagConstraints(); lbl.insets = new Insets(0,6,0,6); lbl.fill = GridBagConstraints.HORIZONTAL;
        JLabel lId = new JLabel("ID"); lId.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f)); lId.setForeground(new Color(200,200,200)); lId.setHorizontalAlignment(SwingConstants.LEFT);
        JLabel lAmt = new JLabel("Amount"); lAmt.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f)); lAmt.setForeground(new Color(200,200,200)); lAmt.setHorizontalAlignment(SwingConstants.LEFT);
        JLabel lTitle = new JLabel("Title"); lTitle.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f)); lTitle.setForeground(new Color(200,200,200)); lTitle.setHorizontalAlignment(SwingConstants.LEFT);
        JLabel lAuthor = new JLabel("Author"); lAuthor.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD,12f)); lAuthor.setForeground(new Color(200,200,200)); lAuthor.setHorizontalAlignment(SwingConstants.LEFT);
        lbl.gridx=0; lbl.weightx=0.12; labelRow.add(lId, lbl);
        lbl.gridx=1; lbl.weightx=0.12; labelRow.add(lAmt, lbl);
        lbl.gridx=2; lbl.weightx=0.38; labelRow.add(lTitle, lbl);
        lbl.gridx=3; lbl.weightx=0.28; labelRow.add(lAuthor, lbl);
        lbl.gridx=4; lbl.weightx=0.10; labelRow.add(new JLabel(""), lbl);
        northPanel.add(labelRow, BorderLayout.CENTER);
        northPanel.add(entryBar, BorderLayout.SOUTH);
        add(northPanel, BorderLayout.NORTH);

        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        app.Components.RoundedCard card = new app.Components.RoundedCard(8,6);

        // wire entry bar behaviors: auto-fill on Book ID focus lost
        ebBookId.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                String txt = ebBookId.getText().trim();
                if (txt.isEmpty()) return;
                try {
                    int bid = Integer.parseInt(txt);
                    var books = JsonHandler.parseBooks("frontend_java/data/books_data.json");
                    if (books.isEmpty()) books = JsonHandler.parseBooks("data/books_data.json");
                    for (JsonHandler.Book b : books) {
                        if (b == null) continue;
                        if (b.getId() == bid) {
                            ebTitle.setText(b.getTitle()); ebAuthor.setText(b.getAuthor());
                            ebTitle.setEditable(false); ebAuthor.setEditable(false);
                            break;
                        }
                    }
                } catch(Exception ex) { }
            }
        });
        // allow quick submit with Enter from amount field
        ebAmount.addActionListener(ev -> ebAdd.doClick());
        // Sell button triggers the same add workflow
        ebAdd.addActionListener(ev -> performAddSale(ebBookId, ebAmount));
        card.setLayout(new BorderLayout()); card.setPreferredSize(new Dimension(0,120));
        JPanel form = new JPanel(new GridBagLayout()); form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(6,6,6,6); g.fill = GridBagConstraints.HORIZONTAL;
        JTextField bookId = new JTextField(); bookId.setToolTipText("Book ID");
        JTextField amount = new JTextField(); amount.setToolTipText("Amount");
        JCheckBox includeDetails = new JCheckBox("Add book details"); includeDetails.setOpaque(false); includeDetails.setForeground(new Color(200,200,200));
        JTextField titleField = new JTextField(); titleField.setToolTipText("Title"); titleField.setVisible(false);
        JTextField authorField = new JTextField(); authorField.setToolTipText("Author"); authorField.setVisible(false);
        JButton add = UITheme.createPrimaryButton("Add Sale");

        includeDetails.addActionListener(ev -> {
            boolean on = includeDetails.isSelected();
            titleField.setVisible(on); authorField.setVisible(on);
            // if enabling details and book id corresponds to a book, autofill
            if (on) {
                try {
                    int bid = Integer.parseInt(bookId.getText().trim());
                    var books = JsonHandler.parseBooks("frontend_java/data/books_data.json");
                    if (books.isEmpty()) books = JsonHandler.parseBooks("data/books_data.json");
                    for (JsonHandler.Book b : books) {
                        if (b == null) continue;
                        if (b.getId() == bid) {
                            titleField.setText(b.getTitle()); authorField.setText(b.getAuthor());
                            titleField.setEditable(false); authorField.setEditable(false);
                            break;
                        }
                    }
                } catch(Exception ex) {
                    // ignore non-numeric id
                }
            } else {
                // allow editing when details toggled off and back on
                titleField.setEditable(true); authorField.setEditable(true);
            }
            form.revalidate(); form.repaint();
        });

        // Auto-fill title/author when leaving the Book ID field (best-effort lookup)
        bookId.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                String txt = bookId.getText().trim();
                if (txt.isEmpty()) return;
                try {
                    int bid = Integer.parseInt(txt);
                    var books = JsonHandler.parseBooks("frontend_java/data/books_data.json");
                    if (books.isEmpty()) books = JsonHandler.parseBooks("data/books_data.json");
                    for (JsonHandler.Book b : books) {
                        if (b == null) continue;
                        if (b.getId() == bid) {
                            includeDetails.setSelected(true);
                            titleField.setVisible(true); authorField.setVisible(true);
                            titleField.setText(b.getTitle()); authorField.setText(b.getAuthor());
                            titleField.setEditable(false); authorField.setEditable(false);
                            form.revalidate(); form.repaint();
                            break;
                        }
                    }
                } catch(Exception ex) { }
            }
        });
        g.gridx=0; g.gridy=0; g.gridwidth=1; g.weightx=0.2; form.add(bookId, g);
        g.gridx=1; g.weightx=0.2; form.add(amount, g);
        g.gridx=2; g.weightx=0.2; form.add(includeDetails, g);
        g.gridx=3; g.weightx=0.4; form.add(add, g);
        g.gridx=0; g.gridy=1; g.gridwidth=3; g.weightx=1.0; form.add(titleField, g);
        g.gridx=3; g.gridwidth=1; form.add(authorField, g);
        card.add(form, BorderLayout.CENTER);
        top.add(card, BorderLayout.NORTH);

        add(top, BorderLayout.CENTER);

        // center table (include Title & Author)
        model = new DefaultTableModel(new String[]{"ID","Book ID","Amount","Date","Title","Author"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        add(sp, BorderLayout.CENTER);

        // Table visual tuning: fixed column widths and alignment
        table.setFillsViewportHeight(true);
        table.setRowHeight(26);
        javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        if (table.getColumnModel().getColumnCount() >= 6) {
            table.getColumnModel().getColumn(0).setPreferredWidth(60);
            table.getColumnModel().getColumn(1).setPreferredWidth(80);
            table.getColumnModel().getColumn(2).setPreferredWidth(90);
            table.getColumnModel().getColumn(3).setPreferredWidth(100);
            table.getColumnModel().getColumn(4).setPreferredWidth(250);
            table.getColumnModel().getColumn(5).setPreferredWidth(150);
            table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
            table.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
            table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        }

        // right: sold donut + total collected + small chart
        soldChart = new app.Components.CircularChart(); soldChart.setPreferredSize(new Dimension(200,140)); soldChart.setAutoColor(true);
        chart = new app.Components.SimpleBarChart(); chart.setPreferredSize(new Dimension(300,200));
        totalLabel = new JLabel("Total collected: 0.00"); totalLabel.setFont(UITheme.TITLE_FONT.deriveFont(Font.BOLD,14f)); totalLabel.setForeground(UITheme.ACCENT);
        totalLabel.setHorizontalAlignment(SwingConstants.CENTER);

        app.Components.RoundedCard r = new app.Components.RoundedCard(6,6); r.setLayout(new BorderLayout());
        JPanel rightInner = new JPanel(); rightInner.setOpaque(false); rightInner.setLayout(new BorderLayout(8,8));
        rightInner.add(soldChart, BorderLayout.NORTH);

        // center stack: total label and quick priority controls
        JPanel centerPanel = new JPanel(); centerPanel.setOpaque(false); centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        totalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(totalLabel);
        centerPanel.add(Box.createVerticalStrut(8));

        JPanel topControls = new JPanel(new FlowLayout(FlowLayout.CENTER,8,0));
        topControls.setOpaque(false);
        JButton topBtn = UITheme.createPrimaryButton("Top Sale"); topBtn.setPreferredSize(new Dimension(90,28));
        JTextField topNField = new JTextField("5"); topNField.setPreferredSize(new Dimension(40,24));
        JButton topNBtn = UITheme.createPrimaryButton("Top N"); topNBtn.setPreferredSize(new Dimension(90,28));
        JButton refreshBtn = UITheme.createPrimaryButton("Refresh"); refreshBtn.setPreferredSize(new Dimension(90,28));
        topControls.add(topBtn); topControls.add(topNField); topControls.add(topNBtn); topControls.add(refreshBtn);
        centerPanel.add(topControls);

        // wire refresh button to manually refresh view
        refreshBtn.addActionListener(ev -> {
            // call backend refresh
            loadDataFromBackend();
        });

        rightInner.add(centerPanel, BorderLayout.CENTER);

        rightInner.add(chart, BorderLayout.SOUTH);
        r.add(rightInner, BorderLayout.CENTER);
        r.setPreferredSize(new Dimension(320,0));
        add(r, BorderLayout.EAST);

        // expose this module reference for dashboard linking
        try { app.Main.salesModuleRef = this; } catch(Exception ex) { }

        // wire top sale button
        topBtn.addActionListener(ev -> {
            new SwingWorker<Void,Void>() {
                String err = null; java.util.List<JsonHandler.Sale> res = null;
                @Override protected Void doInBackground() {
                    try {
                        String inJson = JsonHandler.getGson().toJson(java.util.Map.of("operation","top"));
                        try (java.io.FileWriter fw = new java.io.FileWriter("frontend_java/data/sales.json")) { fw.write(inJson); }
                        String backend = PathsUtil.backendPath();
                        Process p = new ProcessBuilder(backend, "sales").directory(new java.io.File(".")).start();
                        if (p.waitFor() != 0) { err = "Backend call failed"; return null; }
                        res = JsonHandler.parseSales("frontend_java/data/result.json");
                    } catch(Exception ex) { err = ex.getMessage(); }
                    return null;
                }
                @Override protected void done() {
                    if (err!=null) JOptionPane.showMessageDialog(SalesModule.this, err);
                    else if (res==null || res.isEmpty()) JOptionPane.showMessageDialog(SalesModule.this, "No sales found.");
                    else {
                        JsonHandler.Sale s = res.get(0);
                        String msg = String.format("Top Sale:\nID: %d\nBook ID: %d\nAmount: %.2f\nDate: %s\nTitle: %s\nAuthor: %s", s.bookId, s.getBookId(), s.getAmount(), s.getDate(), s.getTitle(), s.getAuthor());
                        JOptionPane.showMessageDialog(SalesModule.this, msg);
                    }
                }
            }.execute();
        });

        // wire topN button
        topNBtn.addActionListener(ev -> {
            new SwingWorker<Void,Void>() {
                String err = null; java.util.List<JsonHandler.Sale> res = null;
                @Override protected Void doInBackground() {
                    try {
                        int n=5; try { n = Integer.parseInt(topNField.getText().trim()); } catch(Exception ex) { n = 5; }
                        String inJson = JsonHandler.getGson().toJson(java.util.Map.of("operation","topN", "n", n));
                        try (java.io.FileWriter fw = new java.io.FileWriter("frontend_java/data/sales.json")) { fw.write(inJson); }
                        String backend = PathsUtil.backendPath();
                        Process p = new ProcessBuilder(backend, "sales").directory(new java.io.File(".")).start();
                        if (p.waitFor() != 0) { err = "Backend call failed"; return null; }
                        res = JsonHandler.parseSales("frontend_java/data/result.json");
                    } catch(Exception ex) { err = ex.getMessage(); }
                    return null;
                }
                @Override protected void done() {
                    if (err!=null) JOptionPane.showMessageDialog(SalesModule.this, err);
                    else if (res==null || res.isEmpty()) JOptionPane.showMessageDialog(SalesModule.this, "No sales found.");
                    else {
                        StringBuilder sb = new StringBuilder();
                        for (int i=0;i<res.size();i++) {
                            JsonHandler.Sale s = res.get(i);
                            sb.append(String.format("%d) Book %d — %.2f — %s\n", i+1, s.getBookId(), s.getAmount(), s.getDate()));
                            if (s.getTitle()!=null && !s.getTitle().isEmpty()) sb.append("   " + s.getTitle() + " — " + s.getAuthor() + "\n");
                        }
                        JTextArea ta = new JTextArea(sb.toString()); ta.setEditable(false); ta.setRows(Math.min(15, res.size()*2)); ta.setColumns(40);
                        JOptionPane.showMessageDialog(SalesModule.this, new JScrollPane(ta), "Top Sales", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }.execute();
        });
        loadData();

        add.addActionListener(e -> performAddSale(bookId, amount));
    }

    private void performAddSale(JTextField bookIdField, JTextField amountField) {
        // find title/author fields inside panel (best-effort)
        Component[] comps = ((JPanel)bookIdField.getParent()).getComponents();
        JTextField titleField = null, authorField = null; JCheckBox includeDetails=null;
        for (Component c : comps) {
            if (c instanceof JTextField && ((JTextField)c).getToolTipText()!=null && ((JTextField)c).getToolTipText().equals("Title")) titleField = (JTextField)c;
            if (c instanceof JTextField && ((JTextField)c).getToolTipText()!=null && ((JTextField)c).getToolTipText().equals("Author")) authorField = (JTextField)c;
            if (c instanceof JCheckBox) includeDetails = (JCheckBox)c;
        }

        final JTextField tfTitle = titleField; final JTextField tfAuthor = authorField; final JCheckBox cb = includeDetails;

        new SwingWorker<Void,Void>() {
            String err = null;
            @Override protected Void doInBackground() {
                try {
                    String btxt = bookIdField.getText().trim();
                    String atxt = amountField.getText().trim();
                    if (btxt.isEmpty() && atxt.isEmpty()) { err = "Book ID and amount required"; return null; }

                    Integer b = null;
                    try { b = Integer.parseInt(btxt); } catch(Exception ex) { b = null; }

                    double a = Double.parseDouble(atxt);

                    // If a Book ID was supplied, try to find it in local books
                    String title = (tfTitle!=null && tfTitle.isVisible()) ? tfTitle.getText().trim() : null;
                    String author = (tfAuthor!=null && tfAuthor.isVisible()) ? tfAuthor.getText().trim() : null;

                    if (b != null) {
                        var books = JsonHandler.parseBooks("frontend_java/data/books_data.json");
                        if (books.isEmpty()) books = JsonHandler.parseBooks("data/books_data.json");
                        boolean found = false;
                        for (JsonHandler.Book book : books) {
                            if (book == null) continue;
                            if (book.getId() == b) {
                                found = true;
                                // auto-fill missing title/author if available
                                if ((title==null || title.isEmpty()) && book.getTitle()!=null) title = book.getTitle();
                                if ((author==null || author.isEmpty()) && book.getAuthor()!=null) author = book.getAuthor();
                                break;
                            }
                        }
                        if (!found && (title==null || title.isEmpty() || author==null || author.isEmpty())) {
                            err = "Book ID not found and title/author missing"; return null;
                        }
                    } else {
                        // no book ID supplied, require title & author
                        if (title==null || title.isEmpty() || author==null || author.isEmpty()) { err = "Provide Book ID or both Title and Author"; return null; }
                    }

                    String json;
                    if (title!=null || author!=null) json = JsonHandler.createSaleJson("add", b==null?0:b, a, java.time.LocalDate.now().toString(), title, author);
                    else json = JsonHandler.createSaleJson("add", b==null?0:b, a, java.time.LocalDate.now().toString());

                    // write to data file used by backend
                    String dataPath = "frontend_java/data/";
                    try (java.io.FileWriter fw = new java.io.FileWriter(dataPath + "sales.json")) { fw.write(json); }

                    Process p = new ProcessBuilder(backendExecutablePath, "sales", "add")
                            .directory(new java.io.File(".")).start();
                    if (p.waitFor() != 0) err = "Backend failed for sales";
                } catch (Exception ex) { err = ex.getMessage(); }
                return null;
            }
            @Override protected void done() {
                if (err != null) JOptionPane.showMessageDialog(SalesModule.this, err);
                else {
                    loadDataFromBackend();
                    // small delay to let result.json be written (backend writes to result.json)
                    javax.swing.Timer t = new javax.swing.Timer(250, ev -> { loadData();
                        // also refresh dashboard if present
                        java.awt.Window w = SwingUtilities.getWindowAncestor(SalesModule.this);
                        if (w instanceof javax.swing.JFrame) {
                            Container content = ((javax.swing.JFrame)w).getContentPane();
                            for (Component c : content.getComponents()) {
                                if (c instanceof JTabbedPane) {
                                    JTabbedPane tabs = (JTabbedPane) c;
                                    for (int i=0;i<tabs.getTabCount();i++) {
                                        Component tcomp = tabs.getComponentAt(i);
                                        if (tcomp instanceof app.Modules.DashboardModule) {
                                            ((app.Modules.DashboardModule)tcomp).refresh();
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }); t.setRepeats(false); t.start();
                    JOptionPane.showMessageDialog(SalesModule.this, "Sale added");
                    bookIdField.setText(""); amountField.setText(""); if (tfTitle!=null) tfTitle.setText(""); if (tfAuthor!=null) tfAuthor.setText("");
                }
            }
        }.execute();
    }

    private void loadData() {
        // prefer backend result if available
        java.util.List<JsonHandler.Sale> sales = JsonHandler.parseSales("frontend_java/data/result.json");
        // prefer the persistent sales store when result.json isn't present or isn't populated
        if (sales.isEmpty()) sales = JsonHandler.parseSales("frontend_java/data/sales_data.json");
        if (sales.isEmpty()) sales = JsonHandler.parseSales("frontend_java/data/sales.json");
        if (sales.isEmpty()) sales = JsonHandler.parseSales("data/sales_data.json");
        if (sales.isEmpty()) sales = JsonHandler.parseSales("data/sales.json");
        model.setRowCount(0);
        java.util.Set<Integer> uniqueBooks = new java.util.HashSet<>();
        double totalCollected = 0.0;
        java.util.Map<Integer, double[]> breakdown = new java.util.HashMap<>(); // bookId -> [count, total]
        java.util.Map<Integer, String> titles = new java.util.HashMap<>();
        for (int i=0;i<sales.size();i++) {
            JsonHandler.Sale s = sales.get(i);
            model.addRow(new Object[]{i+1, s.bookId, String.format("%.2f", s.amount), s.date, s.getTitle(), s.getAuthor()});
            uniqueBooks.add(s.bookId);
            totalCollected += s.amount;
            double[] stat = breakdown.getOrDefault(s.bookId, new double[]{0.0, 0.0}); stat[0] += 1; stat[1] += s.amount; breakdown.put(s.bookId, stat);
            if (s.getTitle() != null && !s.getTitle().isEmpty()) titles.putIfAbsent(s.bookId, s.getTitle());
        }
        chart.setDataFromSales(sales);

        // update total label with currency formatting and tooltip breakdown
        java.text.NumberFormat nf = java.text.NumberFormat.getCurrencyInstance();
        totalLabel.setText("Total collected: " + nf.format(totalCollected));
        totalLabel.setToolTipText(buildSalesTooltip(breakdown, titles, totalCollected));

        // write summary file including breakdown
        try (java.io.FileWriter fw = new java.io.FileWriter("frontend_java/data/sales_summary.json")) {
            java.util.Map<String, Object> summary = new java.util.HashMap<>();
            summary.put("totalCollected", totalCollected);
            summary.put("saleCount", sales.size());
            summary.put("lastUpdated", java.time.LocalDateTime.now().toString());
            java.util.Map<String, java.util.Map<String, Object>> bmap = new java.util.HashMap<>();
            for (var e : breakdown.entrySet()) {
                java.util.Map<String, Object> info = new java.util.HashMap<>();
                info.put("count", (int)e.getValue()[0]);
                info.put("total", e.getValue()[1]);
                info.put("title", titles.getOrDefault(e.getKey(), ""));
                bmap.put(String.valueOf(e.getKey()), info);
            }
            summary.put("breakdown", bmap);
            fw.write(new com.google.gson.Gson().toJson(summary));
        } catch(Exception ex) { /* ignore */ }

        // compute sold-out metric (approx): number of unique books sold vs total books
        int totalBooks = JsonHandler.parseBooks("frontend_java/data/books_data.json").size();
        if (totalBooks == 0) totalBooks = JsonHandler.parseBooks("data/books_data.json").size();
        int soldCount = uniqueBooks.size();
        soldChart.setDisplayAsRemaining(false); // show "Sold" as the filled part
        soldChart.setAutoLegend(true, "Total", "Sold");
        soldChart.setAutoColor(true);
        soldChart.setData(soldCount, Math.max(1, totalBooks), "Sold", UITheme.ACCENT);
        // show total collected as a center detail in currency format
        java.text.NumberFormat cf = java.text.NumberFormat.getCurrencyInstance();
        soldChart.setCenterDetail(cf.format(totalCollected));
    }

    private void loadDataFromBackend() {
        // ask backend to display current sales data (writes to result.json)
        new SwingWorker<Void,Void>() {
            String err=null;
            @Override protected Void doInBackground() {
                try {
                    // ensure backend receives a display request by writing the input file
                    String inJson = JsonHandler.createSaleJson("display");
                    try (java.io.FileWriter fw = new java.io.FileWriter("frontend_java/data/sales.json")) { fw.write(inJson); }
                    String backend = PathsUtil.backendPath();
                    Process p = new ProcessBuilder(backend, "sales").directory(new java.io.File(".")).start();
                    if (p.waitFor() != 0) err = "Backend failed to return sales";
                } catch (Exception ex) { err = ex.getMessage(); }
                return null;
            }
            @Override protected void done() {
                if (err!=null) JOptionPane.showMessageDialog(SalesModule.this, err);
                else {
                    // result.json now contains sales array
                    java.util.List<JsonHandler.Sale> sales = JsonHandler.parseSales("frontend_java/data/result.json");
                    if (sales.isEmpty()) sales = JsonHandler.parseSales("data/result.json");
                    model.setRowCount(0);
                    double totalCollected = 0.0;
                    java.util.Map<Integer, double[]> breakdown = new java.util.HashMap<>();
                    java.util.Map<Integer, String> titles = new java.util.HashMap<>();
                    for (int i=0;i<sales.size();i++) {
                        JsonHandler.Sale s = sales.get(i);
                        model.addRow(new Object[]{i+1, s.bookId, String.format("%.2f", s.amount), s.date, s.getTitle(), s.getAuthor()});
                        totalCollected += s.amount;
                        double[] stat = breakdown.getOrDefault(s.bookId, new double[]{0.0, 0.0}); stat[0] += 1; stat[1] += s.amount; breakdown.put(s.bookId, stat);
                        if (s.getTitle() != null && !s.getTitle().isEmpty()) titles.putIfAbsent(s.bookId, s.getTitle());
                    }
                    chart.setDataFromSales(sales);
                    java.text.NumberFormat nf = java.text.NumberFormat.getCurrencyInstance();
                    totalLabel.setText("Total collected: " + nf.format(totalCollected));
                    totalLabel.setToolTipText(buildSalesTooltip(breakdown, titles, totalCollected));
                    // update donut center with total collected
                    soldChart.setAutoColor(true);
                    soldChart.setCenterDetail(nf.format(totalCollected));
                    try (java.io.FileWriter fw = new java.io.FileWriter("frontend_java/data/sales_summary.json")) {
                        java.util.Map<String, Object> summary = new java.util.HashMap<>();
                        summary.put("totalCollected", totalCollected);
                        summary.put("saleCount", sales.size());
                        summary.put("lastUpdated", java.time.LocalDateTime.now().toString());
                        java.util.Map<String, java.util.Map<String, Object>> bmap = new java.util.HashMap<>();
                        for (var e : breakdown.entrySet()) {
                            java.util.Map<String, Object> info = new java.util.HashMap<>();
                            info.put("count", (int)e.getValue()[0]);
                            info.put("total", e.getValue()[1]);
                            info.put("title", titles.getOrDefault(e.getKey(), ""));
                            bmap.put(String.valueOf(e.getKey()), info);
                        }
                        summary.put("breakdown", bmap);
                        fw.write(new com.google.gson.Gson().toJson(summary));
                    } catch(Exception ex) { }
                }
            }
        }.execute();
    }

    // public refresh helper for Main tab selection
    public void refresh() {
        loadDataFromBackend();
    }

    // programmatic focus: select and scroll to the first sale row for a given bookId
    public void focusOnBook(int bookId) {
        SwingUtilities.invokeLater(() -> {
            try {
                int rows = model.getRowCount();
                for (int r = 0; r < rows; r++) {
                    Object val = model.getValueAt(r, 1);
                    if (val == null) continue;
                    int bid = -1;
                    try { bid = Integer.parseInt(val.toString()); } catch(Exception ex) { continue; }
                    if (bid == bookId) {
                        // select the row and ensure visible
                        table.setRowSelectionInterval(r, r);
                        Rectangle rect = table.getCellRect(r, 0, true);
                        table.scrollRectToVisible(rect);
                        // keep selection for a short time then clear
                        new javax.swing.Timer(2200, ev -> { table.clearSelection(); }).start();
                        return;
                    }
                }
                // not found: flash by briefly selecting none
            } catch(Exception ex) {
                // ignore any UI exceptions
            }
        });
    }

    // helper: build HTML tooltip for breakdown
    private String buildSalesTooltip(java.util.Map<Integer, double[]> breakdown, java.util.Map<Integer, String> titles, double totalCollected) {
        java.text.NumberFormat nf = java.text.NumberFormat.getCurrencyInstance();
        StringBuilder sb = new StringBuilder("<html><b>Breakdown</b><br/>");
        for (var e : breakdown.entrySet()) {
            int id = e.getKey();
            int count = (int)e.getValue()[0];
            double total = e.getValue()[1];
            String title = titles.getOrDefault(id, "");
            sb.append(id);
            if (!title.isEmpty()) sb.append(" (" + escapeHtml(title) + ")");
            double avg = total / Math.max(1, count);
            sb.append(": " + count + " × " + nf.format(avg) + " = " + nf.format(total) + "<br/>");
        }
        sb.append("<hr/>Total: " + nf.format(totalCollected) + "</html>");
        return sb.toString();
    }

    private String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
