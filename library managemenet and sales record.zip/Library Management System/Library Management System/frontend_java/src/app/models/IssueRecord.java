package app.models;

public class IssueRecord {
    private int bookId;
    private int memberId;
    private String issueDate;
    private String status;

    public IssueRecord() {}

    public IssueRecord(int bookId, int memberId, String issueDate, String status) {
        this.bookId = bookId;
        this.memberId = memberId;
        this.issueDate = issueDate;
        this.status = status;
    }

    public int getBookId() { return bookId; }
    public int getMemberId() { return memberId; }
    public String getIssueDate() { return issueDate; }
    public String getStatus() { return status; }

    @Override
    public String toString() {
        return "IssueRecord{" +
                "bookId=" + bookId +
                ", memberId=" + memberId +
                ", issueDate='" + issueDate + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
