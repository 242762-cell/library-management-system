package app;

import app.Modules.*;
import java.io.File;
import javax.swing.*;

public class Main {
        
    public static void main(String[] args) {

        // Debug line (very useful!)
        System.out.println("WORKING DIR = " + new File(".").getAbsolutePath());

        SwingUtilities.invokeLater(() -> {
            // static refs for tab selection
            app.Main.tabsRef = null;
            app.Main.salesModuleRef = null;

            // Apply the dark dashboard theme by default (mockup)
            app.util.UITheme.applyDarkDashboardTheme();

            JFrame f = new JFrame("Library Management System");

            // Header / banner (kept in a small mutable ref so we can re-create it when theme changes)
            final JPanel[] headerRef = new JPanel[1];
            headerRef[0] = app.util.UITheme.createHeader("Library Management System", "Dashboard");
            f.add(headerRef[0], java.awt.BorderLayout.NORTH);

            // Left sidebar navigation
            app.Components.Sidebar sidebar = new app.Components.Sidebar();
            f.add(sidebar, java.awt.BorderLayout.WEST);

            // Store tabs statically so modules can request tab switches (e.g., Dashboard -> Sales)
            JTabbedPane tabs = new JTabbedPane();
            app.Main.tabsRef = tabs;

            BookModule books = new BookModule();
            MemberModule members = new MemberModule();
            IssueReturnModule issues = new IssueReturnModule();
            ReportsModule reports = new ReportsModule();
            SalesModule sales = new SalesModule();
            MessagesModule messages = new MessagesModule();

            // style module panels
            app.util.UITheme.stylePanel(books);
            app.util.UITheme.stylePanel(members);
            app.util.UITheme.stylePanel(issues);
            app.util.UITheme.stylePanel(reports);
            app.util.UITheme.stylePanel(sales);

            // Dashboard as first tab
            DashboardModule dashboard = new DashboardModule();
            app.util.UITheme.stylePanel(dashboard);
            tabs.add("Dashboard", dashboard);

            tabs.add("Books", books);
            tabs.add("Members", members);
            tabs.add("Issues", issues);
            tabs.add("Sales", sales);
            tabs.add("Messages", messages);
            tabs.add("Reports", reports);

            // add automatic refresh when Sales tab is selected
            tabs.addChangeListener(e -> {
                java.awt.Component selected = tabs.getSelectedComponent();
                if (selected == sales) {
                    sales.refresh();
                }
            });

            // provide helper to select a tab by title from other modules
            // e.g., Dashboard will call Main.selectTab("Sales") to bring Sales forward
            app.Main.salesModuleRef = sales;

            // select dashboard by default
            tabs.setSelectedIndex(0);

            // Menu bar
            JMenuBar mb = new JMenuBar();
            JMenu file = new JMenu("File");
            JMenuItem exit = new JMenuItem("Exit");
            exit.addActionListener(e -> System.exit(0));
            file.add(exit);

            JMenu view = new JMenu("View");
            JMenuItem darken = new JMenuItem("Darken Header");
            JMenuItem lighten = new JMenuItem("Lighten Header");
            darken.addActionListener(e -> {
                app.util.UITheme.darkenHeader();
                f.remove(headerRef[0]);
                headerRef[0] = app.util.UITheme.createHeader("Library Management System", "Classical Catalog Interface");
                f.add(headerRef[0], java.awt.BorderLayout.NORTH);
                f.revalidate(); f.repaint();
            });
            lighten.addActionListener(e -> {
                app.util.UITheme.lightenHeader();
                f.remove(headerRef[0]);
                headerRef[0] = app.util.UITheme.createHeader("Library Management System", "Classical Catalog Interface");
                f.add(headerRef[0], java.awt.BorderLayout.NORTH);
                f.revalidate(); f.repaint();
            });
            view.add(darken);
            view.add(lighten);

            // Theme toggle (modern / classical)
            JCheckBoxMenuItem modernToggle = new JCheckBoxMenuItem("Modern Theme");
            modernToggle.setSelected(false);
            modernToggle.addActionListener(e -> {
                boolean modern = modernToggle.isSelected();
                if (modern) {
                    app.util.UITheme.applyModernTheme();
                } else {
                    app.util.UITheme.applyClassicalTheme();
                }

                // recreate header and restyle panels
                f.remove(headerRef[0]);
                headerRef[0] = app.util.UITheme.createHeader("Library Management System", modern ? "Modern Catalog Interface" : "Classical Catalog Interface");
                f.add(headerRef[0], java.awt.BorderLayout.NORTH);

                app.util.UITheme.stylePanel(books);
                app.util.UITheme.stylePanel(members);

                // re-style known components in modules if they expose helpers (best-effort)
                f.revalidate(); f.repaint();
            });
            view.addSeparator();
            view.add(modernToggle);

            JMenu help = new JMenu("Help");
            JMenuItem about = new JMenuItem("About");
            about.addActionListener(e -> JOptionPane.showMessageDialog(f, "Library Management System\nClassical UI\n© Library", "About", JOptionPane.INFORMATION_MESSAGE));
            help.add(about);

            mb.add(file);
            mb.add(view);
            mb.add(help);
            f.setJMenuBar(mb);

            f.add(tabs, java.awt.BorderLayout.CENTER);

            f.setSize(900, 600);
            f.setLocationRelativeTo(null);   // Center window
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setVisible(true);
        });
    }

    // Static references used by other modules for tab navigation
    public static JTabbedPane tabsRef;
    public static app.Modules.SalesModule salesModuleRef;

    // Select a tab by title, fallback to first matching index
    public static void selectTab(String title) {
        try {
            if (tabsRef == null) return;
            for (int i=0;i<tabsRef.getTabCount();i++) {
                if (tabsRef.getTitleAt(i).equalsIgnoreCase(title)) {
                    tabsRef.setSelectedIndex(i);
                    // if sales tab is selected, call refresh on it if we have a ref
                    if (salesModuleRef != null && title.equalsIgnoreCase("sales")) salesModuleRef.refresh();
                    return;
                }
            }
        } catch(Exception ex) { /* best-effort, ignore */ }
    }
}
