package app.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class DataGenerator {
    private static final String[] sampleTitles = new String[]{
        "Pride and Prejudice",
        "The Great Gatsby",
        "To Kill a Mockingbird",
        "1984",
        "The Catcher in the Rye",
        "The Hobbit",
        "Fahrenheit 451",
        "Moby-Dick",
        "Jane Eyre",
        "Brave New World",
        "The Lord of the Rings",
        "Gone with the Wind",
        "The Picture of Dorian Gray",
        "Wuthering Heights",
        "The Alchemist",
        "The Da Vinci Code",
        "The Girl with the Dragon Tattoo",
        "The Road",
        "Life of Pi",
        "The Kite Runner",
        "A Tale of Two Cities",
        "Les Misérables",
        "Anna Karenina",
        "War and Peace",
        "The Odyssey",
        "The Iliad",
        "The Chronicles of Narnia",
        "The Little Prince",
        "The Old Man and the Sea",
        "Slaughterhouse-Five",
        "The Handmaid's Tale",
        "Beloved",
        "Middlemarch",
        "The Brothers Karamazov",
        "The Sun Also Rises",
        "Catch-22",
        "The Count of Monte Cristo",
        "Dracula",
        "Frankenstein",
        "The Sound and the Fury",
        "The Grapes of Wrath",
        "A Farewell to Arms",
        "The Metamorphosis",
        "The Stranger",
        "The Trial",
        "The Magic Mountain",
        "The Bell Jar",
        "The Secret Garden",
        "The Wind-Up Bird Chronicle"
    };

    private static final String[] sampleAuthors = new String[]{
        "Jane Austen","F. Scott Fitzgerald","Harper Lee","George Orwell","J.D. Salinger",
        "J.R.R. Tolkien","Ray Bradbury","Herman Melville","Charlotte Brontë","Aldous Huxley",
        "J.R.R. Tolkien","Margaret Mitchell","Oscar Wilde","Emily Brontë","Paulo Coelho",
        "Dan Brown","Stieg Larsson","Cormac McCarthy","Yann Martel","Khaled Hosseini",
        "Charles Dickens","Victor Hugo","Leo Tolstoy","Homer","C.S. Lewis",
        "Antoine de Saint-Exupéry","Ernest Hemingway","Kurt Vonnegut","Margaret Atwood","Toni Morrison",
        "George Eliot","Fyodor Dostoevsky","Ernest Hemingway","Joseph Heller","Alexandre Dumas",
        "Bram Stoker","Mary Shelley","William Faulkner","John Steinbeck","Franz Kafka",
        "Albert Camus","Franz Kafka","Thomas Mann","Sylvia Plath","Frances Hodgson Burnett",
        "Haruki Murakami"
    };

    private static final String[] firstNames = new String[]{
        "James","Mary","John","Patricia","Robert","Jennifer","Michael","Linda",
        "William","Elizabeth","David","Barbara","Richard","Susan","Joseph","Jessica",
        "Thomas","Sarah","Charles","Karen","Christopher","Nancy","Daniel","Lisa",
        "Matthew","Betty","Anthony","Margaret","Mark","Sandra","Donald","Ashley",
        "Steven","Kimberly","Paul","Emily","Andrew","Donna","Joshua","Michelle"
    };

    private static final String[] lastNames = new String[]{
        "Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Rodriguez",
        "Martinez","Hernandez","Lopez","Gonzalez","Wilson","Anderson","Thomas","Taylor","Moore",
        "Jackson","Martin","Lee","Perez","Thompson","White","Harris","Sanchez","Clark","Ramirez"
    };

    public static void main(String[] args) throws IOException {
        int books = 1000;
        int members = 100;
        if (args.length >= 1) {
            try { books = Integer.parseInt(args[0]); } catch (Exception ignored) {}
        }
        if (args.length >= 2) {
            try { members = Integer.parseInt(args[1]); } catch (Exception ignored) {}
        }
        generateBooksCsv("data/books.csv", books);
        generateMembersCsv("data/members.csv", members);
        System.out.println("Generated books="+books+" members="+members);
    }

    private static void generateBooksCsv(String path, int count) throws IOException {
        Random rnd = new Random(1234);
        try (BufferedWriter w = new BufferedWriter(new FileWriter(path))) {
            w.write("id,title,author\n");
            int id = 100000;
            for (int i = 1; i <= count; i++) {
                String title;
                if (i <= sampleTitles.length) title = sampleTitles[i-1];
                else title = generateTitle(rnd);
                String author = sampleAuthors[rnd.nextInt(sampleAuthors.length)];
                // ensure no commas in fields
                title = title.replace(',', ' ');
                author = author.replace(',', ' ');
                id++;
                w.write(id + "," + title + "," + author + "\n");
            }
        }
    }

    private static String generateTitle(Random rnd) {
        String[] prefixes = new String[]{"The Art of","Modern","Practical","Essential","Understanding","Mastering","A Short History of","The Rise of","The Fall of","Tales of"};
        String[] nouns = new String[]{"Innovation","Solitude","Tomorrow","Cities","Dreams","Algorithms","Design","Society","War","Peace","Language","Memory","Light","Shadows","Time"};
        return prefixes[rnd.nextInt(prefixes.length)] + " " + nouns[rnd.nextInt(nouns.length)];
    }

    private static void generateMembersCsv(String path, int count) throws IOException {
        Random rnd = new Random(4321);
        try (BufferedWriter w = new BufferedWriter(new FileWriter(path))) {
            w.write("id,name,email\n");
            int id = 200000;
            for (int i = 1; i <= count; i++) {
                String first = firstNames[rnd.nextInt(firstNames.length)];
                String last = lastNames[rnd.nextInt(lastNames.length)];
                String name = first + " " + last;
                String email = (first + "." + last + (rnd.nextInt(900)+100)) + "@gmail.com";
                id++;
                w.write(id + "," + name + "," + email + "\n");
            }
        }
    }
}
