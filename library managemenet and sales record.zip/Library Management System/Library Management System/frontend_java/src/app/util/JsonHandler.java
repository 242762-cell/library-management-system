package app.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonHandler {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static <T> void write(String filePath, T data) {
        try (Writer writer = new FileWriter(filePath)) {
            gson.toJson(data, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static <T> List<T> readList(String filePath, Type typeToken) {
        if (!new File(filePath).exists()) return new ArrayList<>();
        try (Reader reader = new FileReader(filePath)) {
            List<T> data = gson.fromJson(reader, typeToken);
            return data != null ? data : new ArrayList<>();
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    public static Gson getGson() {
        return gson;
    }

    // --- Helper Methods for Book Module ---
    public static String createBookJson(String operation, int id, String title, String author) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("id", id);
        map.put("title", title);
        map.put("author", author);
        return gson.toJson(map);
    }

    public static String createBookJson(String operation, int id) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("id", id);
        return gson.toJson(map);
    }

    public static String createBookJson(String operation) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        return gson.toJson(map);
    }

    public static List<Book> parseBooks(String filePath) {
        if (!new File(filePath).exists()) return new ArrayList<>();
        try (Reader reader = new FileReader(filePath)) {
            JsonElement el = JsonParser.parseReader(reader);
            if (el.isJsonArray()) {
                return gson.fromJson(el, new TypeToken<List<Book>>(){}.getType());
            } else if (el.isJsonObject()) {
                JsonObject obj = el.getAsJsonObject();
                if (obj.has("data")) {
                    JsonElement data = obj.get("data");
                    if (data.isJsonArray()) {
                        return gson.fromJson(data, new TypeToken<List<Book>>(){}.getType());
                    } else if (data.isJsonObject()) {
                        Book b = gson.fromJson(data, Book.class);
                        List<Book> res = new ArrayList<>();
                        res.add(b);
                        return res;
                    }
                } else if (obj.has("id")) {
                    Book b = gson.fromJson(obj, Book.class);
                    List<Book> res = new ArrayList<>();
                    res.add(b);
                    return res;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    // --- Helper Methods for Member Module ---
    public static String createMemberJson(String operation, int id, String name, String email) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("id", id);
        map.put("name", name);
        map.put("email", email);
        return gson.toJson(map);
    }

    public static String createMemberJson(String operation, int id) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("id", id);
        return gson.toJson(map);
    }

    public static String createMemberJson(String operation) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        return gson.toJson(map);
    }

    public static List<Member> parseMemberList(String filePath) {
        if (!new File(filePath).exists()) return new ArrayList<>();
        try (Reader reader = new FileReader(filePath)) {
            JsonElement el = JsonParser.parseReader(reader);
            if (el.isJsonArray()) {
                return gson.fromJson(el, new TypeToken<List<Member>>(){}.getType());
            } else if (el.isJsonObject()) {
                JsonObject obj = el.getAsJsonObject();
                if (obj.has("data")) {
                    JsonElement data = obj.get("data");
                    if (data.isJsonArray()) {
                        return gson.fromJson(data, new TypeToken<List<Member>>(){}.getType());
                    } else if (data.isJsonObject()) {
                        Member m = gson.fromJson(data, Member.class);
                        List<Member> res = new ArrayList<>();
                        res.add(m);
                        return res;
                    }
                } else if (obj.has("id")) {
                    Member m = gson.fromJson(obj, Member.class);
                    List<Member> res = new ArrayList<>();
                    res.add(m);
                    return res;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    // --- Helper Methods for Issue Module ---
    public static String createIssueJson(String operation, int bookId, int memberId, String issueDate) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("bookId", bookId);
        map.put("memberId", memberId);
        map.put("issueDate", issueDate);
        return gson.toJson(map);
    }

    public static String createIssueJson(String operation, int bookId) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("bookId", bookId);
        return gson.toJson(map);
    }

    public static String createIssueJson(String operation) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        return gson.toJson(map);
    }

    public static java.util.List<app.models.IssueRecord> parseIssueList(String filePath) {
        if (!new java.io.File(filePath).exists()) return new ArrayList<>();
        try (Reader reader = new FileReader(filePath)) {
            JsonElement el = JsonParser.parseReader(reader);
            if (el.isJsonArray()) {
                return gson.fromJson(el, new TypeToken<List<app.models.IssueRecord>>(){}.getType());
            } else if (el.isJsonObject()) {
                JsonObject obj = el.getAsJsonObject();
                if (obj.has("data")) {
                    JsonElement data = obj.get("data");
                    if (data.isJsonArray()) {
                        return gson.fromJson(data, new TypeToken<List<app.models.IssueRecord>>(){}.getType());
                    } else if (data.isJsonObject()) {
                        app.models.IssueRecord r = gson.fromJson(data, app.models.IssueRecord.class);
                        List<app.models.IssueRecord> res = new ArrayList<>(); res.add(r); return res;
                    }
                } else if (obj.has("bookId")) {
                    app.models.IssueRecord r = gson.fromJson(obj, app.models.IssueRecord.class);
                    List<app.models.IssueRecord> res = new ArrayList<>(); res.add(r); return res;
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return new ArrayList<>();
    }

    // --- Data Classes ---
    public static class Book {
        public int id;
        public String title;
        public String author;
        public int getId() { return id; }
        public String getTitle() { return title; }
        public String getAuthor() { return author; }
        public String toString() { return id + " - " + title; }
    }

    public static class Member {
        public int id;
        public String name;
        public String email;
        public int getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String toString() { return id + " - " + name; }
    }

    // --- Sales & Messages ---
    public static class Sale {
        public int bookId;
        public double amount;
        public String date; // ISO date string
        // optional extra metadata
        public String title;
        public String author;
        public int getBookId() { return bookId; }
        public double getAmount() { return amount; }
        public String getDate() { return date; }
        public String getTitle() { return title; }
        public String getAuthor() { return author; }
        public String toString() { return "Sale: book=" + bookId + ", amt=" + amount + (title!=null?", title="+title:""); }
    }

    public static class Message {
        public String from;
        public String body;
        public String time; // ISO datetime
        public String getFrom() { return from; }
        public String getBody() { return body; }
        public String getTime() { return time; }
        public String toString() { return from + ": " + body; }
    }

    public static List<Sale> parseSales(String filePath) {
        if (!new java.io.File(filePath).exists()) return new ArrayList<>();
        try {
            // Debug helper: show which file is being parsed
            System.out.println("parseSales: reading " + filePath);
            String content = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(filePath)), java.nio.charset.StandardCharsets.UTF_8);
            System.out.println("parseSales: content preview='" + (content.length()>80?content.substring(0,80):content) + "'");
            try {
                JsonElement el = JsonParser.parseString(content);
                if (el.isJsonArray()) {
                    return gson.fromJson(el, new TypeToken<List<Sale>>(){}.getType());
                } else if (el.isJsonObject()) {
                    JsonObject obj = el.getAsJsonObject();
                    if (obj.has("data")) {
                        JsonElement data = obj.get("data");
                        if (data.isJsonArray()) {
                            return gson.fromJson(data, new TypeToken<List<Sale>>(){}.getType());
                        } else if (data.isJsonObject()) {
                            Sale s = gson.fromJson(data, Sale.class);
                            List<Sale> res = new ArrayList<>(); res.add(s); return res;
                        }
                    } else if (obj.has("bookId")) {
                        Sale s = gson.fromJson(obj, Sale.class);
                        List<Sale> res = new ArrayList<>(); res.add(s); return res;
                    }
                }
            } catch (Exception ex) {
                // defensive: catch any parsing/runtime issue and return empty list rather than crash UI
                ex.printStackTrace();
                return new ArrayList<>();
            }
        } catch (IOException e) { e.printStackTrace(); }
        return new ArrayList<>();
    }

    // --- Helper Methods for Sales Module ---
    public static String createSaleJson(String operation, int bookId, double amount, String date) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("bookId", bookId);
        map.put("amount", amount);
        map.put("date", date);
        return gson.toJson(map);
    }

    public static String createSaleJson(String operation, int bookId, double amount, String date, String title, String author) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("bookId", bookId);
        map.put("amount", amount);
        map.put("date", date);
        if (title!=null && !title.isEmpty()) map.put("title", title);
        if (author!=null && !author.isEmpty()) map.put("author", author);
        return gson.toJson(map);
    }

    public static String createSaleJson(String operation, int id) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        map.put("id", id);
        return gson.toJson(map);
    }

    public static String createSaleJson(String operation) {
        Map<String, Object> map = new HashMap<>();
        map.put("operation", operation);
        return gson.toJson(map);
    }

    public static List<Message> parseMessages(String filePath) {
        if (!new java.io.File(filePath).exists()) return new ArrayList<>();
        try (Reader reader = new FileReader(filePath)) {
            JsonElement el = JsonParser.parseReader(reader);
            if (el.isJsonArray()) {
                return gson.fromJson(el, new TypeToken<List<Message>>(){}.getType());
            } else if (el.isJsonObject()) {
                JsonObject obj = el.getAsJsonObject();
                if (obj.has("data")) {
                    JsonElement data = obj.get("data");
                    if (data.isJsonArray()) {
                        return gson.fromJson(data, new TypeToken<List<Message>>(){}.getType());
                    } else if (data.isJsonObject()) {
                        Message m = gson.fromJson(data, Message.class);
                        List<Message> res = new ArrayList<>(); res.add(m); return res;
                    }
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return new ArrayList<>();
    }
}
