package app.util;

import java.io.File;
import java.io.IOException;

public class PathsUtil {

    public static String backendPath() {

        // Prioritize the project root path as it's the standard execution context
        String[] paths = {
                "backend_cpp/main.exe",         // 1. Project root (Standard)
                "../backend_cpp/main.exe",      // 2. From frontend_java/
                "../../backend_cpp/main.exe"    // 3. From frontend_java/bin/
        };

        for (String p : paths) {
            File f = new File(p);
            if (f.exists() && !f.isDirectory()) {
                System.out.println("Backend found: " + f.getAbsolutePath());
                return f.getAbsolutePath();
            }
        }

        // Fallback: return absolute path of standard location for clearer error
        System.out.println("Backend NOT found. Defaulting to: " + new File("backend_cpp/main.exe").getAbsolutePath());
        return new File("backend_cpp/main.exe").getAbsolutePath();
    }

    public static String dataPath() throws IOException {
        return "frontend_java/data/";
    }
}
