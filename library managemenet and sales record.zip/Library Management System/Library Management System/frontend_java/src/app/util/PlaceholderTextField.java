package app.util;

import javax.swing.*;
import java.awt.*;

public class PlaceholderTextField extends JTextField {
    private String placeholder;

    public PlaceholderTextField() { super(); }
    public PlaceholderTextField(int cols) { super(cols); }
    public PlaceholderTextField(String text, int cols) { super(text, cols); }

    public void setPlaceholder(String s) { this.placeholder = s; }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (placeholder == null || placeholder.length() == 0) return;
        if (getText().length() > 0) return;
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(new Color(150,150,150));
        Insets ins = getInsets();
        FontMetrics fm = g2.getFontMetrics(getFont());
        int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(placeholder, ins.left + 4, textY);
        g2.dispose();
    }
}
