package app.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;

public class UIUtils {

    public static JLabel getLogoLabel() {
        // Try to load a logo image from frontend_java/resources/logo.png
        try {
            File f = new File("frontend_java/resources/logo.png");
            if (f.exists()) {
                ImageIcon ico = new ImageIcon(f.getAbsolutePath());
                Image img = ico.getImage().getScaledInstance(160, 60, Image.SCALE_SMOOTH);
                JLabel l = new JLabel(new ImageIcon(img));
                l.setBorder(new EmptyBorder(8,12,8,12));
                return l;
            }
        } catch (Exception ignored) {}

        // Fallback textual logo
        JLabel label = new JLabel("Library Management System");
        label.setFont(new Font("Segoe UI", Font.BOLD, 20));
        label.setForeground(new Color(30,136,229));
        label.setBorder(new EmptyBorder(8,12,8,12));
        return label;
    }

    public static void styleButton(JButton b) {
        b.setBackground(new Color(30,136,229));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setPreferredSize(new Dimension(110,36));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(20,100,180)),
                BorderFactory.createEmptyBorder(6,12,6,12)));
    }

    public static void styleTextField(JTextField t) {
        t.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200,200,200)),
                BorderFactory.createEmptyBorder(4,6,4,6)));
        t.setPreferredSize(new Dimension(220,28));
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(245,245,245));
    }
}
