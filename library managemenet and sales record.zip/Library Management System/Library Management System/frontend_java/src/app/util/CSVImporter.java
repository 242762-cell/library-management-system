package app.util;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple CSV importer for development use:
 * Usage: java app.util.CSVImporter books
 *        java app.util.CSVImporter members
 */
public class CSVImporter {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Specify 'books' or 'members'");
            return;
        }
        String root = new File(".").getAbsolutePath();
        Path repoRoot = Paths.get(".").toAbsolutePath().normalize();
        switch (args[0]) {
            case "books":
                importBooks(repoRoot.resolve("data").resolve("books.csv"), repoRoot.resolve("frontend_java").resolve("data").resolve("books_data.json"));
                break;
            case "members":
                importMembers(repoRoot.resolve("data").resolve("members.csv"), repoRoot.resolve("frontend_java").resolve("data").resolve("members_data.json"));
                break;
            default:
                System.out.println("Unknown command: " + args[0]);
        }
    }

    private static void importBooks(Path csv, Path out) throws IOException {
        if (!Files.exists(csv)) {
            System.err.println("CSV not found: " + csv);
            return;
        }
        List<JsonHandler.Book> list = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(csv)) {
            String line = r.readLine(); // header
            while ((line = r.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length < 3) continue;
                try {
                    JsonHandler.Book b = new JsonHandler.Book();
                    b.id = Integer.parseInt(parts[0].trim());
                    b.title = parts[1].trim();
                    b.author = parts[2].trim();
                    list.add(b);
                } catch (NumberFormatException ex) {
                    System.err.println("Skipping line (bad id): " + line);
                }
            }
        }
        JsonHandler.write(out.toString(), list);
        System.out.println("Imported " + list.size() + " books to " + out);
    }

    private static void importMembers(Path csv, Path out) throws IOException {
        if (!Files.exists(csv)) {
            System.err.println("CSV not found: " + csv);
            return;
        }
        List<JsonHandler.Member> list = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(csv)) {
            String line = r.readLine(); // header
            while ((line = r.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length < 3) continue;
                try {
                    JsonHandler.Member m = new JsonHandler.Member();
                    m.id = Integer.parseInt(parts[0].trim());
                    m.name = parts[1].trim();
                    m.email = parts[2].trim();
                    list.add(m);
                } catch (NumberFormatException ex) {
                    System.err.println("Skipping line (bad id): " + line);
                }
            }
        }
        JsonHandler.write(out.toString(), list);
        System.out.println("Imported " + list.size() + " members to " + out);
    }
}
