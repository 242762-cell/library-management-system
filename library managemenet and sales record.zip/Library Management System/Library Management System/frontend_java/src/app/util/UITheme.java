package app.util;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Small utility to apply a classical library look-and-feel across the app.
 */
public class UITheme {

    // Palette (non-final so we can tweak at runtime)
    public static Color BG = new Color(245, 236, 224);       // parchment
    public static Color PANEL = new Color(250, 244, 236);
    private static Color headerBg = new Color(77, 42, 26);    // dark wood brown
    public static Color HEADER_FG = new Color(245, 238, 224);
    public static Color ACCENT = new Color(102, 51, 0);       // mahogany

    // Modern theme palette
    private static final Color MODERN_BG = new Color(248,249,250);
    private static final Color MODERN_PANEL = new Color(255,255,255);
    private static final Color MODERN_HEADER = new Color(10,102,194);
    private static final Color MODERN_ACCENT = new Color(0,123,255);

    // Dashboard palette (inspired by the provided design)
    private static final Color DASHBOARD_BG = new Color(246, 247, 249);
    private static final Color DASHBOARD_PANEL = new Color(255, 255, 255);
    private static final Color DASHBOARD_HEADER = new Color(245, 245, 250);
    private static final Color DASHBOARD_CARD = new Color(255, 255, 255);
    private static final Color DASHBOARD_KPI = new Color(255, 99, 71);
    private static final Color DASHBOARD_ACCENT = new Color(255, 143, 84);

    private static boolean MODERN = false;

    // Preferred fonts (may be overridden by loading a custom TTF placed in resources)
    public static Font TITLE_FONT = new Font("Garamond", Font.BOLD, 26);
    public static Font HEADER_FONT = new Font("Garamond", Font.BOLD, 16);
    public static Font DEFAULT_FONT = new Font("Garamond", Font.PLAIN, 14);

    /**
     * Attempt to load a TTF font from the project's resources path (relative to repo root).
     * Example: "frontend_java/resources/fonts/Inter-Regular.ttf"
     */
    public static void tryLoadCustomFont(String relativePath) {
        try {
            File f = new File(relativePath);
            if (f.exists()) {
                Font custom = Font.createFont(Font.TRUETYPE_FONT, f);
                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                ge.registerFont(custom);
                DEFAULT_FONT = custom.deriveFont(14f);
                HEADER_FONT = custom.deriveFont(Font.BOLD, 16f);
                TITLE_FONT = custom.deriveFont(Font.BOLD, 26f);
                applyTheme();
            }
        } catch (Exception ignored) {}
    }

    /** Apply a dashboard-oriented palette for a modern admin/dashboard look. */
    public static void applyDashboardTheme() {
        BG = DASHBOARD_BG;
        PANEL = DASHBOARD_PANEL;
        headerBg = DASHBOARD_HEADER;
        HEADER_FG = Color.DARK_GRAY;
        ACCENT = DASHBOARD_ACCENT;
        applyTheme();
    }

    /** Apply the modern (blue accent) theme */
    public static void applyModernTheme() {
        MODERN = true;
        BG = MODERN_BG;
        PANEL = MODERN_PANEL;
        headerBg = MODERN_HEADER;
        HEADER_FG = Color.WHITE;
        ACCENT = MODERN_ACCENT;
        applyTheme();
    }

    /** Revert to the classical (parchment) theme */
    public static void applyClassicalTheme() {
        MODERN = false;
        BG = new Color(245, 236, 224);
        PANEL = new Color(250, 244, 236);
        headerBg = new Color(77, 42, 26);
        HEADER_FG = new Color(245, 238, 224);
        ACCENT = new Color(102, 51, 0);
        applyTheme();
    }

    /** Apply a dark dashboard theme (mockup-inspired) */
    public static void applyDarkDashboardTheme() {
        MODERN = true;
        // Deep charcoal and warm orange accent inspired by the mockup
        BG = new Color(28, 30, 34);          // window background
        PANEL = new Color(36, 38, 42);       // card background
        headerBg = new Color(44, 47, 51);    // header / top bar
        HEADER_FG = new Color(235, 235, 235);
        ACCENT = new Color(255, 102, 51);    // warm orange
        applyTheme();
    }

    /** Apply UI defaults (fonts, background) */
    public static void applyTheme() {
        UIManager.put("Label.font", DEFAULT_FONT);
        UIManager.put("Button.font", DEFAULT_FONT);
        UIManager.put("TextField.font", DEFAULT_FONT);
        UIManager.put("Table.font", DEFAULT_FONT);
        UIManager.put("TableHeader.font", HEADER_FONT);
        UIManager.put("OptionPane.background", BG);
        UIManager.put("Panel.background", BG);
        UIManager.put("ScrollPane.background", BG);
        // try to set a nice cross-platform look
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {}
    }

    // Small helper to style a rounded dashboard card consistently
    public static void styleCard(JComponent c) {
        c.setBackground(PANEL);
        c.setForeground(Color.LIGHT_GRAY);
        c.setFont(DEFAULT_FONT);
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(55,55,55), 1, true),
                new EmptyBorder(12, 12, 12, 12)
        ));
    }

    // Simple button factory (secondary style)
    public static JButton createButton(String text) {
        RoundedButton b = new RoundedButton(text, false);
        b.setBackground(new Color(120, 68, 20));
        b.setForeground(Color.WHITE);
        b.setFont(DEFAULT_FONT);
        return b;
    }

    // Primary (call-to-action) button
    public static JButton createPrimaryButton(String text) {
        RoundedButton b = new RoundedButton(text, true);
        b.setBackground(MODERN ? MODERN_ACCENT : ACCENT);
        b.setForeground(Color.WHITE);
        b.setFont(DEFAULT_FONT.deriveFont(Font.BOLD));
        return b;
    }

    // Button with emoji icon prefix (primary by default)
    public static JButton createIconButton(String emoji, String text, boolean primary) {
        JButton b = primary ? createPrimaryButton(text) : createButton(text);
        // attach a small generated icon on the left (drawn placeholder)
        b.setIcon(makeSmallIcon(emoji.charAt(0), primary ? ACCENT.darker() : new Color(120,68,20)));
        b.setHorizontalTextPosition(SwingConstants.RIGHT);
        b.setIconTextGap(8);
        return b;
    }

    private static ImageIcon makeSmallIcon(char ch, Color base) {
        int size = 18;
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(base);
            g.fillOval(0,0,size,size);
            g.setColor(Color.WHITE);
            g.setFont(new Font("SansSerif", Font.BOLD, 12));
            FontMetrics fm = g.getFontMetrics();
            String s = String.valueOf(ch);
            int x = (size - fm.stringWidth(s)) / 2;
            int y = (size - fm.getHeight()) / 2 + fm.getAscent() - 1;
            g.drawString(s, x, y);
        } finally { g.dispose(); }
        return new ImageIcon(img);
    }

    // Text field styling
    public static void styleTextField(JTextField tf) {
        if (MODERN) {
            tf.setBackground(MODERN_PANEL);
            tf.setCaretColor(MODERN_ACCENT.darker());
            tf.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(230,230,230), 1, true),
                    new EmptyBorder(6,8,6,8)
            ));
        } else {
            tf.setBackground(new Color(255, 253, 244));
            tf.setCaretColor(ACCENT.darker());
            tf.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(190, 190, 190), 1, true),
                    new EmptyBorder(6,8,6,8)
            ));
        }
        tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(MODERN ? MODERN_ACCENT : ACCENT, 2, true),
                        new EmptyBorder(5,7,5,7)
                ));
            }
            public void focusLost(java.awt.event.FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(MODERN ? new Color(230,230,230) : new Color(190,190,190), 1, true),
                        new EmptyBorder(6,8,6,8)
                ));
            }
        });
    }

    // Rounded button implementation with hover effect
    private static class RoundedButton extends JButton {
        private boolean primary;
        private boolean hover = false;
        RoundedButton(String text, boolean primary) {
            super(text);
            this.primary = primary;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setOpaque(false);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));

            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent e) { hover = true; repaint(); }
                public void mouseExited(java.awt.event.MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();

            Color base = getBackground();
            if (hover) base = base.brighter();

            g2.setColor(base);
            g2.fillRoundRect(0,0,w,h,14,14);

            // subtle border
            g2.setColor(base.darker().darker());
            g2.drawRoundRect(0,0,w-1,h-1,14,14);

            super.paintComponent(g2);
            g2.dispose();
        }

        @Override public void setContentAreaFilled(boolean b) { /* ignore */ }
    }

    public static ImageIcon loadLogoIcon(int size) {
        // try to load 'air_university_logo.png' first, then fallback to 'logo.png' in ./frontend_java/resources/
        try {
            File f1 = new File("frontend_java/resources/air_university_logo.png");
            if (f1.exists()) {
                BufferedImage img = ImageIO.read(f1);
                Image scaled = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            }
            // If the Air University logo doesn't exist, generate a simple placeholder 'AU' logo and save it so it persists
            try {
                File resDir = new File("frontend_java/resources");
                if (!resDir.exists()) resDir.mkdirs();
                BufferedImage gen = new BufferedImage(256, 256, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = gen.createGraphics();
                try {
                    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    // background
                    g.setColor(new Color(3, 95, 171)); // university blue
                    g.fillRect(0,0,256,256);
                    // simple eagle-like triangle mark
                    g.setColor(Color.WHITE);
                    int[] xs = {40, 128, 216};
                    int[] ys = {170, 48, 170};
                    g.fillPolygon(xs, ys, 3);
                    // AU letters
                    g.setFont(new Font("SansSerif", Font.BOLD, 96));
                    FontMetrics fm = g.getFontMetrics();
                    String s = "AU";
                    int tx = (256 - fm.stringWidth(s)) / 2;
                    int ty = 200;
                    g.drawString(s, tx, ty);
                } finally { g.dispose(); }
                ImageIO.write(gen, "PNG", f1);
                BufferedImage img = ImageIO.read(f1);
                Image scaled = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            } catch (IOException ignoredGen) { /* fall through to logo.png or placeholder */ }

            File f = new File("frontend_java/resources/logo.png");
            if (f.exists()) {
                BufferedImage img = ImageIO.read(f);
                Image scaled = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            }
        } catch (IOException ignored) {}

        // fallback: generate a simple placeholder icon
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(220, 200, 170));
            g.fillRoundRect(0, 0, size, size, 6, 6);
            g.setColor(headerBg.brighter());
            int w = size - 14;
            int h = size - 20;
            g.fillRect(6, 6, w, h/2);
            g.setColor(headerBg.darker());
            g.fillRect(6, 8 + h/2, w, h/2 - 2);
            g.setColor(HEADER_FG.darker());
            g.setFont(new Font("Serif", Font.BOLD, size/3));
            FontMetrics fm = g.getFontMetrics();
            String s = "📚";
            int x = (size - fm.stringWidth(s)) / 2;
            int y = (size + fm.getAscent()) / 2 - 4;
            g.drawString(s, x, y);
        } finally {
            g.dispose();
        }
        return new ImageIcon(img);
    }

    public static JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(headerBg);
        header.setBorder(new EmptyBorder(12,12,12,12));

        JLabel t = new JLabel(title + "   ");
        t.setForeground(HEADER_FG);
        t.setFont(TITLE_FONT);

        JLabel s = new JLabel(subtitle);
        s.setForeground(HEADER_FG);
        s.setFont(new Font("Garamond", Font.ITALIC, 14));

        JPanel txt = new JPanel(new GridLayout(2,1));
        txt.setOpaque(false);
        txt.add(t);
        txt.add(s);

        JLabel icon = new JLabel();
        icon.setIcon(loadLogoIcon(48));

        header.add(icon, BorderLayout.WEST);
        header.add(txt, BorderLayout.CENTER);

        return header;
    }

    public static void stylePanel(JComponent c) {
        c.setBackground(PANEL);
        c.setForeground(Color.DARK_GRAY);
        c.setFont(DEFAULT_FONT);
    }

    public static void styleTable(JTable t) {
        t.setFont(DEFAULT_FONT);
        t.setRowHeight(20);
        JTableHeader h = t.getTableHeader();
        h.setBackground(headerBg.darker());
        h.setForeground(HEADER_FG);
        h.setFont(HEADER_FONT);
    }
    // Helpers to tweak theme at runtime
    public static void darkenHeader() {
        headerBg = headerBg.darker();
    }

    public static void lightenHeader() {
        headerBg = headerBg.brighter();
    }

    public static void increaseFonts(int delta) {
        // best-effort adjustments by deriving fonts
        // Note: this does not update UIManager; caller should re-call applyTheme and revalidate UI components to see change
        // We derive new fonts (unsafe but quick)
        // Using deriveFont to adjust size
        // TITLE_FONT, HEADER_FONT and DEFAULT_FONT are final references to Font instances; to change them we'd need to reassign new values. To keep simple: we won't reassign statics here, but callers can set system properties or recreate components if needed.
    }}
