package app.Components;

import app.util.UITheme;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Simple bar chart for sales totals by day */
public class SimpleBarChart extends JComponent {
    private java.util.List<java.util.Map.Entry<String, Double>> data = java.util.List.of();
    public void setData(java.util.List<java.util.Map.Entry<String, Double>> d) { this.data = d; repaint(); }

    // convenience: compute totals per day from sales
    public void setDataFromSales(java.util.List<app.util.JsonHandler.Sale> sales) {
        java.util.Map<String, Double> map = new java.util.TreeMap<>();
        for (app.util.JsonHandler.Sale s : sales) {
            String d = s.date == null ? "unknown" : s.date;
            map.put(d, map.getOrDefault(d, 0.0) + s.amount);
        }
        java.util.List<java.util.Map.Entry<String, Double>> lst = new java.util.ArrayList<>(map.entrySet());
        setData(lst);
    }

    private java.util.List<Rectangle> barRects = new java.util.ArrayList<>();
    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            if (data == null || data.isEmpty()) {
                g2.setColor(new Color(120,120,120)); g2.drawString("No data", w/2-20, h/2);
                return;
            }
            double max = data.stream().mapToDouble(java.util.Map.Entry::getValue).max().orElse(1);
            int barW = Math.max(12, (w - 20) / data.size() - 6);
            int x = 10; int base = h - 24;
            barRects.clear();
            for (int i=0;i<data.size();i++) {
                double v = data.get(i).getValue();
                int bh = (int)(v / max * (h - 60));
                boolean hover = (i == hoverIndex);
                Color left = hover ? UITheme.ACCENT.brighter().brighter() : UITheme.ACCENT.brighter();
                Color right = hover ? UITheme.ACCENT.darker().darker() : UITheme.ACCENT.darker();
                GradientPaint gp = new GradientPaint(x, base-bh, left, x, base, right);
                g2.setPaint(gp);
                int drawX = x; int drawW = barW; int drawH = bh;
                if (hover) { drawX -= 2; drawW += 4; drawH += 6; }
                g2.fillRoundRect(drawX, base - drawH, drawW, drawH, 6,6);
                g2.setColor(new Color(200,200,200));
                String lbl = data.get(i).getKey().length()>5?data.get(i).getKey().substring(5):data.get(i).getKey(); // show MM-DD
                g2.drawString(lbl, drawX, base+14);

                // outline for hover
                if (hover) {
                    g2.setColor(new Color(255,255,255,60));
                    g2.setStroke(new BasicStroke(1.6f));
                    g2.drawRoundRect(drawX, base - drawH, drawW, drawH, 6,6);
                }

                barRects.add(new Rectangle(drawX, base - drawH, drawW, Math.max(0,drawH)));
                x += barW + 6;
            }
        } finally { g2.dispose(); }
    }

    private int hoverIndex = -1;
    public SimpleBarChart() { setOpaque(false);
        // tooltip & hover handler: show exact date and amount for hovered bar and highlight
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter(){ @Override public void mouseMoved(java.awt.event.MouseEvent e) {
            int newHover = -1;
            for (int i=0;i<barRects.size();i++) {
                Rectangle r = barRects.get(i);
                if (r.contains(e.getPoint())) { newHover = i; break; }
            }
            if (newHover != hoverIndex) { hoverIndex = newHover; repaint(); }
            if (hoverIndex >= 0) {
                String date = data.get(hoverIndex).getKey(); double val = data.get(hoverIndex).getValue();
                setToolTipText(String.format("%s: %.2f", date, val));
            } else setToolTipText(null);
        }});
        addMouseListener(new java.awt.event.MouseAdapter(){ @Override public void mouseExited(java.awt.event.MouseEvent e) { if (hoverIndex != -1) { hoverIndex = -1; repaint(); } }});
    }
}
