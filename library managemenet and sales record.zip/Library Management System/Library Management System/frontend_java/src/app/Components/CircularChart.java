package app.Components;

import app.util.JsonHandler;
import app.util.UITheme;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple circular donut chart showing borrowed vs available books.
 */
public class CircularChart extends JComponent {
    private int value = 0;              // target value
    private int total = 1;
    private String subtitle = "Borrowed";
    private Color segmentColor = UITheme.ACCENT;
    private String centerDetail = null; // optional line shown under counts (e.g., total money)

    // animation state
    private int displayedValue = 0;     // current animated value
    public int getDisplayedValue() { return displayedValue; }
    private javax.swing.Timer animTimer;
    private int animDuration = 600;     // ms (configurable)
    private String easing = "easeOutCubic"; // "linear" | "easeOutCubic" | "easeInOut"

    private long animStart;
    private int animStartValue;
    private int animTargetValue;

    // flash effect when values change (0.0 .. 1.0)
    private double flashAlpha = 0.0;

    // history (recent changes) for tooltips
    private final java.util.List<String> history = new ArrayList<>();
    private static final DateTimeFormatter TF = DateTimeFormatter.ofPattern("HH:mm:ss");

    public CircularChart() {
        setPreferredSize(new Dimension(160,160)); setOpaque(false);

        // tooltip on hover should show recent history and cursor for clickability
        addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                setToolTipText(buildHistoryTooltip());
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                setCursor(Cursor.getDefaultCursor());
            }
        });
        // also allow click handlers to be added by caller (default does nothing)

    }

    public void setData(int value, int total, String subtitle, Color color) {
        this.total = Math.max(1, total);
        this.subtitle = subtitle == null ? "" : subtitle;
        this.segmentColor = color == null ? UITheme.ACCENT : color;

        // record history entry if value changed
        int prev = Math.max(0, animTargetValue);
        if (value != prev) {
            String ts = LocalDateTime.now().format(TF);
            String entry = String.format("%s: %d -> %d", ts, prev, value);
            history.add(0, entry);
            if (history.size() > 6) history.remove(history.size()-1);
            // trigger flash effect
            flashAlpha = 1.0;
        }

        // If displayAsRemaining is on, we animate toward the remaining count instead of the passed value
        int effectiveTarget = displayAsRemaining ? Math.max(0, total - value) : Math.max(0, value);

        // start animation from current displayedValue to new value
        this.animStartValue = displayedValue;
        this.animTargetValue = effectiveTarget;
        this.animStart = System.currentTimeMillis();
        if (animTimer == null) {
            animTimer = new javax.swing.Timer(16, ae -> animateStep());
        }
        if (!animTimer.isRunning()) animTimer.start();
    }

    // backward compatible
    public void setData(int value, int total) { setData(value, total, "Borrowed", UITheme.ACCENT); }

    // If true, the chart displays remaining = total - value (and percent is remaining/total)
    private boolean displayAsRemaining = false;
    // automatic legend filling (leftLabel, rightLabel)
    private boolean autoLegend = false;
    private String autoLeftLabel = "Total";
    private String autoRightLabel = "Remaining";

    // automatic color thresholds (green/yellow/red based on percent)
    private boolean autoColor = false;

    public void setDisplayAsRemaining(boolean on) { this.displayAsRemaining = on; }
    public void setAutoLegend(boolean on, String leftLabel, String rightLabel) { this.autoLegend = on; if (leftLabel!=null) this.autoLeftLabel = leftLabel; if (rightLabel!=null) this.autoRightLabel = rightLabel; }
    public void setAutoColor(boolean on) { this.autoColor = on; }

    // optional center detail text (e.g., total collected in currency)
    public void setCenterDetail(String detail) { this.centerDetail = detail; }

    private void animateStep() {
        long now = System.currentTimeMillis();
        double t = (double)(now - animStart) / (double)animDuration;
        if (t >= 1.0) {
            displayedValue = animTargetValue;
            animTimer.stop();
        } else {
            double e;
            switch (easing) {
                case "linear": e = t; break;
                case "easeInOut": e = t < 0.5 ? 4*t*t*t : 1 - Math.pow(-2*t+2, 3)/2; break;
                default: // easeOutCubic
                    e = 1 - Math.pow(1 - t, 3);
            }
            displayedValue = animStartValue + (int)Math.round((animTargetValue - animStartValue) * e);
            // fade flash while animating
            flashAlpha = Math.max(0.0, flashAlpha - (t * 0.08));
        }
        repaint();
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(); int h = getHeight();
            int size = Math.min(w,h) - 8;
            int cx = (w - size)/2; int cy = (h - size)/2;

            // background ring
            int thickness = Math.max(12, size/6);
            g2.setStroke(new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(70,70,74));
            g2.drawArc(cx + thickness/2, cy + thickness/2, size - thickness, size - thickness, 0, 360);

            // compute angles based on displayedValue
            float pct = Math.min(1f, (float)displayedValue / (float)total);
            int angle = Math.round(360 * pct);

            // value segment with slight glow effect
            Color drawColor = segmentColor;
            if (autoColor) {
                float pctNow = total <= 0 ? 0f : Math.min(1f, (float)displayedValue / (float)total);
                if (pctNow >= 0.7f) drawColor = new Color(76,175,80); // green
                else if (pctNow >= 0.4f) drawColor = new Color(255,193,7); // amber
                else drawColor = new Color(244,67,54); // red
            }
            g2.setPaint(new java.awt.RadialGradientPaint(new java.awt.Point(w/2,h/2), size/2, new float[]{0f,1f}, new Color[]{drawColor.brighter(), drawColor.darker()}));
            g2.drawArc(cx + thickness/2, cy + thickness/2, size - thickness, size - thickness, 90, -angle);

            // subtle flash overlay when value changed
            if (flashAlpha > 0.01) {
                Composite oldComp = g2.getComposite();
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float)Math.min(1.0, flashAlpha)));
                g2.setColor(drawColor.brighter().brighter());
                g2.setStroke(new BasicStroke(thickness/2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawArc(cx + thickness/4, cy + thickness/4, size - thickness/2, size - thickness/2, 90, -angle);
                g2.setComposite(oldComp);
            }

            // center fill
            g2.setColor(UITheme.PANEL);
            int hole = size - thickness*2 - 8;
            g2.fillOval(cx + (size - hole)/2, cy + (size - hole)/2, hole, hole);

            // percentage text (show one decimal for small percentages)
            g2.setColor(UITheme.HEADER_FG);
            g2.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 14f));
            String pctTxt = String.format("%.1f%%", pct*100f);
            FontMetrics fm = g2.getFontMetrics();
            int tx = w/2 - fm.stringWidth(pctTxt)/2;
            int ty = h/2 + fm.getAscent()/2 - 4;
            g2.drawString(pctTxt, tx, ty);

            // counts text below the percent (e.g., 32 / 100) - but if displayAsRemaining is set show "Remaining" inside center
            int centerShownValue = displayedValue;
            if (displayAsRemaining) {
                centerShownValue = displayedValue; // displayedValue already represents remaining target when setData is called in remaining mode
            }

            g2.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.PLAIN, 11f));
            java.text.NumberFormat nf = java.text.NumberFormat.getIntegerInstance();
            String counts = String.format("%s / %s", nf.format(centerShownValue), nf.format(total));
            fm = g2.getFontMetrics();
            tx = w/2 - fm.stringWidth(counts)/2; ty = h/2 + fm.getAscent()/2 + 14;
            g2.setColor(new Color(180,180,180));
            g2.drawString(counts, tx, ty);

            // subtitle under counts
            if (subtitle != null && !subtitle.isEmpty()) {
                g2.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.PLAIN, 11f));
                String sub = subtitle;
                fm = g2.getFontMetrics();
                tx = w/2 - fm.stringWidth(sub)/2; ty += 14;
                g2.setColor(new Color(150,150,150));
                g2.drawString(sub, tx, ty);
            }

            // center detail (optional) - show extra info such as total collected in currency
            if (centerDetail != null && !centerDetail.isEmpty()) {
                g2.setFont(UITheme.DEFAULT_FONT.deriveFont(Font.BOLD, 12f));
                fm = g2.getFontMetrics();
                tx = w/2 - fm.stringWidth(centerDetail)/2; ty += 16;
                g2.setColor(UITheme.ACCENT);
                g2.drawString(centerDetail, tx, ty);
            }

            // draw legend if set to autoLegend or if legend values supplied
            int legendY = cy + size + 6; // position beneath donut
            int legendCenter = w/2;
            int bulletSize = 8;
            if (autoLegend) {
                String left = autoLeftLabel;
                String right = autoRightLabel;
                int rightVal = displayAsRemaining ? displayedValue : displayedValue; // displayedValue is either remaining or value depending on mode
                int leftVal = total;
                String leftStr = String.valueOf(leftVal);
                String rightStr = String.valueOf(rightVal);

                // left legend (Total)
                int spacing = 12;
                Font labFont = UITheme.DEFAULT_FONT.deriveFont(Font.PLAIN, 11f);
                g2.setFont(labFont);
                FontMetrics lfm = g2.getFontMetrics();
                int leftLabelW = lfm.stringWidth(left);
                int leftValW = lfm.stringWidth(leftStr);
                int rightLabelW = lfm.stringWidth(right);
                int rightValW = lfm.stringWidth(rightStr);
                int totalW = bulletSize + 6 + leftLabelW + 18 + bulletSize + 6 + rightLabelW + 18;

                // left block
                int startX = legendCenter - (totalW/2);
                g2.setColor(new Color(160,160,160));
                g2.fillOval(startX, legendY, bulletSize, bulletSize);
                g2.setColor(new Color(190,190,190));
                g2.drawString(left, startX + bulletSize + 6, legendY + bulletSize);
                g2.setColor(new Color(200,200,200));
                g2.drawString(leftStr, startX + bulletSize + 6 + leftLabelW + 14, legendY + bulletSize);

                // right block (colored)
                int rx = startX + bulletSize + 6 + leftLabelW + 18;
                g2.setColor(segmentColor);
                g2.fillOval(rx, legendY, bulletSize, bulletSize);
                g2.setColor(new Color(190,190,190));
                g2.drawString(right, rx + bulletSize + 6, legendY + bulletSize);
                g2.setColor(UITheme.HEADER_FG);
                g2.drawString(rightStr, rx + bulletSize + 6 + rightLabelW + 14, legendY + bulletSize);
            }

        } finally { g2.dispose(); }
    }

    // configure animation duration and easing type
    public void setAnimationDuration(int ms) { this.animDuration = Math.max(80, ms); }
    public void setEasingType(String type) { if (type != null) this.easing = type; }

    private String buildHistoryTooltip() {
        StringBuilder sb = new StringBuilder();
        sb.append("<html><div style='font-family:Sans; font-size:10px;'>");
        sb.append("<b>").append(subtitle).append("</b><br/>");
        sb.append(String.format("Now: %d / %d<br/>", displayedValue, total));
        if (!history.isEmpty()) {
            sb.append("<hr/>");
            for (int i=0;i<history.size();i++) {
                sb.append(history.get(i)).append("<br/>");
            }
        }
        sb.append("</div></html>");
        return sb.toString();
    }
}

