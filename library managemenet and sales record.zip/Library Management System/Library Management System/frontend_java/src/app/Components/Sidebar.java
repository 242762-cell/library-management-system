package app.Components;

import app.util.UITheme;

import javax.swing.*;
import java.awt.*;

/**
 * Left navigation sidebar matching the mockup: dark background, logo, nav items
 */
public class Sidebar extends JPanel {

    public Sidebar() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(220, 0));
        setBackground(new Color(34, 36, 40));

        // top: logo + title
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);
        top.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        JLabel logo = new JLabel();
        logo.setIcon(UITheme.loadLogoIcon(36));
        top.add(logo);

        JLabel title = new JLabel("Air University Library");
        title.setForeground(UITheme.HEADER_FG);
        title.setFont(UITheme.HEADER_FONT);
        top.add(title);

        add(top, BorderLayout.NORTH);

        // navigation (improved spacing and robust hover handling)
        JPanel nav = new JPanel();
        nav.setOpaque(false);
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));
        nav.setBorder(BorderFactory.createEmptyBorder(12, 8, 12, 8));

        String[] items = new String[]{"Dashboard","Inventory","Sales","Books","Messages"};
        for (int i=0;i<items.length;i++) {
            String it = items[i];
            JButton b = new JButton(it);
            b.setFocusPainted(false);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            b.setPreferredSize(new Dimension(200, 44));
            b.setForeground(new Color(200, 200, 200));
            b.setOpaque(false);
            b.setContentAreaFilled(false);
            b.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            // subtle hover with null-safe active check
            b.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent e) { b.setForeground(UITheme.ACCENT); }
                public void mouseExited(java.awt.event.MouseEvent e) {
                    Object active = b.getClientProperty("active");
                    if (!(active instanceof Boolean) || !((Boolean)active)) b.setForeground(new Color(200,200,200));
                }
            });

            // map clicks to interesting tabs (Shelves / Inventory -> Books)
            b.addActionListener(e -> {
                // find the first JTabbedPane in the top-level frame
                java.awt.Window w = SwingUtilities.getWindowAncestor(Sidebar.this);
                if (w instanceof JFrame) {
                    Container content = ((JFrame) w).getContentPane();
                    for (Component c : content.getComponents()) {
                        if (c instanceof JTabbedPane) {
                            JTabbedPane tabs = (JTabbedPane) c;
                            String target = null;
                            if (it.equalsIgnoreCase("shelves") || it.equalsIgnoreCase("inventory")) target = "Books";
                            else target = it; // try to select tab matching the label

                            if (target != null) {
                                for (int ti = 0; ti < tabs.getTabCount(); ti++) {
                                    if (tabs.getTitleAt(ti).equalsIgnoreCase(target)) {
                                        tabs.setSelectedIndex(ti);
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                }

                // update active visuals: clear others and set this one active
                for (Component comp : nav.getComponents()) {
                    if (comp instanceof JButton) {
                        JButton bb = (JButton) comp;
                        bb.putClientProperty("active", Boolean.FALSE);
                        bb.setForeground(new Color(200,200,200));
                        bb.setBorder(BorderFactory.createEmptyBorder(8,12,8,12));
                    }
                }
                b.putClientProperty("active", Boolean.TRUE);
                b.setForeground(UITheme.ACCENT);
                b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,6,0,0, UITheme.ACCENT), b.getBorder()));
            });

            // initial active indicator
            b.putClientProperty("active", i==0 ? Boolean.TRUE : Boolean.FALSE);
            if (i==0) {
                b.setForeground(UITheme.ACCENT);
                b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,6,0,0, UITheme.ACCENT), b.getBorder()));
            }
            nav.add(b);
            nav.add(Box.createRigidArea(new Dimension(0,8)));
        }

        add(nav, BorderLayout.CENTER);

        // bottom quick actions
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT));
        footer.setOpaque(false);
        footer.setBorder(BorderFactory.createEmptyBorder(8, 12, 12, 12));
        JButton settings = new JButton("Settings");
        settings.setForeground(new Color(180,180,180));
        settings.setBorder(null);
        settings.setBackground(new Color(0,0,0,0));
        footer.add(settings);
        add(footer, BorderLayout.SOUTH);
    }
}
