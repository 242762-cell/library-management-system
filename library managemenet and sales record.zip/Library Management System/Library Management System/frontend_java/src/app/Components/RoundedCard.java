package app.Components;

import app.util.UITheme;

import javax.swing.*;
import java.awt.*;

/**
 * Rounded card with subtle shadow used across the dashboard to mimic the mockup.
 */
public class RoundedCard extends JPanel {
    private int arc = 12;
    private int shadow = 8;

    public RoundedCard() {
        setOpaque(false);
    }

    public RoundedCard(int arc, int shadow) {
        this.arc = arc; this.shadow = shadow; setOpaque(false);
    }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            // draw shadow (simple translucent rounded rect below the card)
            g2.setColor(new Color(0, 0, 0, 40));
            for (int i = 0; i < shadow; i++) {
                int alpha = Math.max(0, 40 - i*4);
                g2.setColor(new Color(0,0,0,alpha));
                g2.fillRoundRect(6-i, 6-i, w - (6-i)*2, h - (6-i)*2, arc, arc);
            }

            // card background
            g2.setColor(UITheme.PANEL);
            g2.fillRoundRect(0, 0, w - shadow, h - shadow, arc, arc);

            // subtle inner border
            g2.setColor(new Color(255,255,255,6));
            g2.drawRoundRect(0, 0, w - shadow -1, h - shadow -1, arc, arc);

        } finally { g2.dispose(); }
        super.paintComponent(g);
    }
}
