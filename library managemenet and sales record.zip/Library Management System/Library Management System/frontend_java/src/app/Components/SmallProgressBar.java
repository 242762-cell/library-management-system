package app.Components;

import app.util.UITheme;

import javax.swing.*;
import java.awt.*;

/**
 * Small horizontal progress bar with label used in KPI cards.
 */
public class SmallProgressBar extends JComponent {
    private float pct = 0f; // 0..1
    private String caption = "";

    public SmallProgressBar(float pct, String caption) {
        this.pct = Math.max(0f, Math.min(1f, pct));
        this.caption = caption;
        setPreferredSize(new Dimension(180, 16));
        setOpaque(false);
    }

    public void setPct(float pct) { this.pct = Math.max(0f, Math.min(1f, pct)); repaint(); }

    @Override protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            int r = 8;
            // background track
            g2.setColor(new Color(45,47,50));
            g2.fillRoundRect(0, 0, w, h, r, r);
            // filled (gradient)
            int fw = (int)(w * pct);
            if (fw > 0) {
                GradientPaint gp = new GradientPaint(0, 0, UITheme.ACCENT.brighter(), fw, 0, UITheme.ACCENT.darker());
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, fw, h, r, r);
            }
            // label
            g2.setColor(new Color(210,210,210));
            g2.setFont(UITheme.DEFAULT_FONT.deriveFont(11f));
            FontMetrics fm = g2.getFontMetrics();
            int sx = 8; int sy = (h + fm.getAscent())/2 - 2;
            if (caption != null && !caption.isEmpty()) g2.drawString(caption, sx, sy);
        } finally { g2.dispose(); }
    }
}
