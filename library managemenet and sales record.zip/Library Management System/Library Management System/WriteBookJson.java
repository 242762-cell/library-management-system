import java.nio.file.*;
import java.nio.charset.StandardCharsets;
public class WriteBookJson {
    public static void main(String[] args) throws Exception {
        String s = "{ \"operation\": \"add\", \"id\": 101, \"title\": \"Test Driven Development\", \"author\": \"Kent Beck\" }";
        Files.write(Paths.get("frontend_java/data/book.json"), s.getBytes(StandardCharsets.UTF_8));
        System.out.println("Wrote via Java helper");
    }
}