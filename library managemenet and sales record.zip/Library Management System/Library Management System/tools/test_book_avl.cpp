#include <iostream>
#include "../backend_cpp/book/BookAVL.h"

int main() {
    BookAVL avl;
    Book b1{10, "C++ Primer", "Lippman"};
    Book b2{5, "Algorithms", "CLRS"};
    Book b3{15, "Clean Code", "Martin"};
    Book b4{12, "Design Patterns", "Gamma"};

    avl.insert(b1);
    avl.insert(b2);
    avl.insert(b3);
    avl.insert(b4);

    auto v = avl.inorder();
    if (v.size() != 4) { std::cerr << "Insert failed; size=" << v.size() << "\n"; return 2; }
    // check sorted by id
    for (size_t i = 1; i < v.size(); ++i) {
        if (v[i-1].id >= v[i].id) { std::cerr << "Order incorrect\n"; return 3; }
    }

    if (!avl.contains(10) || !avl.contains(5) || !avl.contains(15) || !avl.contains(12)) {
        std::cerr << "Contains check failed\n"; return 4;
    }

    avl.remove(10);
    if (avl.contains(10)) { std::cerr << "Remove failed\n"; return 5; }

    std::cout << "BookAVL tests passed\n";
    return 0;
}
