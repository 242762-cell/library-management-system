#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cctype>

using namespace std;

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: repair_json_array <path-to-file>\n";
        return 1;
    }
    std::string path = argv[1];
    std::ifstream f(path);
    if (!f.is_open()) { std::cerr << "Could not open file: " << path << "\n"; return 1; }
    std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    f.close();

    // backup
    std::string bak = path + ".bak";
    std::ofstream backup(bak);
    if (backup.is_open()) { backup << s; backup.close(); }

    std::vector<std::string> objs;
    size_t idx = 0;
    while (true) {
        size_t st = s.find('{', idx);
        if (st == std::string::npos) break;
        size_t en = s.find('}', st);
        if (en == std::string::npos) break;
        std::string obj = s.substr(st, en - st + 1);
        // trim
        size_t a = 0; while (a < obj.size() && std::isspace((unsigned char)obj[a])) a++;
        size_t b = obj.size(); while (b > a && std::isspace((unsigned char)obj[b-1])) b--;
        objs.push_back(obj.substr(a, b-a));
        idx = en + 1;
    }

    std::ofstream out(path);
    if (!out.is_open()) { std::cerr << "Could not write file: " << path << "\n"; return 1; }
    out << "[\n";
    for (size_t i = 0; i < objs.size(); ++i) {
        out << "  " << objs[i];
        if (i + 1 != objs.size()) out << ",\n"; else out << "\n";
    }
    out << "]\n";
    out.close();
    std::cout << "Repaired " << path << " (backup at " << bak << ")\n";
    return 0;
}
