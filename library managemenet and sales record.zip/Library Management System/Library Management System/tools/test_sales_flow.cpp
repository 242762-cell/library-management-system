#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <chrono>
#include <thread>

using namespace std;

bool runBackend() {
    int rc = system(".\\backend_cpp\\main.exe sales");
    return rc == 0;
}

std::string readFile(const std::string &p) {
    std::ifstream f(p);
    if (!f.is_open()) return "";
    std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    f.close();
    return s;
}

void writeSalesJson(int bookId, double amount) {
    std::ofstream f("frontend_java/data/sales.json");
    f << "{ \"operation\": \"add\", \"bookId\": " << bookId << ", \"amount\": " << amount << ", \"date\": \"2025-12-28\" }";
    f.close();
}

int main(int argc, char** argv) {
    if (argc < 2) { std::cerr << "Usage: test_sales_flow <bookId1> [bookId2] ...\n"; return 1; }
    for (int i = 1; i < argc; ++i) {
        int bid = std::stoi(argv[i]);
        writeSalesJson(bid, 5.0);
        if (!runBackend()) { std::cerr << "Backend run failed for " << bid << "\n"; return 2; }
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        std::string res = readFile("frontend_java/data/result.json");
        std::cout << "Result for " << bid << ": " << res << "\n";
    }
    std::cout << "Sold books now:\n" << readFile("frontend_java/data/sold_books.json") << "\n";
    std::cout << "Sales summary:\n" << readFile("frontend_java/data/sales_summary.json") << "\n";
    return 0;
}
