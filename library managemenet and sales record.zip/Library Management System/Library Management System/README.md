# Library Management System

This is a simple desktop application for managing a library's books, members, and issued items. It is designed as a university project to demonstrate core Data Structures and Algorithms concepts.

The application uses a hybrid approach:
-   **Java Swing** for the graphical user interface (GUI).
-   **C++** for the backend logic and data management, with a strict no-STL (Standard Template Library) constraint.
-   **JSON files** for communication between the Java frontend and the C++ backend.

## Folder Structure

```
/
├── backend_cpp/
│   ├── book/
│   │   ├── BookService.cpp
│   │   ├── BookService.h
│   │   ├── BookAVL.cpp
│   │   ├── BookAVL.h
│   │   └── BookSearch.cpp (removed / deprecated)
(Issue/Return module removed)
│   ├── member/
│   │   ├── MemberList.cpp
│   │   ├── MemberList.h
│   │   └── MemberSearch.cpp
│   └── main.cpp
├── data/
│   ├── book.json
│   ├── books_data.json
(issue data files removed)
│   ├── member.json
│   ├── members_data.json
│   └── result.json
└── frontend_java/
    └── src/
        └── app/
            ├── Main.java
            ├── Modules/
            │   ├── BookModule.java
            │   ├── IssueReturnModule.java
            │   └── MemberModule.java
            └── util/
                └── JsonHandler.java
```

## How to Compile and Run

### 1. Compile the C++ Backend

Open a terminal or command prompt and run the following command from the project's root directory. This will compile all necessary C++ files and create a single executable `main.exe` in the `backend_cpp` folder.

```sh
g++ -o backend_cpp/main.exe backend_cpp/main.cpp backend_cpp/book/BookService.cpp backend_cpp/book/BookAVL.cpp backend_cpp/member/MemberList.cpp backend_cpp/sales/SalesList.cpp backend_cpp/util/FileUtils.cpp -std=c++11
```
*(Note: `-std=c++11` is added for better compatibility, though not strictly necessary for the features used.)*

### 2. Compile and Run the Java Frontend

With the `main.exe` executable in place, compile the Java source files.

```sh
# Compile all Java files and place .class files in the project root
javac -d . frontend_java/src/app/Main.java frontend_java/src/app/Modules/*.java frontend_java/src/app/util/JsonHandler.java
```

After compilation, run the main application.

```sh
java app.Main
```

The application window should now appear.

## Project Explanations for Viva-Voce

### System Design and Architecture

#### 1. Use Case Diagram Description

-   **Actors:** The primary actor is the **Librarian**.
-   **Use Cases:**
    -   **Manage Books:** Includes sub-use-cases: `Add Book`, `Search Book`, `Delete Book`, `Display All Books`.
    -   **Manage Members:** Includes sub-use-cases: `Add Member`, `Search Member`, `Delete Member`, `Display All Members`.
    -   **Manage Issues/Returns:** (removed in this revision)

The Librarian interacts with the Java GUI, which triggers these use cases. The system then processes the request using the C++ backend and displays the result.

#### 2. Class Diagram Description

-   **Java (Frontend):**
    -   `Main`: The main JFrame that holds the `JTabbedPane`.
    -   `BookModule`, `MemberModule`, `IssueReturnModule`: `JPanel` classes, each representing a tab in the UI. They contain all the GUI components (text fields, buttons) and event handling logic for their respective module.
    -   `JsonHandler`: A utility class with static methods for creating and parsing JSON strings. It decouples the GUI logic from the specifics of JSON formatting.
-   **C++ (Backend):**
    -   **BookService (BookAVL internally):** Replaces the legacy `BookArray` with a `BookService` adapter that uses an `AVL` tree (`BookAVL`) internally for balanced inserts, deletes, and searches while preserving the JSON file API used by the Java frontend.
    -   `MemberList`: Manages a linked list of `Member` structs. It contains methods for adding, searching (linear), deleting, and displaying members.
    -   `IssueQueue`: Manages a queue (implemented as a linked list) of `IssueRecord` structs. It provides methods to issue (enqueue), return (find and remove), and display issued books, including a sorting feature.

#### 3. Java-C++ Integration Method

**Question:** How does the Java frontend communicate with the C++ backend?

**Answer:** The communication is done via the filesystem using JSON files, which acts as a simple, language-agnostic data exchange format.

1.  **Java Initiates:** When the user performs an action (e.g., clicking "Add Book"), the Java application gathers the data and writes it into a specific JSON file (e.g., `data/book.json`).
2.  **C++ Executes:** Java then executes the compiled C++ program (`main.exe`) as a separate process, passing a command-line argument (`book` or `member`) to specify the module.
3.  **C++ Processes:** The C++ program reads the operation and data from the corresponding JSON file (e.g., `data/book.json`). It also reads from its data store file (e.g., `data/books_data.json`), performs the requested DSA operation, and saves any changes back to the data store file.
4.  **C++ Responds:** The backend writes the result of the operation (a success/error message or the requested data) into a shared `data/result.json` file.
5.  **Java Displays:** The Java application, which was waiting for the C++ process to complete, then reads `data/result.json` and displays the outcome to the user in the GUI.

This file-based approach was chosen for its simplicity and to avoid the complexity of inter-process communication APIs, making it easy to explain and implement within the project's constraints.

### Data Structures and Algorithms (DSA)

#### 1. Book Module: Array + Binary Search

**Question:** Which DSAs did you use for the Book module and why?

**Answer:** We used a **static array** to store the book records and **Binary Search** for searching.

-   **Array:** An array provides fast, O(1) access if you know the index. However, the main reason for this choice was to create a foundation for an efficient search algorithm. Additions and deletions can be slow (O(n)) because of data shifting, but for a small to medium-sized library, this is an acceptable trade-off.
-   **Binary Search:** To speed up searching, we chose Binary Search, which has a time complexity of **O(log n)**. This is significantly faster than a linear search (O(n)) for large datasets. To make Binary Search possible, the array of books is kept **sorted by Book ID** at all times. After any addition or deletion, the array is re-sorted to maintain this property.

#### 2. Member Module: Linked List + Linear Search

**Question:** Which DSAs did you use for the Member module and why?

**Answer:** We used a **Singly Linked List** to store member records and **Linear Search** for searching.

-   **Linked List:** A linked list is a dynamic data structure, making additions and deletions very efficient. Adding a new member is an O(n) operation (because we traverse to the end), but can be O(1) if we also store a `tail` pointer. Deleting a member is an O(n) operation due to the search, but the removal itself is a quick O(1) pointer update. This is advantageous when the number of members is expected to change frequently.
-   **Linear Search:** Since a linked list does not provide random access, we must use Linear Search to find a member. This has a time complexity of **O(n)**, as we might have to traverse the entire list in the worst case. While slower than Binary Search, it's the most straightforward search algorithm for a basic linked list.

#### 3. Issue/Return Module: (removed)

The Issue/Return module (issue tracking and return) has been removed in this revision and archived under `backend_cpp/removed/` and `frontend_java/removed/` to simplify the project and reduce maintenance surface.